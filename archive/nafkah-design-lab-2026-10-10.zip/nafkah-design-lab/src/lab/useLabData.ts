"use client";

import { useMemo } from "react";
import { useApp } from "@/state/AppContext";
import {
  AFFORDABILITY_BANDS,
  BAND_LABEL,
  bandColors,
} from "@/lib/calculations";
import { EXPENSE_CATEGORIES } from "@/data/costs";
import type {
  AffordabilityBand,
  Assumptions,
  ExpenseCategoryKey,
  Provenance,
  RegionMetrics,
} from "@/lib/types";

/** Shared derivations for the three lab variants — logic only, no styling. */

export const BAND_ORDER: AffordabilityBand[] = [
  "comfortable",
  "manageable",
  "tight",
  "insufficient",
];

export function bandRange(band: AffordabilityBand): string {
  const b = AFFORDABILITY_BANDS;
  if (band === "comfortable") return `≥ ${b.comfortableAt}%`;
  if (band === "manageable") return `${b.manageableAt}–${b.comfortableAt - 1}%`;
  if (band === "tight") return `${b.tightAt}–${b.manageableAt - 1}%`;
  return `< ${b.tightAt}%`;
}

/** Text-safe band colours: the fills are too light for small text on paper. */
const BAND_INK_LIGHT: Record<AffordabilityBand, string> = {
  comfortable: "#0b6b42",
  manageable: "#22698a",
  tight: "#8a5a0c",
  insufficient: "#a5271f",
};
const BAND_INK_DARK: Record<AffordabilityBand, string> = {
  comfortable: "#5fd3a0",
  manageable: "#8ccbe6",
  tight: "#f3cd6e",
  insufficient: "#ff8b80",
};

export function bandTheme(dark: boolean) {
  const fill = bandColors(dark);
  const ink = dark ? BAND_INK_DARK : BAND_INK_LIGHT;
  return BAND_ORDER.reduce(
    (acc, band) => {
      acc[band] = {
        label: BAND_LABEL[band],
        range: bandRange(band),
        fill: fill[band],
        ink: ink[band],
      };
      return acc;
    },
    {} as Record<
      AffordabilityBand,
      { label: string; range: string; fill: string; ink: string }
    >,
  );
}

export interface RankedRegion {
  code: string;
  name: string;
  shortName: string;
  province: string;
  tier: string;
  metric: RegionMetrics;
}

export function useNationalStats() {
  const { metrics, metricsReady, regionByCode } = useApp();
  return useMemo(() => {
    const counts: Record<AffordabilityBand, number> = {
      comfortable: 0,
      manageable: 0,
      tight: 0,
      insufficient: 0,
    };
    const ranked: RankedRegion[] = [];
    if (metricsReady) {
      for (const m of metrics.values()) {
        counts[m.band]++;
        const region = regionByCode.get(m.code);
        const name = region?.name ?? m.code;
        ranked.push({
          code: m.code,
          name,
          shortName: name.replace(/^Kota /, ""),
          province: region?.province ?? "",
          tier: region?.tier ?? "kabupaten",
          metric: m,
        });
      }
    }
    ranked.sort((a, b) => b.metric.coveragePercent - a.metric.coveragePercent);
    const total = ranked.length;
    const below = counts.tight + counts.insufficient;
    const median = total
      ? ranked[Math.floor(total / 2)].metric.coveragePercent
      : 0;
    return {
      ready: metricsReady && total > 0,
      counts,
      total,
      below,
      median,
      ranked,
    };
  }, [metrics, metricsReady, regionByCode]);
}

export function useRegionDetail(code: string | null) {
  const { state, metrics, metricsReady, regionByCode } = useApp();
  if (!code) return null;
  const region = regionByCode.get(code);
  const feature = state.geometry?.features.find(
    (f) => f.properties.kode === code,
  );
  const metric = metricsReady ? metrics.get(code) : undefined;
  const wage = state.wages.get(code);
  const costs = state.costs.get(code);
  const narrative = state.narratives.get(code);
  const originRegion = state.originCode
    ? regionByCode.get(state.originCode)
    : undefined;
  const wageProvenance =
    metric?.wageSource === "origin" && state.originCode
      ? (state.wages.get(state.originCode) ?? wage)
      : wage;
  const name = region?.name ?? feature?.properties.name ?? code;
  return {
    code,
    name,
    shortName: name.replace(/^Kota /, ""),
    province: region?.province ?? feature?.properties.province ?? "",
    tier: region?.tier ?? "",
    region,
    metric,
    wage,
    costs,
    narrative,
    originRegion,
    wageProvenance,
    isPinned: state.pinned.includes(code),
    isOrigin: state.originCode === code,
    hasData: Boolean(metric && wage && costs),
  };
}

export type RegionDetail = NonNullable<ReturnType<typeof useRegionDetail>>;

/** Category rows sorted by share of the monthly total, with provenance. */
export function breakdownRows(detail: RegionDetail) {
  const m = detail.metric;
  if (!m || !detail.costs) return [];
  const total = m.totalMonthlyCost || 1;
  return EXPENSE_CATEGORIES.map((c) => ({
    key: c.key as ExpenseCategoryKey,
    label: c.label,
    color: c.color,
    value: m.breakdown[c.key],
    share: m.breakdown[c.key] / total,
    provenance: detail.costs!.baseline[c.key] as Provenance,
  }))
    .filter((r) => r.value > 0)
    .sort((a, b) => b.value - a.value);
}

/** Short wage label honouring custom income / relocation / take-home. */
export function wageLabel(m: RegionMetrics, a: Assumptions): string {
  const dual = a.dualIncome && a.householdType !== "single";
  if (m.wageSource === "custom")
    return dual ? "Pendapatanmu + UMK pasangan" : "Pendapatanmu";
  if (m.wageSource === "origin")
    return dual ? "Gaji asal × 2" : "Gaji asal (UMK)";
  const base = a.wageBasis === "gross" ? "UMK" : "UMK take-home";
  return dual ? `${base} × 2` : base;
}

export function confidenceLabel(c: Provenance["confidence"]): string {
  return c === "official" ? "Resmi" : c === "estimate" ? "Estimasi" : "Sampel";
}

/** "Rp4,74 jt" — newsroom-style rupiah for headlines. */
export function rpJt(value: number): string {
  const abs = Math.abs(value);
  if (abs >= 1_000_000) {
    return `Rp${(abs / 1_000_000).toLocaleString("id-ID", { maximumFractionDigits: 2 })} jt`;
  }
  return `Rp${Math.round(abs / 1000).toLocaleString("id-ID")} rb`;
}

export function rpFull(value: number): string {
  return `Rp${(Math.round(Math.abs(value) / 1000) * 1000).toLocaleString("id-ID")}`;
}

export function pct(value: number, digits = 0): string {
  return `${value.toLocaleString("id-ID", { maximumFractionDigits: digits })}%`;
}
