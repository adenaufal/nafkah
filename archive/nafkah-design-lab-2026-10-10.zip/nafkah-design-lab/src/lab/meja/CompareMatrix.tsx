"use client";

import { useState } from "react";
import { X } from "@phosphor-icons/react";
import { useApp } from "@/state/AppContext";
import { EXPENSE_CATEGORIES } from "@/data/costs";
import { useComparison } from "../useComparison";
import { bandTheme, pct, wageLabel } from "../useLabData";
import { rb, signedRb } from "./model";

/**
 * Pinned regions as a delta matrix: pick a baseline column and every other
 * cell shows its difference — the question analysts actually ask.
 */
export function CompareMatrix() {
  const { state, unpin, select } = useApp();
  const { items } = useComparison();
  const theme = bandTheme(state.darkMode);
  const [baseCode, setBaseCode] = useState<string | null>(null);
  const base = items.find((i) => i.code === baseCode) ?? items[0];
  if (!base) return null;

  const rows: {
    label: string;
    get: (i: (typeof items)[number]) => number;
    money: boolean;
    better: "high" | "low";
  }[] = [
    {
      label: wageLabel(base.metric, state.assumptions),
      get: (i) => i.metric.wageAmount,
      money: true,
      better: "high",
    },
    {
      label: "Biaya hidup",
      get: (i) => i.metric.totalMonthlyCost,
      money: true,
      better: "low",
    },
    {
      label: "Selisih / bln",
      get: (i) => i.metric.surplusOrDeficit,
      money: true,
      better: "high",
    },
    ...EXPENSE_CATEGORIES.map((c) => ({
      label: c.label
        .replace(" / pengasuhan anak", "")
        .replace(" / dana cadangan", ""),
      get: (i: (typeof items)[number]) => i.metric.breakdown[c.key],
      money: true,
      better: "low" as const,
    })),
  ];

  return (
    <div className="lab-scroll h-full overflow-auto">
      <table className="w-full min-w-[640px] border-separate border-spacing-0 text-[12px]">
        <thead className="sticky top-0 z-[1] bg-[var(--panel)]">
          <tr>
            <th
              scope="col"
              className="w-[150px] border-b border-[var(--line)] px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-[0.06em] text-[var(--muted)]"
            >
              Basis: klik kolom
            </th>
            {items.map((it) => {
              const isBase = it.code === base.code;
              return (
                <th
                  key={it.code}
                  scope="col"
                  className={`border-b border-l border-[var(--line)] px-3 py-2 text-right align-top ${isBase ? "bg-[var(--row-sel)]" : ""}`}
                >
                  <div className="flex items-start justify-end gap-1.5">
                    <button
                      type="button"
                      onClick={() => setBaseCode(it.code)}
                      aria-pressed={isBase}
                      className="min-w-0 text-right"
                    >
                      <span className="block truncate text-[12.5px] font-bold hover:text-[var(--accent-ink)]">
                        {it.region.name.replace(/^Kota /, "")}
                      </span>
                      <span className="flex items-center justify-end gap-1 text-[11px] font-normal text-[var(--muted)]">
                        <span
                          aria-hidden="true"
                          className="h-2 w-2 rounded-[2px]"
                          style={{ background: theme[it.metric.band].fill }}
                        />
                        <span className="f-mono tnum">
                          {pct(it.metric.coveragePercent, 1)}
                        </span>
                        {isBase && (
                          <span className="font-semibold text-[var(--accent-ink)]">
                            · basis
                          </span>
                        )}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => unpin(it.code)}
                      aria-label={`Lepas ${it.region.name}`}
                      className="grid h-5 w-5 place-items-center rounded-[4px] text-[var(--faint)] hover:bg-[var(--row-hover)] hover:text-[var(--ink)]"
                    >
                      <X size={10} weight="bold" aria-hidden="true" />
                    </button>
                  </div>
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, ri) => {
            const bv = row.get(base);
            return (
              <tr
                key={row.label}
                className={
                  ri === 2
                    ? "[&>*]:border-b-2 [&>*]:border-b-[var(--line-2)]"
                    : ""
                }
              >
                <th
                  scope="row"
                  className={`border-b border-[var(--line)] px-3 py-1.5 text-left font-medium ${ri < 3 ? "text-[var(--ink)]" : "text-[var(--ink-2)]"}`}
                >
                  {row.label}
                </th>
                {items.map((it) => {
                  const v = row.get(it);
                  const isBase = it.code === base.code;
                  const delta = v - bv;
                  const good = row.better === "high" ? delta > 0 : delta < 0;
                  return (
                    <td
                      key={it.code}
                      onClick={() => select(it.code)}
                      className={`cursor-pointer border-b border-l border-[var(--line)] px-3 py-1.5 text-right ${isBase ? "bg-[var(--row-sel)]" : ""}`}
                    >
                      <span
                        className={`f-mono tnum block ${ri < 3 ? "font-semibold" : ""}`}
                      >
                        {ri === 2 ? signedRb(v) : rb(v)}
                      </span>
                      {!isBase && Math.abs(delta) >= 1000 && (
                        <span
                          className={`f-mono tnum block text-[10.5px] ${good ? "text-[var(--ok)]" : "text-[var(--danger)]"}`}
                        >
                          {signedRb(delta)}
                        </span>
                      )}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
      <p className="px-3 py-2 text-[11px] text-[var(--faint)]">
        Angka dalam ribu rupiah per bulan. Hijau = lebih baik dari basis
        untukmu.
      </p>
    </div>
  );
}
