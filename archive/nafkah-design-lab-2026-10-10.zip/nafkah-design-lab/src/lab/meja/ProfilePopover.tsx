"use client";

import { useEffect, useRef } from "react";
import { MAX_CHILDREN } from "@/state/persist";
import type {
  HouseholdType,
  HousingType,
  LifestyleLevel,
  TransportMode,
  WageBasis,
} from "@/lib/types";
import { parseRupiah, rupiahInput, useAssumptionActions } from "../actions";

/** Dense assumption form anchored to the toolbar; no scrim, map stays live. */
export function ProfilePopover({ onClose }: { onClose: () => void }) {
  const { a, set, setHousehold, reset } = useAssumptionActions();
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      const t = e.target as HTMLElement;
      if (!ref.current?.contains(t) && !t.closest("[data-profile-trigger]"))
        onClose();
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onKey);
    ref.current?.querySelector<HTMLElement>("button")?.focus();
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  return (
    <div
      ref={ref}
      role="dialog"
      aria-label="Profil rumah tangga"
      className="lab-fade absolute right-0 top-[calc(100%+6px)] z-50 w-[440px] rounded-[8px] border border-[var(--line-2)] bg-[var(--panel-2)] p-3 text-[12.5px] shadow-[0_12px_40px_rgb(0_0_0/0.18)]"
    >
      <div className="grid grid-cols-[96px_minmax(0,1fr)] items-center gap-x-3 gap-y-2">
        <Row label="Rumah tangga">
          <Seg<HouseholdType>
            value={a.householdType}
            onChange={setHousehold}
            options={[
              ["single", "Lajang"],
              ["couple", "Pasangan"],
              ["family", "Keluarga"],
            ]}
          />
        </Row>
        <Row label="Anak">
          <Seg<string>
            value={String(a.children)}
            onChange={(v) => set("children", Number(v))}
            options={Array.from(
              { length: MAX_CHILDREN + 1 },
              (_, i) => [String(i), String(i)] as [string, string],
            )}
          />
        </Row>
        <Row label="Gaya hidup">
          <Seg<LifestyleLevel>
            value={a.lifestyle}
            onChange={(v) => set("lifestyle", v)}
            options={[
              ["budget", "Hemat"],
              ["moderate", "Standar"],
              ["comfortable", "Nyaman"],
            ]}
          />
        </Row>
        <Row label="Hunian">
          <Seg<HousingType>
            value={a.housing}
            onChange={(v) => set("housing", v)}
            options={[
              ["room", "Kost"],
              ["studio", "KPR"],
              ["oneBedroom", "Apartemen"],
            ]}
          />
        </Row>
        <Row label="Transportasi">
          <Seg<TransportMode>
            value={a.transport}
            onChange={(v) => set("transport", v)}
            options={[
              ["motorcycle", "Motor"],
              ["publicTransport", "Umum"],
              ["rideHailing", "Ojol"],
            ]}
          />
        </Row>
        <Row label="Basis upah">
          <Seg<WageBasis>
            value={a.wageBasis}
            onChange={(v) => set("wageBasis", v)}
            options={[
              ["gross", "Kotor"],
              ["takeHome", "Take-home"],
            ]}
          />
        </Row>
        <Row label="Gaji sendiri">
          <Money
            value={a.customIncome}
            onChange={(v) => set("customIncome", v)}
            label="Gaji sendiri per bulan"
            placeholder="kosong = UMK daerah"
          />
        </Row>
        <Row label="Cicilan">
          <Money
            value={a.installmentMonthly}
            onChange={(v) => set("installmentMonthly", v)}
            label="Cicilan rumah per bulan"
            placeholder="kosong = sewa estimasi"
          />
        </Row>
      </div>
      <div className="mt-3 flex items-center gap-4 border-t border-[var(--line)] pt-2.5">
        <label className="flex items-center gap-1.5">
          <input
            type="checkbox"
            checked={a.includeSavings}
            onChange={(e) => set("includeSavings", e.target.checked)}
            className="h-3.5 w-3.5 accent-[var(--accent)]"
          />
          Tabungan ±10%
        </label>
        <label
          className={`flex items-center gap-1.5 ${a.householdType === "single" ? "opacity-40" : ""}`}
        >
          <input
            type="checkbox"
            disabled={a.householdType === "single"}
            checked={a.dualIncome && a.householdType !== "single"}
            onChange={(e) => set("dualIncome", e.target.checked)}
            className="h-3.5 w-3.5 accent-[var(--accent)]"
          />
          2 upah
        </label>
        <button
          type="button"
          onClick={reset}
          className="ml-auto text-[12px] font-semibold text-[var(--muted)] hover:text-[var(--ink)]"
        >
          Reset
        </button>
      </div>
    </div>
  );
}

function Row({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <>
      <span className="text-[11.5px] font-semibold text-[var(--muted)]">
        {label}
      </span>
      <div>{children}</div>
    </>
  );
}

function Seg<T extends string>({
  value,
  onChange,
  options,
}: {
  value: T;
  onChange: (v: T) => void;
  options: [T, string][];
}) {
  return (
    <div
      className="flex rounded-[6px] border border-[var(--line)] p-[2px]"
      role="radiogroup"
    >
      {options.map(([v, l]) => (
        <button
          key={v}
          type="button"
          role="radio"
          aria-checked={v === value}
          onClick={() => onChange(v)}
          className={`h-6 flex-1 rounded-[4px] px-1.5 text-[12px] ${v === value ? "bg-[var(--ink)] font-semibold text-[var(--panel-2)]" : "text-[var(--ink-2)] hover:bg-[var(--row-hover)]"}`}
        >
          {l}
        </button>
      ))}
    </div>
  );
}

function Money({
  value,
  onChange,
  label,
  placeholder,
}: {
  value: number | null;
  onChange: (v: number | null) => void;
  label: string;
  placeholder: string;
}) {
  return (
    <div className="flex h-7 items-center rounded-[6px] border border-[var(--line)] bg-[var(--panel)] focus-within:border-[var(--accent)]">
      <span className="f-mono pl-2 text-[11px] text-[var(--faint)]">Rp</span>
      <input
        inputMode="numeric"
        aria-label={label}
        placeholder={placeholder}
        value={rupiahInput(value)}
        onChange={(e) => onChange(parseRupiah(e.target.value))}
        className="f-mono tnum h-full min-w-0 flex-1 bg-transparent px-2 text-[12px] outline-none placeholder:font-sans placeholder:text-[var(--faint)]"
      />
    </div>
  );
}
