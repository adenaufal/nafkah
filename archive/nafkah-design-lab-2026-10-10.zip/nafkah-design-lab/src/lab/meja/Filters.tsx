"use client";

import { useMemo, useState } from "react";
import { useApp } from "@/state/AppContext";
import type { AffordabilityBand } from "@/lib/types";
import { BAND_ORDER, bandTheme, useNationalStats } from "../useLabData";
import { type DeskFilters, emptyFilters, isFiltered } from "./model";

function toggle<T>(set: ReadonlySet<T>, v: T): Set<T> {
  const next = new Set(set);
  if (next.has(v)) next.delete(v);
  else next.add(v);
  return next;
}

export function Filters({
  filters,
  onChange,
  shown,
}: {
  filters: DeskFilters;
  onChange: (f: DeskFilters) => void;
  shown: number;
}) {
  const { state } = useApp();
  const stats = useNationalStats();
  const theme = bandTheme(state.darkMode);
  const [pq, setPq] = useState("");
  const provinces = useMemo(() => {
    const map = new Map<string, number>();
    for (const r of stats.ranked)
      map.set(r.province, (map.get(r.province) ?? 0) + 1);
    return [...map.entries()].sort((a, b) => a[0].localeCompare(b[0], "id"));
  }, [stats.ranked]);
  const tiers = useMemo(() => {
    let kota = 0;
    for (const r of stats.ranked) if (r.tier === "kota") kota++;
    return { kota, kabupaten: stats.total - kota };
  }, [stats.ranked, stats.total]);
  const visibleProvinces = provinces.filter(([p]) =>
    p.toLowerCase().includes(pq.trim().toLowerCase()),
  );

  return (
    <div className="flex h-full flex-col text-[12.5px]">
      <div className="flex items-center justify-between border-b border-[var(--line)] px-3 py-2.5">
        <p className="text-[10.5px] font-bold uppercase tracking-[0.1em] text-[var(--faint)]">
          Saring
        </p>
        {isFiltered(filters) ? (
          <button
            type="button"
            onClick={() => onChange(emptyFilters())}
            className="text-[11.5px] font-semibold text-[var(--accent-ink)] hover:underline"
          >
            Reset ({shown})
          </button>
        ) : (
          <span className="f-mono text-[11px] text-[var(--faint)]">
            {stats.ready ? shown : "–"}
          </span>
        )}
      </div>
      <fieldset className="border-b border-[var(--line)] px-3 py-2.5">
        <legend className="sr-only">Kelompok keterjangkauan</legend>
        <p
          aria-hidden="true"
          className="mb-1.5 text-[11px] font-semibold text-[var(--muted)]"
        >
          Kelompok
        </p>
        {BAND_ORDER.map((b: AffordabilityBand) => (
          <label
            key={b}
            className="flex h-7 cursor-pointer items-center gap-2 rounded-[5px] px-1 hover:bg-[var(--row-hover)]"
          >
            <input
              type="checkbox"
              checked={filters.bands.has(b)}
              onChange={() =>
                onChange({ ...filters, bands: toggle(filters.bands, b) })
              }
              className="h-3.5 w-3.5 accent-[var(--accent)]"
            />
            <span
              aria-hidden="true"
              className="h-2.5 w-2.5 rounded-[2px]"
              style={{ background: theme[b].fill }}
            />
            <span className="flex-1">{theme[b].label}</span>
            <span className="f-mono tnum text-[11px] text-[var(--faint)]">
              {stats.ready ? stats.counts[b] : "–"}
            </span>
          </label>
        ))}
      </fieldset>
      <fieldset className="border-b border-[var(--line)] px-3 py-2.5">
        <legend className="sr-only">Jenis daerah</legend>
        <p
          aria-hidden="true"
          className="mb-1.5 text-[11px] font-semibold text-[var(--muted)]"
        >
          Jenis
        </p>
        {(["kota", "kabupaten"] as const).map((t) => (
          <label
            key={t}
            className="flex h-7 cursor-pointer items-center gap-2 rounded-[5px] px-1 hover:bg-[var(--row-hover)]"
          >
            <input
              type="checkbox"
              checked={filters.tiers.has(t)}
              onChange={() =>
                onChange({ ...filters, tiers: toggle(filters.tiers, t) })
              }
              className="h-3.5 w-3.5 accent-[var(--accent)]"
            />
            <span className="flex-1">
              {t === "kota" ? "Kota" : "Kabupaten"}
            </span>
            <span className="f-mono tnum text-[11px] text-[var(--faint)]">
              {stats.ready ? tiers[t] : "–"}
            </span>
          </label>
        ))}
      </fieldset>
      <div className="flex min-h-0 flex-1 flex-col px-3 pt-2.5">
        <p className="mb-1.5 flex items-center justify-between text-[11px] font-semibold text-[var(--muted)]">
          Provinsi
          {filters.provinces.size > 0 && (
            <button
              type="button"
              onClick={() => onChange({ ...filters, provinces: new Set() })}
              className="font-semibold text-[var(--accent-ink)] hover:underline"
            >
              Semua
            </button>
          )}
        </p>
        <input
          value={pq}
          onChange={(e) => setPq(e.target.value)}
          placeholder="Cari provinsi…"
          aria-label="Cari provinsi"
          className="mb-1.5 h-7 rounded-[5px] border border-[var(--line)] bg-[var(--panel-2)] px-2 text-[12px] outline-none focus:border-[var(--accent)]"
        />
        <div className="lab-scroll -mx-1 min-h-0 flex-1 overflow-y-auto pb-2">
          {visibleProvinces.map(([p, n]) => (
            <label
              key={p}
              className="flex h-7 cursor-pointer items-center gap-2 rounded-[5px] px-1 hover:bg-[var(--row-hover)]"
            >
              <input
                type="checkbox"
                checked={filters.provinces.has(p)}
                onChange={() =>
                  onChange({
                    ...filters,
                    provinces: toggle(filters.provinces, p),
                  })
                }
                className="h-3.5 w-3.5 accent-[var(--accent)]"
              />
              <span className="min-w-0 flex-1 truncate">{p}</span>
              <span className="f-mono tnum text-[11px] text-[var(--faint)]">
                {n}
              </span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
}
