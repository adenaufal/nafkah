"use client";

import { useEffect, useRef } from "react";
import { CaretDown, CaretUp } from "@phosphor-icons/react";
import { MAX_PINS, useApp } from "@/state/AppContext";
import { AFFORDABILITY_BANDS } from "@/lib/calculations";
import type { RankedRegion } from "../useLabData";
import { bandTheme, pct } from "../useLabData";
import { rb, signedRb, type SortKey } from "./model";

const COLS: {
  key: SortKey;
  label: string;
  align: "left" | "right";
  title?: string;
  wideOnly?: boolean;
}[] = [
  { key: "name", label: "Daerah", align: "left" },
  { key: "province", label: "Provinsi", align: "left", wideOnly: true },
  {
    key: "wage",
    label: "Upah",
    align: "right",
    title: "Upah basis profil, ribu rupiah",
    wideOnly: true,
  },
  {
    key: "cost",
    label: "Biaya",
    align: "right",
    title: "Estimasi biaya hidup bulanan, ribu rupiah",
    wideOnly: true,
  },
  {
    key: "coverage",
    label: "Cakupan",
    align: "left",
    title: "Upah ÷ biaya × 100",
  },
  {
    key: "surplus",
    label: "Selisih",
    align: "right",
    title: "Upah − biaya, ribu rupiah",
  },
];

/**
 * All 514 regions in one sortable table, linked to the map both ways:
 * hovering a row outlines the region, hovering the map lights the row.
 */
export function RegionTable({
  rows,
  sort,
  onSort,
  hoverCode,
  onHover,
}: {
  rows: RankedRegion[];
  sort: { key: SortKey; dir: "asc" | "desc" };
  onSort: (key: SortKey) => void;
  hoverCode: string | null;
  onHover: (code: string | null) => void;
}) {
  const { state, select, pin, unpin, metricsReady, retryData } = useApp();
  const theme = bandTheme(state.darkMode);
  const body = useRef<HTMLTableSectionElement>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const b = AFFORDABILITY_BANDS;

  // Keep the selected row in view when selection comes from the map/search.
  useEffect(() => {
    if (!state.selectedCode) return;
    const row = body.current?.querySelector<HTMLElement>(
      `[data-code="${state.selectedCode}"]`,
    );
    row?.scrollIntoView({ block: "nearest" });
  }, [state.selectedCode]);

  const move = (delta: number) => {
    if (!rows.length) return;
    const i = rows.findIndex((r) => r.code === state.selectedCode);
    const next =
      rows[Math.min(rows.length - 1, Math.max(0, i + delta))] ?? rows[0];
    select(next.code);
  };

  return (
    <div
      ref={scroller}
      tabIndex={0}
      aria-label="Tabel daerah. Panah atas/bawah memilih baris, P menyematkan."
      onKeyDown={(e) => {
        if (e.key === "ArrowDown" || e.key === "j") {
          e.preventDefault();
          move(1);
        } else if (e.key === "ArrowUp" || e.key === "k") {
          e.preventDefault();
          move(-1);
        } else if ((e.key === "p" || e.key === "P") && state.selectedCode) {
          e.preventDefault();
          if (state.pinned.includes(state.selectedCode))
            unpin(state.selectedCode);
          else pin(state.selectedCode);
        }
      }}
      className="lab-scroll h-full overflow-auto outline-none focus-visible:shadow-[inset_0_0_0_2px_var(--accent)]"
    >
      <table className="w-full border-separate border-spacing-0 text-[12.5px] sm:min-w-[720px]">
        <thead className="sticky top-0 z-[1] bg-[var(--panel)]">
          <tr>
            <th
              scope="col"
              className="w-9 border-b border-[var(--line)] px-2 py-2"
            >
              <span className="sr-only">Sematkan</span>
            </th>
            {COLS.map((c) => {
              const on = sort.key === c.key;
              return (
                <th
                  key={c.key}
                  scope="col"
                  aria-sort={
                    on
                      ? sort.dir === "asc"
                        ? "ascending"
                        : "descending"
                      : "none"
                  }
                  className={`border-b border-[var(--line)] px-2 py-0 font-semibold text-[var(--muted)] ${c.align === "right" ? "text-right" : "text-left"} ${c.key === "coverage" ? "w-[150px] max-sm:w-[110px]" : ""} ${c.wideOnly ? "max-sm:hidden" : ""}`}
                >
                  <button
                    type="button"
                    title={c.title}
                    onClick={() => onSort(c.key)}
                    className={`inline-flex h-8 items-center gap-1 text-[11.5px] uppercase tracking-[0.06em] hover:text-[var(--ink)] ${on ? "text-[var(--ink)]" : ""} ${c.align === "right" ? "flex-row-reverse" : ""}`}
                  >
                    {c.label}
                    {on ? (
                      sort.dir === "asc" ? (
                        <CaretUp size={11} weight="bold" aria-hidden="true" />
                      ) : (
                        <CaretDown size={11} weight="bold" aria-hidden="true" />
                      )
                    ) : (
                      <span className="w-[11px]" aria-hidden="true" />
                    )}
                  </button>
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody ref={body} onMouseLeave={() => onHover(null)}>
          {state.dataStatus === "error" && (
            <tr>
              <td
                colSpan={7}
                role="alert"
                className="px-4 py-10 text-center text-[13px]"
              >
                <span className="text-[var(--danger)]">
                  Data upah &amp; biaya gagal dimuat.
                </span>{" "}
                <button
                  type="button"
                  onClick={retryData}
                  className="font-semibold text-[var(--accent-ink)] underline underline-offset-2"
                >
                  Muat ulang
                </button>
              </td>
            </tr>
          )}
          {!metricsReady &&
            state.dataStatus !== "error" &&
            Array.from({ length: 12 }, (_, i) => (
              <tr key={i} aria-hidden="true">
                <td colSpan={7} className="px-3 py-2">
                  <div
                    className="lab-skel h-4"
                    style={{ width: `${70 + ((i * 37) % 30)}%` }}
                  />
                </td>
              </tr>
            ))}
          {metricsReady && rows.length === 0 && (
            <tr>
              <td
                colSpan={7}
                className="px-4 py-10 text-center text-[13px] text-[var(--muted)]"
              >
                Tidak ada daerah yang cocok dengan saringan ini.
              </td>
            </tr>
          )}
          {rows.map((r, i) => {
            const m = r.metric;
            const sel = state.selectedCode === r.code;
            const hov = hoverCode === r.code;
            const pinned = state.pinned.includes(r.code);
            const full = !pinned && state.pinned.length >= MAX_PINS;
            const cov = Math.min(150, Math.max(50, m.coveragePercent));
            const x = (v: number) => ((v - 50) / 100) * 100;
            return (
              <tr
                key={r.code}
                data-code={r.code}
                aria-selected={sel}
                onMouseEnter={() => onHover(r.code)}
                onClick={() => select(r.code)}
                className={`cursor-pointer [content-visibility:auto] [contain-intrinsic-size:auto_30px] ${
                  sel
                    ? "bg-[var(--row-sel)]"
                    : hov
                      ? "bg-[var(--row-hover)]"
                      : i % 2
                        ? "bg-[var(--panel)]"
                        : "bg-[var(--panel-2)]"
                }`}
              >
                <td className="border-b border-[var(--line)] px-2 py-0 text-center">
                  <input
                    type="checkbox"
                    checked={pinned}
                    disabled={full}
                    aria-label={`${pinned ? "Lepas" : "Sematkan"} ${r.name}`}
                    title={full ? `Maksimal ${MAX_PINS} daerah` : undefined}
                    onClick={(e) => e.stopPropagation()}
                    onChange={() => (pinned ? unpin(r.code) : pin(r.code))}
                    className="h-3.5 w-3.5 accent-[var(--accent)] disabled:opacity-30"
                  />
                </td>
                <td className="max-w-[220px] border-b border-[var(--line)] px-2 py-[7px] max-sm:max-w-[150px]">
                  <span
                    className={`block truncate ${sel ? "font-bold" : "font-medium"}`}
                  >
                    {r.tier === "kota" && (
                      <span className="text-[var(--faint)]">Kota </span>
                    )}
                    {r.shortName}
                  </span>
                  <span className="block truncate text-[11px] text-[var(--muted)] sm:hidden">
                    {r.province}
                  </span>
                </td>
                <td className="max-w-[160px] truncate border-b border-[var(--line)] px-2 text-[var(--muted)] max-sm:hidden">
                  {r.province}
                </td>
                <td className="f-mono tnum border-b border-[var(--line)] px-2 text-right text-[12px] max-sm:hidden">
                  {rb(m.wageAmount)}
                </td>
                <td className="f-mono tnum border-b border-[var(--line)] px-2 text-right text-[12px] max-sm:hidden">
                  {rb(m.totalMonthlyCost)}
                </td>
                <td className="border-b border-[var(--line)] px-2">
                  <span className="flex items-center gap-2">
                    <span className="f-mono tnum w-[42px] text-right text-[12px] font-semibold">
                      {pct(m.coveragePercent)}
                    </span>
                    <span
                      className="relative h-[10px] flex-1"
                      aria-hidden="true"
                    >
                      <span className="absolute inset-y-[4px] left-0 right-0 rounded-full bg-[var(--line)]" />
                      {[b.tightAt, b.manageableAt, b.comfortableAt].map((t) => (
                        <span
                          key={t}
                          className="absolute inset-y-0 w-px bg-[var(--line-2)]"
                          style={{ left: `${x(t)}%` }}
                        />
                      ))}
                      <span
                        className="absolute top-[1px] h-2 w-2 -translate-x-1/2 rounded-full ring-1 ring-[var(--panel-2)]"
                        style={{
                          left: `${x(cov)}%`,
                          background: theme[m.band].fill,
                        }}
                      />
                    </span>
                  </span>
                </td>
                <td
                  className={`f-mono tnum border-b border-[var(--line)] px-2 text-right text-[12px] font-semibold ${
                    m.surplusOrDeficit >= 0
                      ? "text-[var(--ok)]"
                      : "text-[var(--danger)]"
                  }`}
                >
                  {signedRb(m.surplusOrDeficit)}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
