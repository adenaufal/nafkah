"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowClockwise,
  CaretDown,
  ChartBar,
  Check,
  Command,
  DownloadSimple,
  Funnel,
  MapTrifold,
  Moon,
  ShareNetwork,
  Sun,
  Table,
} from "@phosphor-icons/react";
import { useApp } from "@/state/AppContext";
import type { ColorMode } from "@/lib/types";
import LabMap from "../LabMap";
import { useAssumptionActions, useGlobalKeys, useShareLink } from "../actions";
import { useComparison } from "../useComparison";
import { bandTheme, pct, rpJt, useNationalStats } from "../useLabData";
import { CommandPalette, type PaletteCommand } from "./CommandPalette";
import { CompareMatrix } from "./CompareMatrix";
import { Filters } from "./Filters";
import { Inspector } from "./Inspector";
import {
  emptyFilters,
  useDeskRows,
  type DeskFilters,
  type SortKey,
} from "./model";
import { ProfilePopover } from "./ProfilePopover";
import { RegionTable } from "./RegionTable";

const MODES: { id: ColorMode; label: string }[] = [
  { id: "coverage", label: "Cakupan" },
  { id: "cost", label: "Biaya" },
  { id: "wage", label: "Upah" },
];

/**
 * C · Meja Data — dense analyst desk. Filters | map over table | inspector,
 * all visible at once and linked both ways. Keyboard-first (⌘K, ↑/↓, P).
 */
export default function MejaShell() {
  const { state, select, setColorMode, setDarkMode } = useApp();
  const stats = useNationalStats();
  const comparison = useComparison();
  const [filters, setFilters] = useState<DeskFilters>(emptyFilters);
  const [sort, setSort] = useState<{ key: SortKey; dir: "asc" | "desc" }>({
    key: "coverage",
    dir: "desc",
  });
  const [hover, setHover] = useState<{
    code: string;
    x: number;
    y: number;
  } | null>(null);
  const [rowHover, setRowHover] = useState<string | null>(null);
  const [palette, setPalette] = useState(false);
  const [profile, setProfile] = useState(false);
  const [pane, setPane] = useState<"table" | "compare">("table");
  const [split, setSplit] = useState(0.5);
  const [mobileTab, setMobileTab] = useState<
    "map" | "table" | "detail" | "filter"
  >("map");
  const { rows, hidden } = useDeskRows(stats.ranked, filters, sort);
  const centerRef = useRef<HTMLDivElement>(null);
  const wide = useWide();

  useGlobalKeys({
    onSearch: () => setPalette(true),
    onEscape: () => {
      if (palette || profile) return;
      if (state.selectedCode) select(null);
    },
  });

  useEffect(() => {
    if (comparison.items.length < 2 && pane === "compare") setPane("table");
  }, [comparison.items.length, pane]);
  useEffect(() => {
    if (state.selectedCode)
      setMobileTab((t) => (t === "map" || t === "table" ? "detail" : t));
  }, [state.selectedCode]);

  const onSort = (key: SortKey) =>
    setSort((s) =>
      s.key === key
        ? { key, dir: s.dir === "asc" ? "desc" : "asc" }
        : { key, dir: key === "name" || key === "province" ? "asc" : "desc" },
    );

  const commands: PaletteCommand[] = useMemo(
    () => [
      {
        id: "sort-cov",
        label: "Urutkan: cakupan terendah dulu",
        run: () => setSort({ key: "coverage", dir: "asc" }),
      },
      {
        id: "sort-cost",
        label: "Urutkan: biaya hidup tertinggi",
        run: () => setSort({ key: "cost", dir: "desc" }),
      },
      {
        id: "sort-gap",
        label: "Urutkan: selisih paling negatif",
        run: () => setSort({ key: "surplus", dir: "asc" }),
      },
      {
        id: "only-bad",
        label: "Saring: hanya Tak Cukup",
        run: () =>
          setFilters({ ...emptyFilters(), bands: new Set(["insufficient"]) }),
      },
      {
        id: "only-kota",
        label: "Saring: hanya kota",
        run: () => setFilters({ ...emptyFilters(), tiers: new Set(["kota"]) }),
      },
      {
        id: "reset",
        label: "Reset semua saringan",
        run: () => setFilters(emptyFilters()),
      },
      ...MODES.map((m) => ({
        id: `mode-${m.id}`,
        label: `Warnai peta: ${m.label}`,
        run: () => setColorMode(m.id),
      })),
      {
        id: "theme",
        label: state.darkMode ? "Tema terang" : "Tema gelap",
        run: () => setDarkMode(!state.darkMode),
      },
      ...(comparison.items.length >= 2
        ? [
            {
              id: "compare",
              label: `Buka perbandingan (${comparison.items.length})`,
              run: () => setPane("compare"),
            },
            {
              id: "csv",
              label: "Ekspor perbandingan ke CSV",
              run: comparison.exportCsv,
            },
          ]
        : []),
    ],
    [
      state.darkMode,
      comparison.items.length,
      comparison.exportCsv,
      setColorMode,
      setDarkMode,
    ],
  );

  const startDrag = useCallback((e: React.PointerEvent) => {
    const el = centerRef.current;
    if (!el) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    const rect = el.getBoundingClientRect();
    const move = (ev: PointerEvent) =>
      setSplit(
        Math.min(0.78, Math.max(0.22, (ev.clientY - rect.top) / rect.height)),
      );
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  }, []);

  const mapHoverCode = rowHover ?? hover?.code ?? null;
  const markers = state.pinned.map((code, i) => ({
    code,
    label: String(i + 1),
  }));

  const tablePane = (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex h-9 shrink-0 items-center gap-1 border-b border-[var(--line)] bg-[var(--panel)] px-2">
        <TabBtn
          on={pane === "table"}
          onClick={() => setPane("table")}
          icon={<Table size={13} aria-hidden="true" />}
        >
          Tabel{" "}
          <span className="f-mono tnum text-[var(--faint)]">
            {stats.ready ? rows.length : "–"}
          </span>
        </TabBtn>
        <TabBtn
          on={pane === "compare"}
          disabled={comparison.items.length < 2}
          onClick={() => setPane("compare")}
          icon={<ChartBar size={13} aria-hidden="true" />}
          title={
            comparison.items.length < 2
              ? "Sematkan 2 daerah atau lebih (centang di tabel)"
              : undefined
          }
        >
          Bandingkan{" "}
          <span className="f-mono tnum text-[var(--faint)]">
            {comparison.items.length}
          </span>
        </TabBtn>
        <label className="ml-auto flex h-7 items-center gap-1.5 rounded-[6px] border border-[var(--line)] bg-[var(--panel-2)] px-2 focus-within:border-[var(--accent)]">
          <span className="sr-only">Saring nama di tabel</span>
          <input
            value={filters.query}
            onChange={(e) => setFilters({ ...filters, query: e.target.value })}
            placeholder="Saring nama…"
            className="w-36 bg-transparent text-[12px] outline-none placeholder:text-[var(--faint)]"
          />
        </label>
        {comparison.items.length > 0 && (
          <button
            type="button"
            onClick={comparison.exportCsv}
            className="inline-flex h-7 items-center gap-1 rounded-[6px] border border-[var(--line)] px-2 text-[12px] font-semibold hover:border-[var(--ink-2)]"
          >
            <DownloadSimple size={13} aria-hidden="true" />
            {comparison.exportStatus === "done" ? "Diunduh" : "CSV"}
          </button>
        )}
      </div>
      <div className="min-h-0 flex-1">
        {pane === "compare" ? (
          <CompareMatrix />
        ) : (
          <RegionTable
            rows={rows}
            sort={sort}
            onSort={onSort}
            hoverCode={mapHoverCode}
            onHover={setRowHover}
          />
        )}
      </div>
    </div>
  );

  return (
    <div className="meja flex h-dvh flex-col overflow-hidden text-[13px]">
      <Toolbar
        onPalette={() => setPalette(true)}
        profileOpen={profile}
        setProfile={setProfile}
      />

      {/* Desktop desk — only one layout is mounted, so only one map exists. */}
      {wide ? (
        <div className="flex min-h-0 flex-1">
          <aside
            aria-label="Saringan"
            className="w-[232px] shrink-0 border-r border-[var(--line)] bg-[var(--panel)]"
          >
            <Filters
              filters={filters}
              onChange={setFilters}
              shown={rows.length}
            />
          </aside>
          <div ref={centerRef} className="flex min-w-0 flex-1 flex-col">
            <div
              className="relative min-h-0"
              style={{ height: `${split * 100}%` }}
            >
              <LabMap
                hoverCode={mapHoverCode}
                onHover={setHover}
                dimCodes={hidden.size ? hidden : null}
                markers={markers}
                markerClassName="lab-marker-square"
                fillOpacity={0.92}
              />
              {hover && <DeskTip hover={hover} />}
              <MapStatus />
            </div>
            <div
              role="separator"
              aria-orientation="horizontal"
              aria-label="Ubah tinggi peta dan tabel"
              aria-valuenow={Math.round(split * 100)}
              aria-valuemin={22}
              aria-valuemax={78}
              tabIndex={0}
              onPointerDown={startDrag}
              onKeyDown={(e) => {
                if (e.key === "ArrowUp")
                  setSplit((s) => Math.max(0.22, s - 0.05));
                if (e.key === "ArrowDown")
                  setSplit((s) => Math.min(0.78, s + 0.05));
              }}
              className="group relative h-[7px] shrink-0 cursor-row-resize border-y border-[var(--line)] bg-[var(--panel)] outline-none focus-visible:bg-[var(--accent-soft)]"
            >
              <span
                className="absolute left-1/2 top-1/2 h-[3px] w-8 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[var(--line-2)] group-hover:bg-[var(--muted)]"
                aria-hidden="true"
              />
            </div>
            <div className="min-h-0 flex-1">{tablePane}</div>
          </div>
          <aside
            aria-label="Inspektor"
            className="lab-scroll w-[340px] shrink-0 overflow-y-auto border-l border-[var(--line)] bg-[var(--panel)]"
          >
            <Inspector onHover={setRowHover} />
          </aside>
        </div>
      ) : (
        <>
          {/* Compact desk: one pane at a time */}
          <div className="relative min-h-0 flex-1">
            <div
              className={
                mobileTab === "map"
                  ? "absolute inset-0"
                  : "pointer-events-none absolute inset-0 opacity-0"
              }
            >
              <LabMap
                hoverCode={mapHoverCode}
                onHover={setHover}
                dimCodes={hidden.size ? hidden : null}
                markers={markers}
                markerClassName="lab-marker-square"
              />
              <MapStatus />
            </div>
            {mobileTab === "table" && (
              <div className="absolute inset-0 bg-[var(--panel)]">
                {tablePane}
              </div>
            )}
            {mobileTab === "detail" && (
              <div className="lab-scroll absolute inset-0 overflow-y-auto bg-[var(--panel)]">
                <Inspector onHover={setRowHover} />
              </div>
            )}
            {mobileTab === "filter" && (
              <div className="absolute inset-0 bg-[var(--panel)]">
                <Filters
                  filters={filters}
                  onChange={setFilters}
                  shown={rows.length}
                />
              </div>
            )}
          </div>
          <nav
            aria-label="Panel"
            className="grid h-14 shrink-0 grid-cols-4 border-t border-[var(--line)] bg-[var(--panel)]"
          >
            {(
              [
                {
                  id: "map",
                  label: "Peta",
                  icon: <MapTrifold size={18} aria-hidden="true" />,
                },
                {
                  id: "table",
                  label: "Tabel",
                  icon: <Table size={18} aria-hidden="true" />,
                },
                {
                  id: "detail",
                  label: "Detail",
                  icon: <ChartBar size={18} aria-hidden="true" />,
                },
                {
                  id: "filter",
                  label: "Saring",
                  icon: <Funnel size={18} aria-hidden="true" />,
                },
              ] as const
            ).map((t) => (
              <button
                key={t.id}
                type="button"
                aria-pressed={mobileTab === t.id}
                onClick={() => setMobileTab(t.id)}
                className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-semibold ${mobileTab === t.id ? "text-[var(--accent-ink)]" : "text-[var(--muted)]"}`}
              >
                {t.icon}
                {t.label}
              </button>
            ))}
          </nav>
        </>
      )}

      <StatusBar shown={rows.length} />
      {palette && (
        <CommandPalette commands={commands} onClose={() => setPalette(false)} />
      )}
    </div>
  );
}

function useWide() {
  const [wide, setWide] = useState(
    () => typeof window !== "undefined" && window.innerWidth >= 1024,
  );
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px)");
    const sync = () => setWide(mq.matches);
    sync();
    mq.addEventListener("change", sync);
    return () => mq.removeEventListener("change", sync);
  }, []);
  return wide;
}

function TabBtn({
  on,
  onClick,
  icon,
  children,
  disabled,
  title,
}: {
  on: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  children: React.ReactNode;
  disabled?: boolean;
  title?: string;
}) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={onClick}
      disabled={disabled}
      title={title}
      className={`inline-flex h-7 items-center gap-1.5 rounded-[6px] px-2.5 text-[12px] font-semibold disabled:cursor-not-allowed disabled:opacity-45 ${
        on
          ? "bg-[var(--panel-2)] text-[var(--ink)] shadow-[0_0_0_1px_var(--line)]"
          : "text-[var(--muted)] hover:text-[var(--ink)]"
      }`}
    >
      {icon}
      {children}
    </button>
  );
}

function Toolbar({
  onPalette,
  profileOpen,
  setProfile,
}: {
  onPalette: () => void;
  profileOpen: boolean;
  setProfile: (v: boolean) => void;
}) {
  const { state, setColorMode, setDarkMode } = useApp();
  const { a } = useAssumptionActions();
  const share = useShareLink();
  const profileText = [
    { single: "lajang", couple: "pasangan", family: "keluarga" }[
      a.householdType
    ] + (a.children ? `+${a.children}` : ""),
    { budget: "hemat", moderate: "standar", comfortable: "nyaman" }[
      a.lifestyle
    ],
    { room: "kost", studio: "KPR", oneBedroom: "apt" }[a.housing],
    { motorcycle: "motor", publicTransport: "umum", rideHailing: "ojol" }[
      a.transport
    ],
    (a.customIncome ?? 0) > 0
      ? rpJt(a.customIncome ?? 0)
      : a.wageBasis === "takeHome"
        ? "take-home"
        : "UMK",
  ].join(" · ");

  return (
    <header className="relative z-30 flex h-12 shrink-0 items-center gap-2 border-b border-[var(--line)] bg-[var(--panel)] px-3">
      <div className="flex items-center gap-2 pr-1">
        <span
          aria-hidden="true"
          className="grid h-6 w-6 place-items-center rounded-[5px] bg-[var(--accent)] text-[12px] font-extrabold text-white dark:text-[#211a14]"
        >
          N
        </span>
        <span className="text-[14px] font-extrabold tracking-[-0.01em]">
          Nafkah
        </span>
        <span className="text-[var(--line-2)]" aria-hidden="true">
          /
        </span>
        <span className="text-[13px] font-semibold text-[var(--ink-2)] max-sm:hidden">
          Meja data
        </span>
        <span className="f-mono rounded-[4px] border border-[var(--line)] px-1.5 text-[10.5px] text-[var(--faint)] max-md:hidden">
          v2026.1
        </span>
      </div>
      <button
        type="button"
        onClick={onPalette}
        aria-label="Cari daerah, provinsi, atau perintah"
        className="mx-2 flex h-8 min-w-9 flex-1 items-center gap-2 rounded-[6px] border border-[var(--line)] bg-[var(--panel-2)] px-2.5 text-left text-[12.5px] text-[var(--faint)] hover:border-[var(--line-2)] max-sm:mx-1 max-sm:flex-none max-sm:justify-center max-sm:px-0 md:max-w-[420px]"
      >
        <Command size={13} aria-hidden="true" className="shrink-0" />
        <span className="truncate max-sm:hidden">
          Cari daerah, provinsi, perintah…
        </span>
        <kbd className="f-mono ml-auto rounded-[4px] border border-[var(--line)] px-1 text-[10.5px] max-md:hidden">
          Ctrl K
        </kbd>
      </button>
      <div
        role="radiogroup"
        aria-label="Warnai peta menurut"
        className="flex rounded-[6px] border border-[var(--line)] p-[2px] max-md:hidden"
      >
        {MODES.map((m) => (
          <button
            key={m.id}
            type="button"
            role="radio"
            aria-checked={state.colorMode === m.id}
            onClick={() => setColorMode(m.id)}
            className={`h-6 rounded-[4px] px-2.5 text-[12px] ${state.colorMode === m.id ? "bg-[var(--ink)] font-semibold text-[var(--panel-2)]" : "text-[var(--ink-2)] hover:bg-[var(--row-hover)]"}`}
          >
            {m.label}
          </button>
        ))}
      </div>
      <div className="relative">
        <button
          type="button"
          data-profile-trigger
          aria-expanded={profileOpen}
          onClick={() => setProfile(!profileOpen)}
          className={`inline-flex h-8 max-w-[300px] items-center gap-1.5 rounded-[6px] border px-2.5 text-[12px] ${
            profileOpen
              ? "border-[var(--accent)] bg-[var(--accent-soft)]"
              : "border-[var(--line)] hover:border-[var(--line-2)]"
          }`}
        >
          <span className="font-semibold text-[var(--muted)]">Profil</span>
          <span className="truncate font-semibold max-xl:hidden">
            {profileText}
          </span>
          <CaretDown size={11} weight="bold" aria-hidden="true" />
        </button>
        {profileOpen && <ProfilePopover onClose={() => setProfile(false)} />}
      </div>
      <button
        type="button"
        onClick={() => void share.share()}
        aria-label={share.label}
        title={share.label}
        className="grid h-8 w-8 place-items-center rounded-[6px] text-[var(--ink-2)] hover:bg-[var(--row-hover)]"
      >
        {share.status === "copied" ? (
          <Check size={15} weight="bold" aria-hidden="true" />
        ) : (
          <ShareNetwork size={15} aria-hidden="true" />
        )}
      </button>
      <button
        type="button"
        onClick={() => setDarkMode(!state.darkMode)}
        aria-label={state.darkMode ? "Tema terang" : "Tema gelap"}
        className="grid h-8 w-8 place-items-center rounded-[6px] text-[var(--ink-2)] hover:bg-[var(--row-hover)]"
      >
        {state.darkMode ? (
          <Sun size={15} aria-hidden="true" />
        ) : (
          <Moon size={15} aria-hidden="true" />
        )}
      </button>
    </header>
  );
}

function StatusBar({ shown }: { shown: number }) {
  const { state } = useApp();
  const stats = useNationalStats();
  const origin = state.originCode;
  if (!stats.ready) {
    return (
      <footer className="f-mono flex h-7 shrink-0 items-center gap-3 border-t border-[var(--line)] bg-[var(--panel)] px-3 text-[11px] text-[var(--muted)] max-lg:hidden">
        {state.dataStatus === "error" ? (
          <span className="text-[var(--danger)]">dataset gagal dimuat</span>
        ) : (
          <span>memuat dataset 2026.1…</span>
        )}
        <span className="ml-auto">UMK resmi · biaya = estimasi model</span>
      </footer>
    );
  }
  return (
    <footer className="f-mono flex h-7 shrink-0 items-center gap-3 overflow-hidden whitespace-nowrap border-t border-[var(--line)] bg-[var(--panel)] px-3 text-[11px] text-[var(--muted)] max-lg:hidden">
      <span>
        <b className="text-[var(--ink)]">{shown}</b>/{stats.total || 514} daerah
      </span>
      <span aria-hidden="true">·</span>
      <span>
        <b className="text-[var(--danger)]">{stats.below}</b> di bawah 100%
      </span>
      <span aria-hidden="true">·</span>
      <span>median {pct(stats.median, 1)}</span>
      {origin && (
        <>
          <span aria-hidden="true">·</span>
          <span className="text-[var(--accent-ink)]">
            relokasi aktif: gaji asal {origin}
          </span>
        </>
      )}
      <span className="ml-auto">
        dataset 2026.1 · 7 Sep 2026 · UMK resmi · biaya = estimasi model
      </span>
    </footer>
  );
}

function DeskTip({ hover }: { hover: { code: string; x: number; y: number } }) {
  const { state, metrics, metricsReady, regionByCode } = useApp();
  const m = metricsReady ? metrics.get(hover.code) : undefined;
  const r = regionByCode.get(hover.code);
  const theme = bandTheme(state.darkMode);
  return (
    <div
      role="status"
      className="pointer-events-none absolute z-20 rounded-[6px] border border-[var(--line-2)] bg-[var(--panel-2)] px-2.5 py-1.5 text-[12px] shadow-[0_6px_20px_rgb(0_0_0/0.15)]"
      style={{ left: hover.x + 12, top: hover.y + 12 }}
    >
      <p className="font-bold">
        {r?.name ?? hover.code}{" "}
        <span className="f-mono font-normal text-[var(--faint)]">
          {hover.code}
        </span>
      </p>
      {m ? (
        <p className="f-mono tnum mt-0.5 flex items-center gap-1.5 text-[11.5px]">
          <span
            aria-hidden="true"
            className="h-2 w-2 rounded-[2px]"
            style={{ background: theme[m.band].fill }}
          />
          {pct(m.coveragePercent, 1)} · {m.surplusOrDeficit >= 0 ? "+" : "−"}
          {rpJt(m.surplusOrDeficit)}
        </p>
      ) : (
        <p className="text-[11.5px] text-[var(--muted)]">
          {metricsReady ? "belum ada data" : "memuat…"}
        </p>
      )}
    </div>
  );
}

function MapStatus() {
  const { state, retryData, retryGeometry } = useApp();
  const err =
    state.geometryStatus === "error"
      ? "Batas wilayah gagal dimuat"
      : state.dataStatus === "error"
        ? "Data upah & biaya gagal dimuat"
        : null;
  const loading =
    state.geometryStatus === "loading" || state.dataStatus === "loading";
  if (!err && !loading) return null;
  return (
    <div
      role={err ? "alert" : "status"}
      className="f-mono absolute left-3 top-3 z-20 flex items-center gap-2 rounded-[6px] border border-[var(--line-2)] bg-[var(--panel-2)] px-2.5 py-1.5 text-[11.5px] shadow-[0_4px_14px_rgb(0_0_0/0.12)]"
    >
      {err ? (
        <>
          <span className="text-[var(--danger)]">● {err}</span>
          <button
            type="button"
            onClick={
              state.geometryStatus === "error" ? retryGeometry : retryData
            }
            className="inline-flex items-center gap-1 rounded-[4px] bg-[var(--ink)] px-2 py-0.5 font-semibold text-[var(--panel-2)]"
          >
            <ArrowClockwise size={11} weight="bold" aria-hidden="true" />
            ulangi
          </button>
        </>
      ) : (
        <>
          <span
            aria-hidden="true"
            className="h-2.5 w-2.5 animate-spin rounded-full border-[1.5px] border-[var(--accent)] border-t-transparent"
          />
          memuat {state.geometryStatus === "loading" ? "geometri" : "dataset"}…
        </>
      )}
    </div>
  );
}
