"use client";

import { useMemo } from "react";
import type { AffordabilityBand } from "@/lib/types";
import { BAND_ORDER, type RankedRegion } from "../useLabData";

/** Desk-local filter + sort model (lives in the shell, not in global state). */

export type SortKey =
  "name" | "province" | "wage" | "cost" | "coverage" | "surplus";

export interface DeskFilters {
  bands: ReadonlySet<AffordabilityBand>;
  tiers: ReadonlySet<string>;
  provinces: ReadonlySet<string>;
  query: string;
}

export const ALL_BANDS: ReadonlySet<AffordabilityBand> = new Set(BAND_ORDER);
export const ALL_TIERS: ReadonlySet<string> = new Set(["kota", "kabupaten"]);

export function emptyFilters(): DeskFilters {
  return {
    bands: ALL_BANDS,
    tiers: ALL_TIERS,
    provinces: new Set(),
    query: "",
  };
}

export function isFiltered(f: DeskFilters): boolean {
  return (
    f.bands.size < 4 ||
    f.tiers.size < 2 ||
    f.provinces.size > 0 ||
    f.query.trim() !== ""
  );
}

export function matches(r: RankedRegion, f: DeskFilters): boolean {
  if (!f.bands.has(r.metric.band)) return false;
  if (!f.tiers.has(r.tier === "kota" ? "kota" : "kabupaten")) return false;
  if (f.provinces.size && !f.provinces.has(r.province)) return false;
  const q = f.query.trim().toLowerCase();
  if (
    q &&
    !r.name.toLowerCase().includes(q) &&
    !r.province.toLowerCase().includes(q)
  )
    return false;
  return true;
}

export function useDeskRows(
  ranked: RankedRegion[],
  filters: DeskFilters,
  sort: { key: SortKey; dir: "asc" | "desc" },
) {
  return useMemo(() => {
    const visible = ranked.filter((r) => matches(r, filters));
    const value = (r: RankedRegion): number | string => {
      switch (sort.key) {
        case "name":
          return r.shortName.toLowerCase();
        case "province":
          return r.province.toLowerCase();
        case "wage":
          return r.metric.wageAmount;
        case "cost":
          return r.metric.totalMonthlyCost;
        case "surplus":
          return r.metric.surplusOrDeficit;
        default:
          return r.metric.coveragePercent;
      }
    };
    const dir = sort.dir === "asc" ? 1 : -1;
    visible.sort((a, b) => {
      const va = value(a);
      const vb = value(b);
      if (typeof va === "string" && typeof vb === "string")
        return va.localeCompare(vb, "id") * dir;
      return ((va as number) - (vb as number)) * dir;
    });
    const hidden = new Set(
      ranked.filter((r) => !matches(r, filters)).map((r) => r.code),
    );
    return { rows: visible, hidden };
  }, [ranked, filters, sort]);
}

/** "5.938.885" → "5.939" (ribu) for dense columns. */
export function rb(v: number): string {
  return Math.round(v / 1000).toLocaleString("id-ID");
}

export function signedRb(v: number): string {
  return `${v >= 0 ? "+" : "−"}${Math.round(Math.abs(v) / 1000).toLocaleString("id-ID")}`;
}
