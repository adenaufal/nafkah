"use client";

import { useMemo, useRef, useState } from "react";
import { MagnifyingGlass } from "@phosphor-icons/react";
import { useApp } from "@/state/AppContext";
import { useDialogFocus } from "@/lib/useDialogFocus";
import { useRegionSearch } from "../useRegionSearch";
import { bandTheme, pct } from "../useLabData";

export interface PaletteCommand {
  id: string;
  label: string;
  hint?: string;
  run: () => void;
}

/** ⌘K: jump to any region or run a desk command without leaving the keyboard. */
export function CommandPalette({
  commands,
  onClose,
}: {
  commands: PaletteCommand[];
  onClose: () => void;
}) {
  const { state, metrics, metricsReady, select } = useApp();
  const [q, setQ] = useState("");
  const [active, setActive] = useState(0);
  const input = useRef<HTMLInputElement>(null);
  const ref = useDialogFocus<HTMLDivElement>(true, onClose, input);
  const hits = useRegionSearch(q, 7);
  const theme = bandTheme(state.darkMode);
  const cmds = useMemo(() => {
    const t = q.trim().toLowerCase();
    return commands
      .filter((c) => !t || c.label.toLowerCase().includes(t))
      .slice(0, t ? 5 : 8);
  }, [commands, q]);
  const items = [
    ...hits.map((h) => ({ kind: "region" as const, id: h.code, h })),
    ...cmds.map((c) => ({ kind: "cmd" as const, id: c.id, c })),
  ];
  const run = (i: number) => {
    const it = items[i];
    if (!it) return;
    if (it.kind === "region") select(it.h.code);
    else it.c.run();
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center bg-black/30 px-4 pt-[12vh]"
      onClick={onClose}
      role="presentation"
    >
      <div
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-label="Palet perintah"
        onClick={(e) => e.stopPropagation()}
        className="lab-fade w-full max-w-[560px] overflow-hidden rounded-[10px] border border-[var(--line-2)] bg-[var(--panel-2)] shadow-[0_24px_60px_rgb(0_0_0/0.3)]"
      >
        <div className="flex items-center gap-2.5 border-b border-[var(--line)] px-3.5">
          <MagnifyingGlass
            size={16}
            className="text-[var(--muted)]"
            aria-hidden="true"
          />
          <input
            ref={input}
            role="combobox"
            aria-expanded="true"
            aria-controls="palette-list"
            aria-activedescendant={
              items[active] ? `pal-${items[active].id}` : undefined
            }
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setActive(0);
            }}
            onKeyDown={(e) => {
              if (e.key === "ArrowDown") {
                e.preventDefault();
                setActive((i) => Math.min(i + 1, items.length - 1));
              } else if (e.key === "ArrowUp") {
                e.preventDefault();
                setActive((i) => Math.max(i - 1, 0));
              } else if (e.key === "Enter") {
                e.preventDefault();
                run(active);
              }
            }}
            placeholder="Cari daerah, provinsi, atau perintah…"
            className="h-12 min-w-0 flex-1 bg-transparent text-[14px] outline-none placeholder:text-[var(--faint)]"
          />
          <kbd className="f-mono rounded-[4px] border border-[var(--line)] px-1.5 text-[10.5px] text-[var(--faint)]">
            esc
          </kbd>
        </div>
        <ul
          id="palette-list"
          role="listbox"
          className="lab-scroll max-h-[50vh] overflow-y-auto p-1.5"
        >
          {items.length === 0 && (
            <li className="px-3 py-6 text-center text-[13px] text-[var(--muted)]">
              Tidak ada yang cocok.
            </li>
          )}
          {items.map((it, i) => {
            const first = i === 0 || items[i - 1].kind !== it.kind;
            const m =
              it.kind === "region" && metricsReady
                ? metrics.get(it.h.code)
                : undefined;
            return (
              <li key={`${it.kind}-${it.id}`} role="presentation">
                {first && (
                  <p className="px-2.5 pb-1 pt-2 text-[10.5px] font-bold uppercase tracking-[0.1em] text-[var(--faint)]">
                    {it.kind === "region" ? "Daerah" : "Perintah"}
                  </p>
                )}
                <div
                  id={`pal-${it.id}`}
                  role="option"
                  aria-selected={i === active}
                  onMouseEnter={() => setActive(i)}
                  onMouseDown={(e) => {
                    e.preventDefault();
                    run(i);
                  }}
                  className={`flex cursor-pointer items-center gap-3 rounded-[6px] px-2.5 py-1.5 text-[13px] ${i === active ? "bg-[var(--row-sel)]" : ""}`}
                >
                  {it.kind === "region" ? (
                    <>
                      <span className="min-w-0 flex-1 truncate">
                        <b className="font-semibold">{it.h.name}</b>{" "}
                        <span className="text-[var(--muted)]">
                          · {it.h.province}
                        </span>
                      </span>
                      {m && (
                        <span className="f-mono tnum flex items-center gap-1.5 text-[12px]">
                          <span
                            aria-hidden="true"
                            className="h-2 w-2 rounded-[2px]"
                            style={{ background: theme[m.band].fill }}
                          />
                          {pct(m.coveragePercent)}
                        </span>
                      )}
                      <span className="f-mono text-[11px] text-[var(--faint)]">
                        {it.h.code}
                      </span>
                    </>
                  ) : (
                    <>
                      <span className="flex-1">{it.c.label}</span>
                      {it.c.hint && (
                        <span className="f-mono text-[11px] text-[var(--faint)]">
                          {it.c.hint}
                        </span>
                      )}
                    </>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
