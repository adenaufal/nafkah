"use client";

import { useMemo } from "react";
import {
  ArrowUpRight,
  Check,
  MapPinLine,
  PushPin,
  X,
} from "@phosphor-icons/react";
import { useApp } from "@/state/AppContext";
import { AFFORDABILITY_BANDS } from "@/lib/calculations";
import { EXPENSE_CATEGORIES } from "@/data/costs";
import { formatDate } from "@/lib/format";
import { CORRECTION_FORM_URL } from "@/lib/links";
import { recordUsage } from "@/lib/usage";
import type { ExpenseCategoryKey } from "@/lib/types";
import {
  BAND_ORDER,
  bandTheme,
  breakdownRows,
  confidenceLabel,
  pct,
  rpJt,
  useNationalStats,
  useRegionDetail,
  wageLabel,
} from "../useLabData";
import { rb, signedRb } from "./model";

function median(values: number[]): number {
  if (!values.length) return 0;
  const s = [...values].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

/** National medians per category under the active profile. */
function useCategoryMedians() {
  const stats = useNationalStats();
  return useMemo(() => {
    const out = {} as Record<ExpenseCategoryKey, number>;
    for (const c of EXPENSE_CATEGORIES)
      out[c.key] = median(stats.ranked.map((r) => r.metric.breakdown[c.key]));
    return out;
  }, [stats.ranked]);
}

export function Inspector({
  onHover,
}: {
  onHover: (code: string | null) => void;
}) {
  const { state } = useApp();
  return state.selectedCode ? (
    <RegionInspector code={state.selectedCode} />
  ) : (
    <NationalInspector onHover={onHover} />
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-[10.5px] font-bold uppercase tracking-[0.1em] text-[var(--faint)]">
      {children}
    </p>
  );
}

function RegionInspector({ code }: { code: string }) {
  const { state, pin, unpin, setOrigin, select } = useApp();
  const d = useRegionDetail(code);
  const stats = useNationalStats();
  const medians = useCategoryMedians();
  if (!d) return null;
  const m = d.metric;
  const theme = bandTheme(state.darkMode);
  const rows = breakdownRows(d);
  const rank = stats.ranked.findIndex((r) => r.code === code) + 1;
  const percentile = rank
    ? Math.round((1 - (rank - 1) / Math.max(1, stats.total - 1)) * 100)
    : 0;
  const maxCat = Math.max(
    1,
    ...rows.map((r) => Math.max(r.value, medians[r.key] ?? 0)),
  );

  return (
    <div className="lab-fade">
      <div className="flex items-start gap-2 border-b border-[var(--line)] px-4 py-3">
        <div className="min-w-0 flex-1">
          <p className="f-mono text-[11px] text-[var(--faint)]">
            {code} · {d.tier === "kota" ? "kota" : "kabupaten"}
          </p>
          <h2 className="truncate text-[17px] font-extrabold tracking-[-0.015em]">
            {d.name}
          </h2>
          <p className="truncate text-[12px] text-[var(--muted)]">
            {d.province}
          </p>
        </div>
        <button
          type="button"
          onClick={() => select(null)}
          aria-label="Tutup inspektor daerah"
          className="grid h-7 w-7 place-items-center rounded-[6px] text-[var(--muted)] hover:bg-[var(--row-hover)] hover:text-[var(--ink)]"
        >
          <X size={13} weight="bold" aria-hidden="true" />
        </button>
      </div>

      {!m || !d.hasData ? (
        <p
          role="status"
          className="m-4 rounded-[6px] border border-dashed border-[var(--line-2)] p-3 text-[12.5px] text-[var(--muted)]"
        >
          {state.dataStatus === "ready"
            ? `Belum ada data untuk ${d.name}.`
            : "Memuat data…"}
        </p>
      ) : (
        <>
          <div className="flex gap-1.5 border-b border-[var(--line)] px-4 py-2.5">
            <button
              type="button"
              onClick={() => (d.isPinned ? unpin(code) : pin(code))}
              aria-pressed={d.isPinned}
              className={`inline-flex h-7 items-center gap-1.5 rounded-[6px] border px-2.5 text-[12px] font-semibold ${
                d.isPinned
                  ? "border-[var(--accent)] bg-[var(--accent-soft)] text-[var(--accent-ink)]"
                  : "border-[var(--line-2)] hover:border-[var(--ink-2)]"
              }`}
            >
              {d.isPinned ? (
                <Check size={12} weight="bold" aria-hidden="true" />
              ) : (
                <PushPin size={12} aria-hidden="true" />
              )}
              {d.isPinned ? "Tersemat" : "Sematkan"}
              <kbd className="f-mono ml-0.5 text-[10px] text-[var(--faint)]">
                P
              </kbd>
            </button>
            <button
              type="button"
              onClick={() => setOrigin(d.isOrigin ? null : code)}
              aria-pressed={d.isOrigin}
              className={`inline-flex h-7 items-center gap-1.5 rounded-[6px] border px-2.5 text-[12px] font-semibold ${
                d.isOrigin
                  ? "border-[var(--accent)] bg-[var(--accent-soft)] text-[var(--accent-ink)]"
                  : "border-[var(--line-2)] hover:border-[var(--ink-2)]"
              }`}
            >
              <MapPinLine size={12} aria-hidden="true" />
              {d.isOrigin ? "Asal aktif" : "Jadikan asal"}
            </button>
          </div>

          <dl className="grid grid-cols-2 border-b border-[var(--line)]">
            {[
              {
                k: wageLabel(m, state.assumptions),
                v: rb(m.wageAmount),
                unit: "rb",
              },
              { k: "Biaya hidup", v: rb(m.totalMonthlyCost), unit: "rb" },
              {
                k: "Cakupan",
                v: pct(m.coveragePercent, 1),
                color: theme[m.band].ink,
              },
              {
                k: "Selisih / bln",
                v: signedRb(m.surplusOrDeficit),
                unit: "rb",
                color: m.surplusOrDeficit >= 0 ? "var(--ok)" : "var(--danger)",
              },
            ].map((x, i) => (
              <div
                key={x.k}
                className={`px-4 py-2.5 ${i % 2 === 0 ? "border-r border-[var(--line)]" : ""} ${i < 2 ? "border-b border-[var(--line)]" : ""}`}
              >
                <dt className="truncate text-[11px] text-[var(--muted)]">
                  {x.k}
                </dt>
                <dd
                  className="f-mono tnum mt-0.5 text-[17px] font-semibold tracking-[-0.02em]"
                  style={x.color ? { color: x.color } : undefined}
                >
                  {x.v}
                  {x.unit && (
                    <span className="ml-1 text-[11px] font-normal text-[var(--faint)]">
                      {x.unit}
                    </span>
                  )}
                </dd>
              </div>
            ))}
          </dl>
          <div className="flex items-center gap-2 border-b border-[var(--line)] px-4 py-2 text-[12px]">
            <span
              aria-hidden="true"
              className="h-2.5 w-2.5 rounded-[3px]"
              style={{ background: theme[m.band].fill }}
            />
            <b>{theme[m.band].label}</b>
            <span className="text-[var(--muted)]">{theme[m.band].range}</span>
            <span className="f-mono tnum ml-auto text-[11.5px] text-[var(--muted)]">
              #{rank}/{stats.total} · P{percentile}
            </span>
          </div>

          <section
            className="border-b border-[var(--line)] px-4 py-3"
            aria-labelledby="insp-cat"
          >
            <div className="mb-2 flex items-baseline justify-between">
              <Label>
                <span id="insp-cat">Komposisi biaya</span>
              </Label>
              <span className="flex items-center gap-1.5 text-[10.5px] text-[var(--faint)]">
                <span
                  aria-hidden="true"
                  className="h-2.5 w-px bg-[var(--ink)]"
                />{" "}
                median nasional
              </span>
            </div>
            <ul className="space-y-1.5">
              {rows.map((r) => {
                const med = medians[r.key] ?? 0;
                const delta = med ? (r.value / med - 1) * 100 : 0;
                return (
                  <li
                    key={r.key}
                    className="grid grid-cols-[96px_minmax(0,1fr)_56px] items-center gap-2 text-[11.5px]"
                  >
                    <span
                      className="truncate text-[var(--ink-2)]"
                      title={r.label}
                    >
                      {r.label
                        .replace(" / pengasuhan anak", "")
                        .replace(" / dana cadangan", "")}
                    </span>
                    <span className="relative h-3" aria-hidden="true">
                      <span
                        className="absolute inset-y-0 left-0 rounded-[2px] bg-[var(--line-2)]"
                        style={{ width: `${(r.value / maxCat) * 100}%` }}
                      />
                      {med > 0 && (
                        <span
                          className="absolute -inset-y-0.5 w-px bg-[var(--ink)]"
                          style={{ left: `${(med / maxCat) * 100}%` }}
                        />
                      )}
                    </span>
                    <span className="f-mono tnum text-right">
                      {rb(r.value)}
                      <span
                        className={`block text-[10px] ${delta > 5 ? "text-[var(--danger)]" : delta < -5 ? "text-[var(--ok)]" : "text-[var(--faint)]"}`}
                      >
                        {delta >= 0 ? "+" : "−"}
                        {Math.abs(Math.round(delta))}%
                      </span>
                    </span>
                  </li>
                );
              })}
            </ul>
          </section>

          <section
            className="border-b border-[var(--line)] px-4 py-3"
            aria-labelledby="insp-prov"
          >
            <Label>
              <span id="insp-prov">Provenance</span>
            </Label>
            <table className="mt-2 w-full text-[11px]">
              <tbody>
                {d.wageProvenance && (
                  <tr className="align-top">
                    <th
                      scope="row"
                      className="py-1 pr-2 text-left font-semibold"
                    >
                      UMK
                    </th>
                    <td className="py-1 pr-2 text-[var(--muted)]">
                      {d.wageProvenance.source}
                    </td>
                    <td className="f-mono py-1 text-right text-[10.5px]">
                      <span className="rounded-[4px] bg-[var(--row-hover)] px-1.5 py-0.5">
                        {confidenceLabel(d.wageProvenance.confidence)}
                      </span>
                    </td>
                  </tr>
                )}
                <tr className="align-top">
                  <th scope="row" className="py-1 pr-2 text-left font-semibold">
                    Biaya ×10
                  </th>
                  <td className="py-1 pr-2 text-[var(--muted)]">
                    Model Susenas + IHK BPS + harga lokal, per{" "}
                    {rows[0] ? formatDate(rows[0].provenance.asOf) : "—"}
                  </td>
                  <td className="f-mono py-1 text-right text-[10.5px]">
                    <span className="rounded-[4px] bg-[var(--row-hover)] px-1.5 py-0.5">
                      {rows[0]
                        ? confidenceLabel(rows[0].provenance.confidence)
                        : "—"}
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </section>

          {d.narrative && (
            <section className="px-4 py-3 text-[12px] leading-[1.55] text-[var(--ink-2)]">
              <Label>Konteks</Label>
              <p className="mt-1.5">{d.narrative.interpretation}</p>
              <p className="mt-2">
                <b className="text-[var(--ink)]">Sewa</b>{" "}
                {rpJt(d.narrative.rentRange.min)}–
                {rpJt(d.narrative.rentRange.max)} ·{" "}
                {d.narrative.transportContext}
              </p>
              <a
                href={CORRECTION_FORM_URL}
                target="_blank"
                rel="noreferrer"
                onClick={() => recordUsage("correction_report_opened")}
                className="mt-3 inline-flex items-center gap-1 font-semibold text-[var(--accent-ink)] hover:underline"
              >
                Laporkan angka
                <ArrowUpRight size={11} weight="bold" aria-hidden="true" />
              </a>
            </section>
          )}
        </>
      )}
    </div>
  );
}

function NationalInspector({
  onHover,
}: {
  onHover: (code: string | null) => void;
}) {
  const { state, select, retryData } = useApp();
  const stats = useNationalStats();
  const theme = bandTheme(state.darkMode);
  const bins = useMemo(() => {
    const out: { from: number; n: number; band: string }[] = [];
    for (let v = 50; v < 150; v += 5) out.push({ from: v, n: 0, band: "" });
    for (const r of stats.ranked) {
      const i = Math.min(
        out.length - 1,
        Math.max(0, Math.floor((r.metric.coveragePercent - 50) / 5)),
      );
      out[i].n++;
    }
    const b = AFFORDABILITY_BANDS;
    out.forEach((bin) => {
      const mid = bin.from + 2.5;
      bin.band =
        mid >= b.comfortableAt
          ? "comfortable"
          : mid >= b.manageableAt
            ? "manageable"
            : mid >= b.tightAt
              ? "tight"
              : "insufficient";
    });
    return out;
  }, [stats.ranked]);
  const maxN = Math.max(1, ...bins.map((b) => b.n));
  const byProvince = useMemo(() => {
    const map = new Map<string, { n: number; below: number; sum: number }>();
    for (const r of stats.ranked) {
      const p = map.get(r.province) ?? { n: 0, below: 0, sum: 0 };
      p.n++;
      p.sum += r.metric.coveragePercent;
      if (r.metric.coveragePercent < 100) p.below++;
      map.set(r.province, p);
    }
    return [...map.entries()]
      .map(([province, v]) => ({
        province,
        ...v,
        avg: v.sum / v.n,
        share: v.below / v.n,
      }))
      .sort((a, b) => b.share - a.share);
  }, [stats.ranked]);

  if (!stats.ready) {
    return (
      <div className="px-4 py-3">
        <p className="f-mono text-[11px] text-[var(--faint)]">
          ringkasan · 514 daerah
        </p>
        <h2 className="text-[17px] font-extrabold tracking-[-0.015em]">
          Indonesia
        </h2>
        {state.dataStatus === "error" ? (
          <div
            role="alert"
            className="mt-3 rounded-[6px] border border-[var(--line-2)] p-3 text-[12.5px] leading-[1.5]"
          >
            <p className="font-semibold text-[var(--danger)]">
              Dataset gagal dimuat.
            </p>
            <p className="mt-1 text-[var(--muted)]">
              Angka ringkasan tidak ditampilkan sampai data upah &amp; biaya
              tersedia.
            </p>
            <button
              type="button"
              onClick={retryData}
              className="mt-2.5 h-7 rounded-[5px] bg-[var(--ink)] px-2.5 text-[12px] font-semibold text-[var(--panel-2)]"
            >
              Muat ulang data
            </button>
          </div>
        ) : (
          <div
            className="mt-3 space-y-2"
            role="status"
            aria-label="Memuat ringkasan"
          >
            <div className="lab-skel h-10" />
            <div className="lab-skel h-20" />
            <div className="lab-skel h-32" />
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="lab-fade">
      <div className="border-b border-[var(--line)] px-4 py-3">
        <p className="f-mono text-[11px] text-[var(--faint)]">
          ringkasan · {stats.total || 514} daerah
        </p>
        <h2 className="text-[17px] font-extrabold tracking-[-0.015em]">
          Indonesia
        </h2>
        <p className="text-[12px] text-[var(--muted)]">
          Pilih baris atau wilayah untuk inspeksi.
        </p>
      </div>
      <dl className="grid grid-cols-2 border-b border-[var(--line)]">
        <div className="border-r border-[var(--line)] px-4 py-2.5">
          <dt className="text-[11px] text-[var(--muted)]">Di bawah 100%</dt>
          <dd className="f-mono tnum mt-0.5 text-[17px] font-semibold text-[var(--danger)]">
            {stats.below}
            <span className="ml-1 text-[11px] font-normal text-[var(--faint)]">
              {stats.total ? pct((stats.below / stats.total) * 100) : ""}
            </span>
          </dd>
        </div>
        <div className="px-4 py-2.5">
          <dt className="text-[11px] text-[var(--muted)]">Median cakupan</dt>
          <dd className="f-mono tnum mt-0.5 text-[17px] font-semibold">
            {pct(stats.median, 1)}
          </dd>
        </div>
      </dl>
      <section
        className="border-b border-[var(--line)] px-4 py-3"
        aria-label="Histogram cakupan"
      >
        <Label>Distribusi cakupan (bin 5%)</Label>
        <div
          className="mt-2 flex h-20 items-end gap-[2px]"
          role="img"
          aria-label="Histogram jumlah daerah per rentang cakupan"
        >
          {bins.map((bin) => (
            <span
              key={bin.from}
              title={`${bin.from}–${bin.from + 5}%: ${bin.n} daerah`}
              className="flex-1 rounded-t-[2px]"
              style={{
                height: `${(bin.n / maxN) * 100}%`,
                minHeight: bin.n ? 2 : 0,
                background: theme[bin.band as keyof typeof theme].fill,
              }}
            />
          ))}
        </div>
        <div className="f-mono tnum mt-1 flex justify-between text-[10px] text-[var(--faint)]">
          <span>50</span>
          <span>80</span>
          <span>100</span>
          <span>120</span>
          <span>150%</span>
        </div>
        <ul className="mt-2.5 grid grid-cols-2 gap-x-3 gap-y-1 text-[11.5px]">
          {BAND_ORDER.map((b) => (
            <li key={b} className="flex items-center gap-1.5">
              <span
                aria-hidden="true"
                className="h-2 w-2 rounded-[2px]"
                style={{ background: theme[b].fill }}
              />
              <span>{theme[b].label}</span>
              <span className="f-mono tnum ml-auto">{stats.counts[b]}</span>
            </li>
          ))}
        </ul>
      </section>
      <section className="px-4 py-3" aria-labelledby="insp-province">
        <Label>
          <span id="insp-province">Provinsi · % daerah di bawah 100%</span>
        </Label>
        <ul className="mt-2 space-y-1">
          {byProvince.slice(0, 12).map((p) => (
            <li
              key={p.province}
              className="grid grid-cols-[minmax(0,1fr)_64px_36px] items-center gap-2 text-[11.5px]"
            >
              <span className="truncate">{p.province}</span>
              <span
                className="h-1.5 rounded-full bg-[var(--line)]"
                aria-hidden="true"
              >
                <span
                  className="block h-full rounded-full bg-[var(--danger)]/70"
                  style={{ width: `${p.share * 100}%` }}
                />
              </span>
              <span className="f-mono tnum text-right text-[11px] text-[var(--muted)]">
                {Math.round(p.share * 100)}%
              </span>
            </li>
          ))}
        </ul>
        <p className="mt-3 text-[11px] text-[var(--faint)]">
          Terendah:{" "}
          {stats.ranked
            .slice(-3)
            .reverse()
            .map((r, i) => (
              <button
                key={r.code}
                type="button"
                onClick={() => select(r.code)}
                onMouseEnter={() => onHover(r.code)}
                onMouseLeave={() => onHover(null)}
                className="font-semibold text-[var(--ink-2)] underline decoration-[var(--line-2)] underline-offset-2 hover:text-[var(--accent-ink)]"
              >
                {r.shortName}
                {i < 2 ? ", " : ""}
              </button>
            ))}
        </p>
      </section>
    </div>
  );
}
