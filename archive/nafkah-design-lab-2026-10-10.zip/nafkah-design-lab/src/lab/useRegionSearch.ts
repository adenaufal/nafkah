"use client";

import { useMemo } from "react";
import { useApp } from "@/state/AppContext";

export interface SearchHit {
  code: string;
  name: string;
  province: string;
  tier: string;
}

/**
 * Ranked type-ahead over region names and provinces: name prefix, then word
 * prefix ("bandung" → "Kota Bandung"), then substring, then province match.
 */
export function useRegionSearch(query: string, limit = 8): SearchHit[] {
  const { state } = useApp();
  const index = useMemo(
    () =>
      state.regions.map((r) => ({
        code: r.code,
        name: r.name,
        province: r.province,
        tier: r.tier,
        n: r.name.toLowerCase(),
        p: r.province.toLowerCase(),
      })),
    [state.regions],
  );
  return useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    const scored: { hit: SearchHit; score: number }[] = [];
    for (const r of index) {
      let score = -1;
      if (r.n.startsWith(q)) score = 0;
      else if (r.n.split(/\s+/).some((w) => w.startsWith(q))) score = 1;
      else if (r.n.includes(q)) score = 2;
      else if (r.p.includes(q)) score = 3;
      if (score >= 0) {
        scored.push({
          hit: {
            code: r.code,
            name: r.name,
            province: r.province,
            tier: r.tier,
          },
          score: score * 1000 + r.n.length,
        });
      }
    }
    return scored
      .sort((a, b) => a.score - b.score)
      .slice(0, limit)
      .map((s) => s.hit);
  }, [index, query, limit]);
}
