"use client";

import { useRef, type KeyboardEvent, type ReactNode } from "react";
import type { AffordabilityBand, RegionMetrics } from "@/lib/types";
import { bandTheme, rpFull, rpJt } from "../useLabData";

/** Small caps line that opens every block. */
export function Kicker({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <p
      className={`flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-[var(--muted)] ${className}`}
    >
      {children}
    </p>
  );
}

export function SectionTitle({
  children,
  aside,
}: {
  children: ReactNode;
  aside?: ReactNode;
}) {
  return (
    <div className="mb-3 flex items-baseline justify-between gap-3 border-b border-[var(--rule)] pb-2">
      <h2 className="text-[13px] font-bold tracking-[-0.005em] text-[var(--ink)]">
        {children}
      </h2>
      {aside}
    </div>
  );
}

/** Underline-style segmented control: quiet, editorial, keyboard-friendly. */
export function Seg<T extends string>({
  label,
  value,
  options,
  onChange,
  hideLabel = false,
}: {
  label: string;
  value: T;
  options: { value: T; label: string; hint?: string }[];
  onChange: (v: T) => void;
  hideLabel?: boolean;
}) {
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  const idx = options.findIndex((o) => o.value === value);
  const onKey = (e: KeyboardEvent) => {
    if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
    e.preventDefault();
    const next =
      (idx + (e.key === "ArrowRight" ? 1 : -1) + options.length) %
      options.length;
    onChange(options[next].value);
    refs.current[next]?.focus();
  };
  const id = `seg-${label.replace(/\W+/g, "-").toLowerCase()}`;
  return (
    <div>
      <p
        id={id}
        className={
          hideLabel
            ? "sr-only"
            : "mb-2 text-[13px] font-semibold text-[var(--ink-2)]"
        }
      >
        {label}
      </p>
      <div
        role="radiogroup"
        aria-labelledby={id}
        onKeyDown={onKey}
        className="grid rounded-[10px] bg-[var(--paper-2)] p-[3px]"
        style={{
          gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))`,
        }}
      >
        {options.map((o, i) => {
          const on = o.value === value;
          return (
            <button
              key={o.value}
              ref={(el) => {
                refs.current[i] = el;
              }}
              type="button"
              role="radio"
              aria-checked={on}
              tabIndex={on ? 0 : -1}
              title={o.hint}
              onClick={() => onChange(o.value)}
              className={`h-9 min-w-0 truncate rounded-[8px] px-2 text-[13px] transition-[background,color,box-shadow] duration-150 ${
                on
                  ? "bg-[var(--paper)] font-semibold text-[var(--ink)] shadow-[0_1px_2px_rgb(0_0_0/0.08),0_0_0_1px_var(--rule)]"
                  : "font-medium text-[var(--muted)] hover:text-[var(--ink)]"
              }`}
            >
              {o.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function BandChip({
  band,
  dark,
  withRange = false,
}: {
  band: AffordabilityBand;
  dark: boolean;
  withRange?: boolean;
}) {
  const t = bandTheme(dark)[band];
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-[var(--rule)] bg-[var(--paper)] py-[3px] pl-1.5 pr-2.5 text-[12px] font-semibold text-[var(--ink)]">
      <span
        aria-hidden="true"
        className="h-2.5 w-2.5 rounded-full"
        style={{ background: t.fill }}
      />
      {t.label}
      {withRange && (
        <span className="font-normal text-[var(--muted)]">{t.range}</span>
      )}
    </span>
  );
}

const RAMP_LIGHT = [
  "#7d604b",
  "#8f735d",
  "#a08670",
  "#b09a85",
  "#bfac98",
  "#cdbcaa",
  "#d8cab9",
  "#e1d5c7",
  "#e8ded2",
  "#eee6dc",
];
const RAMP_DARK = [
  "#e3d2c0",
  "#d2bfac",
  "#c0ad99",
  "#ad9a87",
  "#9a8775",
  "#867464",
  "#736354",
  "#615346",
  "#51463b",
  "#453b32",
];

/**
 * Budget bar: stacked cost categories against a wage marker. The gap is the
 * story — hatched green when the wage leaves something over, hatched red where
 * costs run past the wage.
 */
export function BudgetBar({
  metric,
  rows,
  dark,
  wageText,
  highlight,
  compact = false,
}: {
  metric: RegionMetrics;
  rows: { key: string; value: number; label: string }[];
  dark: boolean;
  wageText: string;
  highlight?: string | null;
  compact?: boolean;
}) {
  const wage = metric.wageAmount;
  const cost = metric.totalMonthlyCost;
  const max = Math.max(wage, cost) * 1.04 || 1;
  const wagePct = (wage / max) * 100;
  const costPct = (cost / max) * 100;
  const ramp = dark ? RAMP_DARK : RAMP_LIGHT;
  const surplus = wage >= cost;
  let x = 0;
  const h = compact ? 10 : 18;
  return (
    <div className={compact ? "pt-4" : "pt-7"}>
      <div className="relative" style={{ height: h }}>
        <div className="absolute inset-0 overflow-hidden rounded-[3px] bg-[var(--paper-2)]">
          {rows.map((r, i) => {
            const w = (r.value / max) * 100;
            const left = x;
            x += w;
            return (
              <span
                key={r.key}
                title={`${r.label}: ${rpFull(r.value)}`}
                className="absolute inset-y-0 border-r border-[var(--paper)] transition-colors duration-150"
                style={{
                  left: `${left}%`,
                  width: `${w}%`,
                  background:
                    highlight === r.key
                      ? "var(--accent)"
                      : ramp[Math.min(i, ramp.length - 1)],
                }}
              />
            );
          })}
          <span
            aria-hidden="true"
            className={`absolute inset-y-0 ${surplus ? "lab-hatch-ok" : "lab-hatch-bad"}`}
            style={{
              left: `${Math.min(wagePct, costPct)}%`,
              width: `${Math.abs(wagePct - costPct)}%`,
            }}
          />
        </div>
        {/* Wage marker */}
        <span
          aria-hidden="true"
          className="absolute w-[2px] rounded-full bg-[var(--ink)]"
          style={{ left: `calc(${wagePct}% - 1px)`, top: -6, bottom: -6 }}
        />
        <span
          className={`absolute whitespace-nowrap text-[11.5px] font-semibold text-[var(--ink)] ${compact ? "-top-[18px]" : "-top-[26px]"}`}
          style={
            wagePct > 60
              ? { right: `${100 - wagePct}%`, transform: "translateX(1px)" }
              : { left: `${wagePct}%`, transform: "translateX(-1px)" }
          }
        >
          {wageText}
        </span>
      </div>
      {!compact && (
        <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-1.5 text-[12.5px] text-[var(--ink-2)]">
          <span className="inline-flex items-center gap-1.5">
            <span
              aria-hidden="true"
              className="h-2.5 w-3.5 rounded-[2px]"
              style={{ background: ramp[2] }}
            />
            Biaya hidup{" "}
            <b className="tnum font-semibold text-[var(--ink)]">
              {rpFull(cost)}
            </b>
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span
              aria-hidden="true"
              className={`h-2.5 w-3.5 rounded-[2px] ${surplus ? "lab-hatch-ok" : "lab-hatch-bad"}`}
            />
            {surplus ? "Sisa" : "Kurang"}{" "}
            <b
              className={`tnum font-semibold ${surplus ? "text-[var(--ok)]" : "text-[var(--danger)]"}`}
            >
              {rpFull(Math.abs(wage - cost))}
            </b>
            <span className="text-[var(--muted)]">/bulan</span>
          </span>
        </div>
      )}
      <p className="sr-only">
        {wageText}. Biaya hidup {rpJt(cost)}. {surplus ? "Sisa" : "Kurang"}{" "}
        {rpJt(Math.abs(wage - cost))} per bulan.
      </p>
    </div>
  );
}

export function IconButton({
  label,
  onClick,
  children,
  pressed,
  className = "",
}: {
  label: string;
  onClick: () => void;
  children: ReactNode;
  pressed?: boolean;
  className?: string;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      aria-pressed={pressed}
      onClick={onClick}
      className={`grid h-9 w-9 shrink-0 place-items-center rounded-[9px] text-[var(--ink-2)] transition-colors hover:bg-[var(--paper-2)] hover:text-[var(--ink)] ${className}`}
    >
      {children}
    </button>
  );
}
