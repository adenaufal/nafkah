"use client";

import { useState } from "react";
import {
  ArrowLeft,
  ArrowUpRight,
  Check,
  MapPinLine,
  Plus,
  ShareNetwork,
} from "@phosphor-icons/react";
import { useApp } from "@/state/AppContext";
import { formatDate } from "@/lib/format";
import { CORRECTION_FORM_URL } from "@/lib/links";
import { recordUsage } from "@/lib/usage";
import { useShareLink } from "../actions";
import {
  bandTheme,
  breakdownRows,
  confidenceLabel,
  pct,
  rpFull,
  rpJt,
  useNationalStats,
  useRegionDetail,
} from "../useLabData";
import { DotStrip } from "./DotStrip";
import { BandChip, BudgetBar, Kicker, SectionTitle } from "./parts";

export function RegionStory({
  code,
  onBack,
  onEditProfile,
  onHover,
}: {
  code: string;
  onBack: () => void;
  onEditProfile: () => void;
  onHover: (code: string | null) => void;
}) {
  const { state, pin, unpin, setOrigin, select } = useApp();
  const d = useRegionDetail(code);
  const stats = useNationalStats();
  const share = useShareLink();
  const [hl, setHl] = useState<string | null>(null);
  if (!d) return null;
  const theme = bandTheme(state.darkMode);
  const m = d.metric;
  const rows = breakdownRows(d);
  const rank = stats.ranked.findIndex((r) => r.code === code) + 1;
  const subject =
    m?.wageSource === "custom"
      ? "Gajimu"
      : m?.wageSource === "origin"
        ? `UMK ${d.originRegion?.name ?? "kota asal"}`
        : "UMK";
  const wageText =
    m?.wageSource === "custom"
      ? `Gajimu ${rpJt(m.wageAmount)}`
      : m?.wageSource === "origin"
        ? `Gaji asal ${rpJt(m?.wageAmount ?? 0)}`
        : `UMK ${rpJt(m?.wageAmount ?? 0)}`;

  // One provenance line when every category shares source class + date.
  const provKinds = new Map<string, number>();
  rows.forEach((r) => {
    const k = `${r.provenance.confidence}|${r.provenance.asOf}`;
    provKinds.set(k, (provKinds.get(k) ?? 0) + 1);
  });
  const uniformProv = provKinds.size === 1 ? rows[0]?.provenance : null;

  return (
    <article className="lab-rise" aria-labelledby="atlas-region-name">
      <div className="sticky top-0 z-10 -mx-8 -mt-7 mb-6 flex items-center gap-2 border-b max-md:-mt-6 border-[var(--rule)] bg-[var(--paper)]/95 px-6 py-2.5 backdrop-blur max-md:-mx-5 max-md:px-3">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex h-9 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-[9px] px-2.5 text-[13px] font-semibold text-[var(--ink-2)] hover:bg-[var(--paper-2)] hover:text-[var(--ink)]"
        >
          <ArrowLeft size={15} weight="bold" aria-hidden="true" />
          Semua daerah
        </button>
        <div className="ml-auto flex items-center gap-1.5">
          {m && (
            <button
              type="button"
              onClick={() => (d.isPinned ? unpin(code) : pin(code))}
              aria-pressed={d.isPinned}
              className={`inline-flex h-9 items-center gap-1.5 whitespace-nowrap rounded-[9px] border px-3 text-[13px] font-semibold transition-colors ${
                d.isPinned
                  ? "border-[var(--ink)] bg-[var(--ink)] text-[var(--paper)]"
                  : "border-[var(--rule-2)] text-[var(--ink)] hover:border-[var(--ink)]"
              }`}
            >
              {d.isPinned ? (
                <Check size={14} weight="bold" aria-hidden="true" />
              ) : (
                <Plus size={14} weight="bold" aria-hidden="true" />
              )}
              {d.isPinned ? "Dibandingkan" : "Bandingkan"}
            </button>
          )}
          {d.wage && (
            <button
              type="button"
              onClick={() => setOrigin(d.isOrigin ? null : code)}
              aria-pressed={d.isOrigin}
              title="Pakai UMK daerah ini sebagai gaji saat melihat biaya daerah lain"
              className={`inline-flex h-9 items-center gap-1.5 whitespace-nowrap rounded-[9px] px-2.5 text-[13px] font-semibold transition-colors ${
                d.isOrigin
                  ? "bg-[var(--accent-soft)] text-[var(--accent-ink)]"
                  : "text-[var(--ink-2)] hover:bg-[var(--paper-2)]"
              }`}
            >
              <MapPinLine size={15} weight="bold" aria-hidden="true" />
              <span className="max-[400px]:sr-only">
                {d.isOrigin ? "Asal ✓" : "Kota asal"}
              </span>
            </button>
          )}
          <button
            type="button"
            onClick={() => void share.share()}
            aria-label={share.label}
            title={share.label}
            className="grid h-9 w-9 place-items-center rounded-[9px] text-[var(--ink-2)] hover:bg-[var(--paper-2)]"
          >
            {share.status === "copied" ? (
              <Check size={16} weight="bold" aria-hidden="true" />
            ) : (
              <ShareNetwork size={16} aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      <Kicker>
        {d.province}
        <span aria-hidden="true">·</span>
        {d.tier === "kota" ? "Kota" : "Kabupaten"}
        <span aria-hidden="true">·</span>
        <span className="tnum normal-case tracking-normal">{code}</span>
      </Kicker>
      <h1
        id="atlas-region-name"
        className="f-display text-balance mt-2 text-[clamp(30px,3vw,42px)] font-[580] leading-[1.04] tracking-[-0.018em]"
      >
        {d.name}
      </h1>

      {state.dataStatus !== "ready" ? (
        <div
          className="mt-6 space-y-3"
          role="status"
          aria-label="Memuat data daerah"
        >
          <div className="lab-skel h-6 w-[85%]" />
          <div className="lab-skel h-6 w-[60%]" />
          <div className="lab-skel mt-6 h-5 w-full" />
        </div>
      ) : !m || !d.hasData ? (
        <div
          role="status"
          className="mt-6 rounded-[12px] border border-dashed border-[var(--rule-2)] p-5 text-[14px] leading-[1.6]"
        >
          <p className="font-semibold">Belum ada data untuk {d.name}.</p>
          <p className="mt-1 text-[var(--ink-2)]">
            Batas wilayahnya ada di peta, tetapi catatan upah atau biayanya
            belum masuk dataset. Daerah seperti ini tampil berarsir.
          </p>
        </div>
      ) : (
        <>
          <p className="f-display text-pretty mt-5 text-[21px] leading-[1.38] text-[var(--ink)]">
            {m.surplusOrDeficit >= 0 ? (
              <>
                {subject} menutup{" "}
                <b
                  className="tnum font-[620]"
                  style={{ color: theme[m.band].ink }}
                >
                  {pct(m.coveragePercent)}
                </b>{" "}
                biaya hidup bulanan dan menyisakan{" "}
                <b className="tnum font-[620] text-[var(--ok)]">
                  {rpJt(m.surplusOrDeficit)}
                </b>
                .
              </>
            ) : (
              <>
                {subject} hanya menutup{" "}
                <b
                  className="tnum font-[620]"
                  style={{ color: theme[m.band].ink }}
                >
                  {pct(m.coveragePercent)}
                </b>{" "}
                biaya hidup bulanan — kurang{" "}
                <b className="tnum font-[620] text-[var(--danger)]">
                  {rpJt(-m.surplusOrDeficit)}
                </b>{" "}
                setiap bulan.
              </>
            )}
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <BandChip band={m.band} dark={state.darkMode} withRange />
            {rank > 0 && (
              <span className="tnum text-[12.5px] text-[var(--muted)]">
                Peringkat {rank} dari {stats.total}
              </span>
            )}
          </div>

          <section aria-label="Upah dibandingkan biaya hidup" className="mt-6">
            <BudgetBar
              metric={m}
              rows={rows}
              dark={state.darkMode}
              wageText={wageText}
              highlight={hl}
            />
          </section>

          {m.wageSource === "region" && (
            <p className="mt-4 text-[12.5px] leading-[1.55] text-[var(--muted)]">
              UMK adalah lantai upah resmi, bukan gaji rata-rata.{" "}
              <button
                type="button"
                onClick={onEditProfile}
                className="font-semibold text-[var(--accent-ink)] underline decoration-[var(--rule-2)] underline-offset-2"
              >
                Hitung dengan gajimu
              </button>
            </p>
          )}
          {state.originCode && d.originRegion && (
            <p className="mt-4 rounded-[10px] bg-[var(--accent-soft)] px-3.5 py-2.5 text-[13px] leading-[1.5]">
              <b>Mode pindah kota.</b> Gaji dari {d.originRegion.name}, biaya
              dari {d.name}.{" "}
              <button
                type="button"
                onClick={() => setOrigin(null)}
                className="font-semibold underline underline-offset-2"
              >
                Matikan
              </button>
            </p>
          )}

          <section className="mt-9" aria-labelledby="atlas-cat">
            <SectionTitle
              aside={
                <span className="text-[12px] text-[var(--muted)]">
                  per bulan
                </span>
              }
            >
              <span id="atlas-cat">Ke mana uangnya pergi</span>
            </SectionTitle>
            <ul onMouseLeave={() => setHl(null)}>
              {rows.map((r) => (
                <li
                  key={r.key}
                  onMouseEnter={() => setHl(r.key)}
                  className="grid grid-cols-[minmax(0,1fr)_auto_44px] items-center gap-3 border-b border-[var(--rule)] py-2 last:border-0"
                >
                  <span className="min-w-0">
                    <span className="block truncate text-[14px]">
                      {r.label}
                    </span>
                    <span className="mt-1 block h-[3px] rounded-full bg-[var(--paper-2)]">
                      <span
                        className="block h-full rounded-full transition-colors"
                        style={{
                          width: `${Math.max(2, r.share * 100 * 2.2)}%`,
                          maxWidth: "100%",
                          background:
                            hl === r.key ? "var(--accent)" : "var(--rule-2)",
                        }}
                      />
                    </span>
                  </span>
                  <span className="tnum text-[14px] font-semibold">
                    {rpFull(r.value)}
                  </span>
                  <span className="tnum text-right text-[12.5px] text-[var(--muted)]">
                    {pct(r.share * 100)}
                  </span>
                </li>
              ))}
            </ul>
            {uniformProv && (
              <p className="mt-2 text-[12px] text-[var(--muted)]">
                Semua kategori:{" "}
                {confidenceLabel(uniformProv.confidence).toLowerCase()} model,
                per {formatDate(uniformProv.asOf)}.
              </p>
            )}
          </section>

          {d.narrative && (
            <section className="mt-9" aria-labelledby="atlas-note">
              <SectionTitle>
                <span id="atlas-note">Catatan daerah</span>
              </SectionTitle>
              <blockquote className="f-display text-pretty border-l-2 border-[var(--accent)] pl-4 text-[17px] leading-[1.55] text-[var(--ink-2)]">
                {d.narrative.interpretation}
              </blockquote>
              <dl className="mt-5 grid grid-cols-2 gap-4 text-[13px] leading-[1.5]">
                <div>
                  <dt className="font-semibold text-[var(--ink)]">
                    Sewa tipikal
                  </dt>
                  <dd className="tnum mt-0.5 text-[15px] font-semibold">
                    {rpJt(d.narrative.rentRange.min)} –{" "}
                    {rpJt(d.narrative.rentRange.max)}
                  </dd>
                  <dd className="mt-1 text-[var(--muted)]">
                    {d.narrative.rentRange.note}
                  </dd>
                </div>
                <div>
                  <dt className="font-semibold text-[var(--ink)]">
                    Transportasi
                  </dt>
                  <dd className="mt-0.5 text-[var(--muted)]">
                    {d.narrative.transportContext}
                  </dd>
                </div>
              </dl>
            </section>
          )}

          {stats.ready && (
            <section className="mt-9" aria-labelledby="atlas-pos">
              <SectionTitle
                aside={
                  <span className="tnum text-[12px] text-[var(--muted)]">
                    ▼ median {pct(stats.median, 1)}
                  </span>
                }
              >
                <span id="atlas-pos">
                  Posisinya di antara {stats.total} daerah
                </span>
              </SectionTitle>
              <DotStrip
                ranked={stats.ranked}
                dark={state.darkMode}
                median={stats.median}
                focusCode={code}
                onHover={onHover}
                onSelect={select}
                height={84}
              />
            </section>
          )}

          <details className="group mt-9 border-t border-[var(--rule)] pt-3">
            <summary className="flex cursor-pointer list-none items-center justify-between py-1 text-[13px] font-bold">
              Sumber &amp; tanggal data ({rows.length + 1} angka)
              <span
                aria-hidden="true"
                className="text-[var(--muted)] transition-transform group-open:rotate-45"
              >
                +
              </span>
            </summary>
            <table className="mt-2 w-full text-left text-[12px] leading-[1.45]">
              <thead className="text-[var(--muted)]">
                <tr>
                  <th scope="col" className="py-1.5 pr-2 font-medium">
                    Angka
                  </th>
                  <th scope="col" className="py-1.5 pr-2 font-medium">
                    Sumber
                  </th>
                  <th scope="col" className="py-1.5 font-medium">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody>
                {d.wageProvenance && (
                  <tr className="border-t border-[var(--rule)] align-top">
                    <th scope="row" className="py-2 pr-2 font-medium">
                      UMK {d.wageProvenance.year}
                    </th>
                    <td className="py-2 pr-2 text-[var(--ink-2)]">
                      {d.wageProvenance.source}
                    </td>
                    <td className="py-2 whitespace-nowrap">
                      {confidenceLabel(d.wageProvenance.confidence)}
                    </td>
                  </tr>
                )}
                {rows.map((r) => (
                  <tr
                    key={r.key}
                    className="border-t border-[var(--rule)] align-top"
                  >
                    <th scope="row" className="py-2 pr-2 font-medium">
                      {r.label}
                    </th>
                    <td className="py-2 pr-2 text-[var(--ink-2)]">
                      {r.provenance.source}
                    </td>
                    <td className="py-2 whitespace-nowrap">
                      {confidenceLabel(r.provenance.confidence)}
                      <span className="block text-[var(--muted)]">
                        {r.provenance.asOf.slice(0, 7)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </details>

          <div className="mt-6 flex items-center justify-between gap-4 rounded-[12px] border border-[var(--rule)] px-4 py-3">
            <p className="text-[12.5px] leading-[1.5] text-[var(--muted)]">
              Angka meleset? Laporan diperiksa manual, tidak mengubah data
              otomatis.
            </p>
            <a
              href={CORRECTION_FORM_URL}
              target="_blank"
              rel="noreferrer"
              onClick={() => recordUsage("correction_report_opened")}
              className="inline-flex shrink-0 items-center gap-1 text-[13px] font-semibold text-[var(--accent-ink)] hover:underline"
            >
              Laporkan
              <ArrowUpRight size={13} weight="bold" aria-hidden="true" />
            </a>
          </div>
        </>
      )}
    </article>
  );
}
