"use client";

import { DownloadSimple, X } from "@phosphor-icons/react";
import { useApp } from "@/state/AppContext";
import { EXPENSE_CATEGORIES } from "@/data/costs";
import { useEffect, useRef } from "react";
import { useAssumptionActions } from "../actions";
import { useComparison } from "../useComparison";
import { bandTheme, pct, rpFull, rpJt, wageLabel } from "../useLabData";
import { BudgetBar } from "./parts";

/**
 * Side-by-side reading of pinned regions. Rises over the lower part of the
 * map only, so the rail and the map context stay in view.
 */
export function CompareSheet({ onClose }: { onClose: () => void }) {
  const { state, unpin, select } = useApp();
  const { summary } = useAssumptionActions();
  const { items, exportCsv, exportStatus } = useComparison();
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    ref.current
      ?.querySelector<HTMLElement>("h2")
      ?.focus({ preventScroll: true });
  }, []);
  const theme = bandTheme(state.darkMode);
  const cols = `184px repeat(${items.length}, minmax(176px, 1fr))`;

  const maxByCat = Object.fromEntries(
    EXPENSE_CATEGORIES.map((c) => [
      c.key,
      Math.max(...items.map((i) => i.metric.breakdown[c.key])),
    ]),
  );

  return (
    <section
      ref={ref}
      aria-label="Perbandingan daerah"
      className="lab-rise absolute inset-x-3 bottom-3 z-30 flex max-h-[min(640px,calc(100%-24px))] flex-col overflow-hidden rounded-[16px] border border-[var(--rule)] bg-[var(--paper)] shadow-[var(--shadow)] md:inset-x-5 md:bottom-5"
    >
      <header className="flex items-center gap-3 border-b border-[var(--rule)] px-5 py-3">
        <div className="min-w-0">
          <h2
            tabIndex={-1}
            style={{ outline: "none" }}
            className="f-display text-[20px] font-[580] leading-tight"
          >
            Perbandingan {items.length} daerah
          </h2>
          <p className="truncate text-[12.5px] text-[var(--muted)]">
            Profil: {summary}
          </p>
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          <button
            type="button"
            onClick={exportCsv}
            className="inline-flex h-9 items-center gap-1.5 rounded-[9px] border border-[var(--rule-2)] px-3 text-[13px] font-semibold hover:border-[var(--ink)]"
          >
            <DownloadSimple size={15} aria-hidden="true" />
            {exportStatus === "done" ? "CSV diunduh" : "Ekspor CSV"}
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup perbandingan"
            className="grid h-9 w-9 place-items-center rounded-[9px] hover:bg-[var(--paper-2)]"
          >
            <X size={16} weight="bold" aria-hidden="true" />
          </button>
        </div>
      </header>
      {exportStatus === "error" && (
        <p
          role="alert"
          className="border-b border-[var(--rule)] bg-[var(--accent-soft)] px-5 py-2 text-[12.5px]"
        >
          CSV belum bisa disimpan di browser ini. Coba lagi, atau salin tautan
          lewat Bagikan.
        </p>
      )}

      <div className="lab-scroll min-h-0 flex-1 overflow-auto">
        <div
          className="grid text-[13.5px]"
          style={{
            gridTemplateColumns: cols,
            minWidth: 184 + items.length * 176,
          }}
          role="table"
          aria-label="Tabel perbandingan"
        >
          <div role="row" className="contents">
            <div
              role="columnheader"
              className="sticky left-0 z-[1] bg-[var(--paper)] px-5 py-4"
            />
            {items.map(({ code, region, metric }) => (
              <div
                role="columnheader"
                key={code}
                className="border-l border-[var(--rule)] px-4 py-4"
              >
                <div className="flex items-start gap-2">
                  <button
                    type="button"
                    onClick={() => select(code)}
                    className="min-w-0 flex-1 text-left"
                  >
                    <span className="f-display block truncate text-[18px] font-[580] leading-tight hover:text-[var(--accent-ink)]">
                      {region.name.replace(/^Kota /, "")}
                    </span>
                    <span className="block truncate text-[12px] text-[var(--muted)]">
                      {region.tier === "kota" ? "Kota · " : ""}
                      {region.province}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => unpin(code)}
                    aria-label={`Keluarkan ${region.name} dari perbandingan`}
                    className="grid h-7 w-7 shrink-0 place-items-center rounded-[7px] text-[var(--muted)] hover:bg-[var(--paper-2)] hover:text-[var(--ink)]"
                  >
                    <X size={13} weight="bold" aria-hidden="true" />
                  </button>
                </div>
                <p
                  className="f-display tnum mt-3 text-[34px] font-[560] leading-none"
                  style={{ color: theme[metric.band].ink }}
                >
                  {pct(metric.coveragePercent)}
                </p>
                <p className="mt-1.5 flex items-center gap-1.5 text-[12.5px] text-[var(--ink-2)]">
                  <span
                    aria-hidden="true"
                    className="h-2 w-2 rounded-full"
                    style={{ background: theme[metric.band].fill }}
                  />
                  {theme[metric.band].label} ·{" "}
                  <span
                    className={`tnum font-semibold ${metric.surplusOrDeficit >= 0 ? "text-[var(--ok)]" : "text-[var(--danger)]"}`}
                  >
                    {metric.surplusOrDeficit >= 0 ? "+" : "−"}
                    {rpJt(metric.surplusOrDeficit)}
                  </span>
                </p>
                <BudgetBar
                  compact
                  metric={metric}
                  dark={state.darkMode}
                  wageText={rpJt(metric.wageAmount)}
                  rows={EXPENSE_CATEGORIES.map((c) => ({
                    key: c.key,
                    label: c.label,
                    value: metric.breakdown[c.key],
                  })).sort((a, b) => b.value - a.value)}
                />
              </div>
            ))}
          </div>
          <Row
            label={
              items[0] ? wageLabel(items[0].metric, state.assumptions) : "Upah"
            }
          >
            {items.map(({ code, metric }) => (
              <Cell key={code} strong>
                {rpFull(metric.wageAmount)}
              </Cell>
            ))}
          </Row>
          <Row label="Biaya hidup / bulan">
            {items.map(({ code, metric }) => (
              <Cell key={code} strong>
                {rpFull(metric.totalMonthlyCost)}
              </Cell>
            ))}
          </Row>
          {EXPENSE_CATEGORIES.map((c) => (
            <Row key={c.key} label={c.label} muted>
              {items.map(({ code, metric }) => {
                const v = metric.breakdown[c.key];
                const top = items.length > 1 && v > 0 && v === maxByCat[c.key];
                return (
                  <Cell
                    key={code}
                    title={
                      top
                        ? "Tertinggi di antara daerah yang dibandingkan"
                        : undefined
                    }
                  >
                    <span
                      className={
                        top ? "font-semibold text-[var(--ink)]" : undefined
                      }
                    >
                      {rpFull(v)}
                    </span>
                    {top && (
                      <span
                        aria-hidden="true"
                        className="ml-1.5 inline-block h-1.5 w-1.5 rounded-full bg-[var(--accent)] align-middle"
                      />
                    )}
                  </Cell>
                );
              })}
            </Row>
          ))}
        </div>
      </div>
      <footer className="border-t border-[var(--rule)] px-5 py-2.5 text-[12px] text-[var(--muted)]">
        <span
          aria-hidden="true"
          className="mr-1 inline-block h-1.5 w-1.5 rounded-full bg-[var(--accent)] align-middle"
        />{" "}
        biaya tertinggi per kategori. Semua biaya adalah estimasi model; upah
        dari SK resmi 2026.
      </footer>
    </section>
  );
}

function Row({
  label,
  children,
  muted = false,
}: {
  label: string;
  children: React.ReactNode;
  muted?: boolean;
}) {
  return (
    <div role="row" className="contents">
      <div
        role="rowheader"
        className={`sticky left-0 z-[1] border-t border-[var(--rule)] bg-[var(--paper)] px-5 py-2 ${muted ? "text-[var(--ink-2)]" : "font-semibold"}`}
      >
        {label}
      </div>
      {children}
    </div>
  );
}

function Cell({
  children,
  strong = false,
  title,
}: {
  children: React.ReactNode;
  strong?: boolean;
  title?: string;
}) {
  return (
    <div
      role="cell"
      title={title}
      className={`tnum border-l border-t border-[var(--rule)] px-4 py-2 text-right ${strong ? "font-semibold" : "text-[var(--ink-2)]"}`}
    >
      {children}
    </div>
  );
}
