"use client";

import { forwardRef, useImperativeHandle, useRef, useState } from "react";
import { MagnifyingGlass } from "@phosphor-icons/react";
import { useApp } from "@/state/AppContext";
import { useRegionSearch } from "../useRegionSearch";
import { bandTheme, pct } from "../useLabData";

export interface SearchHandle {
  focus: () => void;
}

/** Masthead type-ahead: type → ↑/↓ → Enter opens the region story. */
export const AtlasSearch = forwardRef<SearchHandle, { compact?: boolean }>(
  function AtlasSearch({ compact = false }, ref) {
    const { state, metrics, metricsReady, select } = useApp();
    const [q, setQ] = useState("");
    const [open, setOpen] = useState(false);
    const [active, setActive] = useState(0);
    const input = useRef<HTMLInputElement>(null);
    useImperativeHandle(
      ref,
      () => ({ focus: () => input.current?.focus() }),
      [],
    );
    const hits = useRegionSearch(q, 7);
    const theme = bandTheme(state.darkMode);
    const choose = (code: string) => {
      select(code);
      setQ("");
      setOpen(false);
      input.current?.blur();
    };
    const showList = open && q.trim() !== "";

    return (
      <div className={`relative ${compact ? "w-full" : "w-[min(360px,32vw)]"}`}>
        <label htmlFor="atlas-search" className="sr-only">
          Cari kabupaten/kota atau provinsi
        </label>
        <MagnifyingGlass
          size={16}
          aria-hidden="true"
          className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted)]"
        />
        <input
          ref={input}
          id="atlas-search"
          role="combobox"
          aria-expanded={showList}
          aria-controls="atlas-search-list"
          aria-autocomplete="list"
          aria-activedescendant={
            showList && hits[active]
              ? `atlas-hit-${hits[active].code}`
              : undefined
          }
          autoComplete="off"
          value={q}
          disabled={state.regions.length === 0}
          placeholder={
            state.regions.length
              ? "Cari kabupaten/kota…"
              : "Memuat daftar daerah…"
          }
          onChange={(e) => {
            setQ(e.target.value);
            setOpen(true);
            setActive(0);
          }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 120)}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setActive((i) => Math.min(i + 1, hits.length - 1));
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              setActive((i) => Math.max(i - 1, 0));
            } else if (e.key === "Enter" && hits[active]) {
              e.preventDefault();
              choose(hits[active].code);
            } else if (e.key === "Escape") {
              e.stopPropagation();
              setQ("");
              input.current?.blur();
            }
          }}
          className="h-10 w-full rounded-full border border-[var(--rule)] bg-[var(--paper-2)] pl-9 pr-12 text-[14px] text-[var(--ink)] outline-none transition-colors placeholder:text-[var(--muted)] focus:border-[var(--rule-2)] focus:bg-[var(--paper)] disabled:opacity-60"
        />
        {!compact && (
          <kbd className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 rounded-[5px] border border-[var(--rule)] bg-[var(--paper)] px-1.5 text-[11px] font-medium text-[var(--muted)]">
            /
          </kbd>
        )}
        {showList && (
          <ul
            id="atlas-search-list"
            role="listbox"
            className="lab-fade absolute left-0 right-0 top-[calc(100%+6px)] z-50 overflow-hidden rounded-[12px] border border-[var(--rule)] bg-[var(--paper)] py-1 shadow-[var(--shadow)]"
          >
            {hits.length === 0 ? (
              <li
                role="status"
                className="px-4 py-3 text-[13.5px] text-[var(--muted)]"
              >
                Tidak ada daerah yang cocok dengan “{q.trim()}”.
              </li>
            ) : (
              hits.map((h, i) => {
                const m = metricsReady ? metrics.get(h.code) : undefined;
                return (
                  <li
                    key={h.code}
                    id={`atlas-hit-${h.code}`}
                    role="option"
                    aria-selected={i === active}
                    onMouseDown={(e) => {
                      e.preventDefault();
                      choose(h.code);
                    }}
                    onMouseEnter={() => setActive(i)}
                    className={`flex cursor-pointer items-center gap-3 px-4 py-2 ${i === active ? "bg-[var(--paper-2)]" : ""}`}
                  >
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[14px] font-medium">
                        {h.name}
                      </span>
                      <span className="block truncate text-[12px] text-[var(--muted)]">
                        {h.province}
                      </span>
                    </span>
                    {m && (
                      <span className="tnum flex items-center gap-1.5 text-[13px] font-semibold">
                        <span
                          aria-hidden="true"
                          className="h-2 w-2 rounded-full"
                          style={{ background: theme[m.band].fill }}
                        />
                        {pct(m.coveragePercent)}
                      </span>
                    )}
                  </li>
                );
              })
            )}
          </ul>
        )}
      </div>
    );
  },
);
