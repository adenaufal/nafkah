"use client";

import { ArrowLeft, Minus, Plus, X } from "@phosphor-icons/react";
import { MAX_CHILDREN } from "@/state/persist";
import type {
  HouseholdType,
  HousingType,
  LifestyleLevel,
  TransportMode,
  WageBasis,
} from "@/lib/types";
import { parseRupiah, rupiahInput, useAssumptionActions } from "../actions";
import { BAND_ORDER, bandTheme, useNationalStats } from "../useLabData";
import { useApp } from "@/state/AppContext";
import { Kicker, Seg } from "./parts";

/**
 * Assumptions live in the rail, not in a modal: the map beside it stays
 * fully visible and recolours as each control changes.
 */
export function ProfileEditor({ onBack }: { onBack: () => void }) {
  const { state } = useApp();
  const { a, set, setHousehold, reset } = useAssumptionActions();
  const stats = useNationalStats();
  const theme = bandTheme(state.darkMode);
  const couple = a.householdType !== "single";

  return (
    <div className="lab-rise">
      <div className="sticky top-0 z-10 -mx-8 -mt-7 mb-6 border-b border-[var(--rule)] bg-[var(--paper)]/95 px-6 pb-3 pt-2.5 max-md:-mt-6 backdrop-blur max-md:-mx-5 max-md:px-3">
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex h-9 items-center gap-1.5 rounded-[9px] px-2.5 text-[13px] font-semibold text-[var(--ink-2)] hover:bg-[var(--paper-2)] hover:text-[var(--ink)]"
          >
            <ArrowLeft size={15} weight="bold" aria-hidden="true" />
            Kembali
          </button>
          <button
            type="button"
            onClick={reset}
            className="h-9 rounded-[9px] px-2.5 text-[13px] font-semibold text-[var(--muted)] hover:bg-[var(--paper-2)] hover:text-[var(--ink)]"
          >
            Kembalikan ke awal
          </button>
        </div>
        {/* Live result: the same headline number, updating as you edit. */}
        <div className="mt-2 px-2.5" aria-live="polite">
          <div
            className="flex h-2 gap-[2px] overflow-hidden rounded-full"
            aria-hidden="true"
          >
            {BAND_ORDER.map((b) => (
              <span
                key={b}
                className="h-full transition-[flex-grow] duration-300"
                style={{
                  flexGrow: stats.ready ? stats.counts[b] || 0.001 : 1,
                  background: theme[b].fill,
                }}
              />
            ))}
          </div>
          <p className="tnum mt-1.5 text-[12.5px] text-[var(--ink-2)]">
            <b className="text-[var(--ink)]">{stats.below}</b> dari{" "}
            {stats.total} daerah di bawah 100% ·{" "}
            <b className="text-[var(--ink)]">
              {stats.counts.comfortable + stats.counts.manageable}
            </b>{" "}
            cukup
          </p>
        </div>
      </div>

      <Kicker>Profil rumah tangga</Kicker>
      <h1 className="f-display mt-2 text-[30px] font-[560] leading-[1.1] tracking-[-0.012em]">
        Hitung untuk hidupmu.
      </h1>
      <p className="mt-3 text-[14.5px] leading-[1.6] text-[var(--ink-2)]">
        Setiap pilihan langsung mewarnai ulang peta di sebelah. Angka tetap di
        browsermu, kecuali kamu memilih Bagikan.
      </p>

      <div className="mt-8 space-y-7">
        <fieldset className="space-y-4">
          <legend className="mb-3 text-[13px] font-bold">
            Siapa yang dihitung
          </legend>
          <Seg<HouseholdType>
            label="Rumah tangga"
            value={a.householdType}
            onChange={setHousehold}
            options={[
              { value: "single", label: "Lajang" },
              { value: "couple", label: "Pasangan" },
              { value: "family", label: "Keluarga" },
            ]}
          />
          <div className="flex items-center justify-between gap-3">
            <span
              id="atlas-kids"
              className="text-[13px] font-semibold text-[var(--ink-2)]"
            >
              Jumlah anak
            </span>
            <div
              role="group"
              aria-labelledby="atlas-kids"
              className="flex items-center gap-1 rounded-[10px] bg-[var(--paper-2)] p-[3px]"
            >
              <button
                type="button"
                aria-label={`Kurangi jumlah anak menjadi ${a.children - 1}`}
                disabled={a.children <= 0}
                onClick={() => set("children", a.children - 1)}
                className="grid h-8 w-8 place-items-center rounded-[8px] hover:bg-[var(--paper)] disabled:opacity-35"
              >
                <Minus size={14} weight="bold" aria-hidden="true" />
              </button>
              <span
                aria-live="polite"
                className="tnum w-14 text-center text-[14px] font-semibold"
              >
                {a.children} anak
              </span>
              <button
                type="button"
                aria-label={`Tambah jumlah anak menjadi ${a.children + 1}`}
                disabled={a.children >= MAX_CHILDREN}
                onClick={() => set("children", a.children + 1)}
                className="grid h-8 w-8 place-items-center rounded-[8px] hover:bg-[var(--paper)] disabled:opacity-35"
              >
                <Plus size={14} weight="bold" aria-hidden="true" />
              </button>
            </div>
          </div>
          {couple && (
            <label className="flex items-center justify-between gap-3 text-[13px] font-semibold text-[var(--ink-2)]">
              Pasangan juga bekerja (2 upah)
              <Toggle
                checked={a.dualIncome}
                onChange={(v) => set("dualIncome", v)}
              />
            </label>
          )}
        </fieldset>

        <fieldset className="space-y-4">
          <legend className="mb-3 text-[13px] font-bold">Cara hidup</legend>
          <Seg<LifestyleLevel>
            label="Gaya hidup"
            value={a.lifestyle}
            onChange={(v) => set("lifestyle", v)}
            options={[
              { value: "budget", label: "Hemat" },
              { value: "moderate", label: "Standar" },
              { value: "comfortable", label: "Nyaman" },
            ]}
          />
          <Seg<HousingType>
            label="Hunian"
            value={a.housing}
            onChange={(v) => set("housing", v)}
            options={[
              { value: "room", label: "Rusun/kost", hint: "Menengah ke bawah" },
              { value: "studio", label: "Rumah KPR", hint: "Menengah" },
              {
                value: "oneBedroom",
                label: "Apartemen",
                hint: "Menengah ke atas",
              },
            ]}
          />
          <Seg<TransportMode>
            label="Transportasi"
            value={a.transport}
            onChange={(v) => set("transport", v)}
            options={[
              { value: "motorcycle", label: "Motor" },
              { value: "publicTransport", label: "Kend. umum" },
              { value: "rideHailing", label: "Ojol" },
            ]}
          />
          <MoneyField
            id="atlas-installment"
            label="Cicilan rumah sendiri"
            hint="Menggantikan estimasi sewa daerah."
            value={a.installmentMonthly}
            onChange={(v) => set("installmentMonthly", v)}
            placeholder="cth. 2.500.000"
          />
        </fieldset>

        <fieldset className="space-y-4">
          <legend className="mb-3 text-[13px] font-bold">Pendapatan</legend>
          <MoneyField
            id="atlas-income"
            label="Gajimu per bulan"
            hint={
              (a.customIncome ?? 0) > 0
                ? "Peta kini membandingkan gajimu dengan biaya hidup tiap daerah."
                : "Kosong = memakai UMK/UMP tiap daerah."
            }
            value={a.customIncome}
            onChange={(v) => set("customIncome", v)}
            placeholder="cth. 6.500.000"
          />
          <Seg<WageBasis>
            label="Basis upah"
            value={a.wageBasis}
            onChange={(v) => set("wageBasis", v)}
            options={[
              { value: "gross", label: "UMK kotor" },
              { value: "takeHome", label: "Est. take-home" },
            ]}
          />
          <label className="flex items-center justify-between gap-3 text-[13px] font-semibold text-[var(--ink-2)]">
            Sisihkan tabungan / dana darurat (±10%)
            <Toggle
              checked={a.includeSavings}
              onChange={(v) => set("includeSavings", v)}
            />
          </label>
        </fieldset>
      </div>

      <button
        type="button"
        onClick={onBack}
        className="mt-9 h-11 w-full rounded-[11px] bg-[var(--ink)] text-[14px] font-semibold text-[var(--paper)] hover:opacity-90"
      >
        Lihat hasilnya
      </button>
    </div>
  );
}

function Toggle({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <span className="relative inline-flex shrink-0">
      <input
        type="checkbox"
        role="switch"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="peer absolute inset-0 h-full w-full cursor-pointer opacity-0"
      />
      <span
        aria-hidden="true"
        className="h-6 w-10 rounded-full bg-[var(--rule-2)] transition-colors peer-checked:bg-[var(--accent)] peer-focus-visible:ring-2 peer-focus-visible:ring-[var(--accent)] peer-focus-visible:ring-offset-2 peer-focus-visible:ring-offset-[var(--paper)]"
      />
      <span
        aria-hidden="true"
        className="pointer-events-none absolute left-[3px] top-[3px] h-[18px] w-[18px] rounded-full bg-white shadow transition-transform peer-checked:translate-x-4"
      />
    </span>
  );
}

function MoneyField({
  id,
  label,
  hint,
  value,
  onChange,
  placeholder,
}: {
  id: string;
  label: string;
  hint: string;
  value: number | null;
  onChange: (v: number | null) => void;
  placeholder: string;
}) {
  return (
    <div>
      <label
        htmlFor={id}
        className="mb-2 block text-[13px] font-semibold text-[var(--ink-2)]"
      >
        {label}{" "}
        <span className="font-normal text-[var(--muted)]">(opsional)</span>
      </label>
      <div className="flex h-11 items-center rounded-[10px] border border-[var(--rule-2)] bg-[var(--paper)] focus-within:border-[var(--ink)]">
        <span className="pl-3 text-[14px] text-[var(--muted)]">Rp</span>
        <input
          id={id}
          inputMode="numeric"
          autoComplete="off"
          aria-describedby={`${id}-hint`}
          placeholder={placeholder}
          value={rupiahInput(value)}
          onChange={(e) => onChange(parseRupiah(e.target.value))}
          className="tnum h-full min-w-0 flex-1 bg-transparent px-2 text-[15px] outline-none placeholder:text-[var(--muted)]/60"
        />
        {value ? (
          <button
            type="button"
            onClick={() => onChange(null)}
            aria-label={`Kosongkan ${label.toLowerCase()}`}
            className="mr-1 grid h-8 w-8 place-items-center rounded-[8px] text-[var(--muted)] hover:bg-[var(--paper-2)] hover:text-[var(--ink)]"
          >
            <X size={14} weight="bold" aria-hidden="true" />
          </button>
        ) : null}
      </div>
      <p
        id={`${id}-hint`}
        className="mt-1.5 text-[12px] leading-[1.5] text-[var(--muted)]"
      >
        {hint}
      </p>
    </div>
  );
}
