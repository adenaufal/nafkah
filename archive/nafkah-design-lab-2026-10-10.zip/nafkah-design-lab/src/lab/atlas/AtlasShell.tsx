"use client";

import { useRef, useState } from "react";
import {
  ArrowClockwise,
  ArrowsIn,
  Check,
  Moon,
  Plus,
  Minus,
  ShareNetwork,
  Stack,
  Sun,
  X,
} from "@phosphor-icons/react";
import { useApp } from "@/state/AppContext";
import { AboutDrawer } from "@/components/AboutPanel";
import type { BasemapId } from "@/lib/types";
import LabMap, { type LabMapApi } from "../LabMap";
import { useGlobalKeys, useShareLink } from "../actions";
import { useComparison } from "../useComparison";
import {
  BAND_ORDER,
  bandTheme,
  pct,
  rpJt,
  useNationalStats,
} from "../useLabData";
import { AtlasSearch, type SearchHandle } from "./AtlasSearch";
import { CompareSheet } from "./CompareSheet";
import { NationalStory } from "./NationalStory";
import { ProfileEditor } from "./ProfileEditor";
import { RegionStory } from "./RegionStory";

/**
 * A · Atlas — editorial. The rail tells the story (national answer →
 * region story → profile) while the map stays the evidence beside it:
 * nothing ever covers the map with a scrim.
 */
export default function AtlasShell() {
  const { state, select, setDarkMode, setAboutOpen } = useApp();
  const [profileOpen, setProfileOpen] = useState(false);
  const [compareOpen, setCompareOpen] = useState(false);
  const [mapHover, setMapHover] = useState<{
    code: string;
    x: number;
    y: number;
  } | null>(null);
  const [listHover, setListHover] = useState<string | null>(null);
  const [api, setApi] = useState<LabMapApi | null>(null);
  const search = useRef<SearchHandle>(null);
  const railRef = useRef<HTMLDivElement>(null);
  const comparison = useComparison();

  useGlobalKeys({
    onSearch: () => search.current?.focus(),
    onEscape: () => {
      if (compareOpen) setCompareOpen(false);
      else if (profileOpen) setProfileOpen(false);
      else if (state.selectedCode) select(null);
    },
  });

  const view = profileOpen
    ? "profile"
    : state.selectedCode
      ? "region"
      : "national";
  const railKey = view === "region" ? `r-${state.selectedCode}` : view;
  const scrollTop = () => railRef.current?.scrollTo({ top: 0 });

  return (
    <div className="atlas flex h-dvh flex-col overflow-hidden">
      <Masthead
        searchRef={search}
        onMethod={() => setAboutOpen(true)}
        onTheme={() => setDarkMode(!state.darkMode)}
        dark={state.darkMode}
      />

      <div className="flex min-h-0 flex-1 max-md:flex-col-reverse">
        <aside
          ref={railRef}
          aria-label={
            view === "region"
              ? "Cerita daerah"
              : view === "profile"
                ? "Profil rumah tangga"
                : "Ringkasan nasional"
          }
          className="lab-scroll relative z-10 min-h-0 overflow-y-auto border-r border-[var(--rule)] bg-[var(--paper)] max-md:-mt-4 max-md:flex-1 max-md:rounded-t-[20px] max-md:border-r-0 max-md:border-t max-md:shadow-[0_-8px_24px_rgb(0_0_0/0.08)] md:w-[400px] md:shrink-0 xl:w-[452px]"
        >
          <div
            key={railKey}
            className="px-8 pb-10 pt-7 max-md:px-5 max-md:pt-6"
          >
            {view === "profile" ? (
              <ProfileEditor onBack={() => setProfileOpen(false)} />
            ) : view === "region" && state.selectedCode ? (
              <RegionStory
                code={state.selectedCode}
                onBack={() => {
                  select(null);
                  scrollTop();
                }}
                onEditProfile={() => {
                  setProfileOpen(true);
                  scrollTop();
                }}
                onHover={setListHover}
              />
            ) : (
              <NationalStory
                hoverCode={listHover}
                onHover={setListHover}
                onEditProfile={() => {
                  setProfileOpen(true);
                  scrollTop();
                }}
                onOpenMethod={() => setAboutOpen(true)}
              />
            )}
          </div>
        </aside>

        <main
          className="relative min-h-0 flex-1 bg-[var(--paper-2)] max-md:h-[46dvh] max-md:flex-none"
          aria-label="Peta"
        >
          <LabMap
            hoverCode={listHover ?? mapHover?.code ?? null}
            onHover={setMapHover}
            dimUnselected
            onReady={setApi}
            padding={{ bottom: compareOpen ? 380 : 0 }}
            markers={state.pinned.map((code, i) => ({
              code,
              label: String(i + 1),
            }))}
            markerClassName="lab-marker"
          />
          {mapHover && <MapTooltip hover={mapHover} />}
          <MapStatus />
          {view !== "national" && <MapKey />}
          <MapControls api={api} />

          {compareOpen && comparison.items.length >= 2 ? (
            <CompareSheet onClose={() => setCompareOpen(false)} />
          ) : (
            state.pinned.length > 0 && (
              <CompareTray
                onOpen={() => setCompareOpen(true)}
                canCompare={comparison.items.length >= 2}
              />
            )
          )}
          {state.pinMessage && (
            <p
              role="alert"
              className="lab-fade absolute left-1/2 top-4 z-30 -translate-x-1/2 rounded-full bg-[var(--ink)] px-4 py-2 text-[13px] font-medium text-[var(--paper)] shadow-[var(--shadow)]"
            >
              {state.pinMessage}
            </p>
          )}
        </main>
      </div>
      <AboutDrawer />
    </div>
  );
}

function Masthead({
  searchRef,
  onMethod,
  onTheme,
  dark,
}: {
  searchRef: React.RefObject<SearchHandle | null>;
  onMethod: () => void;
  onTheme: () => void;
  dark: boolean;
}) {
  const share = useShareLink();
  return (
    <header className="relative z-20 flex h-14 shrink-0 items-center gap-4 border-b border-[var(--rule)] bg-[var(--paper)] px-5 max-md:gap-2 max-md:px-3">
      <a
        href="/lab/atlas"
        className="flex items-center gap-2.5"
        aria-label="Nafkah, beranda"
      >
        <span
          aria-hidden="true"
          className="grid h-8 w-8 place-items-center rounded-[9px] bg-[var(--accent)] text-[15px] font-extrabold text-white dark:text-[#211a14]"
        >
          N
        </span>
        <span className="f-display text-[21px] font-[620] tracking-[-0.01em]">
          Nafkah
        </span>
      </a>
      <span
        className="hidden h-5 w-px bg-[var(--rule-2)] lg:block"
        aria-hidden="true"
      />
      <p className="hidden text-[13px] text-[var(--muted)] lg:block">
        Peta kecukupan upah · data 2026.1
      </p>
      <div className="ml-auto max-md:hidden">
        <AtlasSearch ref={searchRef} />
      </div>
      <nav
        aria-label="Utilitas"
        className="flex items-center gap-1 max-md:ml-auto"
      >
        <button
          type="button"
          onClick={onMethod}
          className="h-9 rounded-[9px] px-3 text-[13.5px] font-semibold text-[var(--ink-2)] hover:bg-[var(--paper-2)] hover:text-[var(--ink)]"
        >
          Metode
        </button>
        <button
          type="button"
          onClick={() => void share.share()}
          title={
            share.includesMoney
              ? "Tautan ikut membawa angka gaji/cicilan yang kamu isi."
              : "Salin tautan tampilan ini"
          }
          className="inline-flex h-9 items-center gap-1.5 rounded-[9px] px-3 text-[13.5px] font-semibold text-[var(--ink-2)] hover:bg-[var(--paper-2)] hover:text-[var(--ink)]"
        >
          {share.status === "copied" ? (
            <Check size={15} weight="bold" aria-hidden="true" />
          ) : (
            <ShareNetwork size={15} aria-hidden="true" />
          )}
          <span className="max-sm:sr-only" aria-live="polite">
            {share.label}
          </span>
        </button>
        <button
          type="button"
          onClick={onTheme}
          aria-label={dark ? "Pakai tema terang" : "Pakai tema gelap"}
          title={dark ? "Tema terang" : "Tema gelap"}
          className="grid h-9 w-9 place-items-center rounded-[9px] text-[var(--ink-2)] hover:bg-[var(--paper-2)] hover:text-[var(--ink)]"
        >
          {dark ? (
            <Sun size={17} aria-hidden="true" />
          ) : (
            <Moon size={17} aria-hidden="true" />
          )}
        </button>
      </nav>
    </header>
  );
}

function MapTooltip({
  hover,
}: {
  hover: { code: string; x: number; y: number };
}) {
  const { state, metrics, metricsReady, regionByCode } = useApp();
  const region = regionByCode.get(hover.code);
  const m = metricsReady ? metrics.get(hover.code) : undefined;
  const theme = bandTheme(state.darkMode);
  const flipX =
    typeof window !== "undefined" && hover.x > window.innerWidth - 760;
  return (
    <div
      role="status"
      className="pointer-events-none absolute z-20 w-[248px] rounded-[12px] border border-[var(--rule)] bg-[var(--paper)] p-3 shadow-[var(--shadow)]"
      style={{
        left: hover.x,
        top: hover.y,
        transform: `translate(${flipX ? "calc(-100% - 14px)" : "14px"}, ${hover.y > 260 ? "calc(-100% - 10px)" : "14px"})`,
      }}
    >
      <p className="truncate text-[14px] font-bold leading-tight">
        {region?.name ?? hover.code}
      </p>
      <p className="truncate text-[12px] text-[var(--muted)]">
        {region?.province}
      </p>
      {m ? (
        <div className="mt-2 flex items-end justify-between gap-2">
          <div>
            <span
              className="f-display tnum text-[26px] font-[560] leading-none"
              style={{ color: theme[m.band].ink }}
            >
              {pct(m.coveragePercent)}
            </span>
            <span className="ml-1.5 text-[12px] text-[var(--muted)]">
              tertutup
            </span>
          </div>
          <span
            className={`tnum text-[12.5px] font-semibold ${m.surplusOrDeficit >= 0 ? "text-[var(--ok)]" : "text-[var(--danger)]"}`}
          >
            {m.surplusOrDeficit >= 0 ? "+" : "−"}
            {rpJt(m.surplusOrDeficit)}/bln
          </span>
        </div>
      ) : (
        <p className="mt-2 text-[12.5px] text-[var(--muted)]">
          {metricsReady ? "Belum ada data" : "Memuat data…"}
        </p>
      )}
    </div>
  );
}

function MapKey() {
  const { state } = useApp();
  const stats = useNationalStats();
  const theme = bandTheme(state.darkMode);
  if (state.colorMode !== "coverage") return null;
  return (
    <div className="pointer-events-none absolute left-4 top-4 z-10 flex gap-3 rounded-[10px] border border-[var(--rule)] bg-[var(--paper)]/92 px-3 py-2 text-[12px] shadow-[0_1px_2px_rgb(0_0_0/0.06)] backdrop-blur max-md:hidden">
      {BAND_ORDER.map((b) => (
        <span key={b} className="flex items-center gap-1.5">
          <span
            aria-hidden="true"
            className="h-2.5 w-2.5 rounded-full"
            style={{ background: theme[b].fill }}
          />
          <span className="font-medium">{theme[b].label}</span>
          <span className="tnum text-[var(--muted)]">{stats.counts[b]}</span>
        </span>
      ))}
    </div>
  );
}

const LAYERS: { id: BasemapId; label: string }[] = [
  { id: "light", label: "Kertas" },
  { id: "satellite", label: "Satelit" },
  { id: "offline", label: "Tanpa peta dasar" },
];

function MapControls({ api }: { api: LabMapApi | null }) {
  const { state, setBasemap } = useApp();
  const [open, setOpen] = useState(false);
  const btn =
    "grid h-9 w-9 place-items-center text-[var(--ink-2)] hover:bg-[var(--paper-2)] hover:text-[var(--ink)] disabled:opacity-40";
  const current = state.basemap === "dark" ? "light" : state.basemap;
  return (
    <div className="absolute bottom-9 right-3 z-10 flex flex-col items-end gap-2">
      {open && (
        <div
          role="menu"
          aria-label="Peta dasar"
          className="lab-fade w-48 rounded-[12px] border border-[var(--rule)] bg-[var(--paper)] p-1 shadow-[var(--shadow)]"
        >
          {LAYERS.map((l) => (
            <button
              key={l.id}
              type="button"
              role="menuitemradio"
              aria-checked={current === l.id}
              onClick={() => {
                setBasemap(
                  l.id === "light" ? (state.darkMode ? "dark" : "light") : l.id,
                );
                setOpen(false);
              }}
              className="flex h-9 w-full items-center justify-between rounded-[8px] px-3 text-[13px] font-medium hover:bg-[var(--paper-2)]"
            >
              {l.label}
              {current === l.id && (
                <Check size={14} weight="bold" aria-hidden="true" />
              )}
            </button>
          ))}
        </div>
      )}
      <div className="flex flex-col overflow-hidden rounded-[11px] border border-[var(--rule)] bg-[var(--paper)] shadow-[0_1px_2px_rgb(0_0_0/0.06),0_4px_14px_rgb(0_0_0/0.08)]">
        <div className="flex flex-col max-md:hidden">
          <button
            type="button"
            className={btn}
            aria-label="Perbesar"
            onClick={() => api?.zoomIn()}
            disabled={!api}
          >
            <Plus size={15} weight="bold" aria-hidden="true" />
          </button>
          <span className="mx-2 h-px bg-[var(--rule)]" aria-hidden="true" />
          <button
            type="button"
            className={btn}
            aria-label="Perkecil"
            onClick={() => api?.zoomOut()}
            disabled={!api}
          >
            <Minus size={15} weight="bold" aria-hidden="true" />
          </button>
          <span className="mx-2 h-px bg-[var(--rule)]" aria-hidden="true" />
        </div>
        <button
          type="button"
          className={btn}
          aria-label="Tampilkan seluruh Indonesia"
          onClick={() => api?.fitIndonesia()}
          disabled={!api}
        >
          <ArrowsIn size={15} weight="bold" aria-hidden="true" />
        </button>
        <span className="mx-2 h-px bg-[var(--rule)]" aria-hidden="true" />
        <button
          type="button"
          className={btn}
          aria-label="Pilih peta dasar"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <Stack size={16} aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}

function CompareTray({
  onOpen,
  canCompare,
}: {
  onOpen: () => void;
  canCompare: boolean;
}) {
  const { state, metrics, regionByCode, unpin, select } = useApp();
  const theme = bandTheme(state.darkMode);
  return (
    <div className="lab-rise absolute bottom-5 left-1/2 z-20 flex max-w-[calc(100%-120px)] -translate-x-1/2 items-center gap-1.5 rounded-[14px] border border-[var(--rule)] bg-[var(--paper)] p-1.5 shadow-[var(--shadow)] max-md:bottom-3 max-md:left-3 max-md:max-w-[calc(100%-72px)] max-md:translate-x-0">
      <ul className="lab-scroll flex min-w-0 items-center gap-1 overflow-x-auto">
        {state.pinned.map((code, i) => {
          const m = metrics.get(code);
          const name = (regionByCode.get(code)?.name ?? code).replace(
            /^Kota /,
            "",
          );
          return (
            <li
              key={code}
              className="flex shrink-0 items-center rounded-[10px] bg-[var(--paper-2)] pl-1"
            >
              <button
                type="button"
                onClick={() => select(code)}
                className="flex items-center gap-1.5 py-1.5 pl-1.5 pr-1 text-[13px] font-medium"
              >
                <span className="grid h-[18px] w-[18px] place-items-center rounded-full bg-[var(--ink)] text-[10.5px] font-bold text-[var(--paper)]">
                  {i + 1}
                </span>
                {name}
                {m && (
                  <span
                    className="tnum text-[12px] font-semibold"
                    style={{ color: theme[m.band].ink }}
                  >
                    {pct(m.coveragePercent)}
                  </span>
                )}
              </button>
              <button
                type="button"
                onClick={() => unpin(code)}
                aria-label={`Keluarkan ${name}`}
                className="grid h-7 w-7 place-items-center rounded-[8px] text-[var(--muted)] hover:text-[var(--ink)]"
              >
                <X size={12} weight="bold" aria-hidden="true" />
              </button>
            </li>
          );
        })}
      </ul>
      <button
        type="button"
        onClick={onOpen}
        disabled={!canCompare}
        title={canCompare ? undefined : "Tambahkan satu daerah lagi"}
        className="h-9 shrink-0 rounded-[10px] bg-[var(--ink)] px-3.5 text-[13px] font-semibold text-[var(--paper)] disabled:bg-[var(--paper-3)] disabled:text-[var(--muted)]"
      >
        {canCompare ? "Bandingkan" : "+1 daerah lagi"}
      </button>
    </div>
  );
}

function MapStatus() {
  const { state, retryData, retryGeometry } = useApp();
  const items: {
    key: string;
    text: string;
    error?: boolean;
    retry?: () => void;
  }[] = [];
  if (state.geometryStatus === "loading")
    items.push({ key: "g", text: "Memuat batas wilayah…" });
  if (state.geometryStatus === "error")
    items.push({
      key: "g",
      text: "Batas wilayah gagal dimuat.",
      error: true,
      retry: retryGeometry,
    });
  if (state.dataStatus === "loading")
    items.push({ key: "d", text: "Memuat data upah & biaya…" });
  if (state.dataStatus === "error")
    items.push({
      key: "d",
      text: "Data upah & biaya gagal dimuat.",
      error: true,
      retry: retryData,
    });
  if (!items.length) return null;
  return (
    <div className="absolute left-1/2 top-4 z-30 flex -translate-x-1/2 flex-col items-center gap-2">
      {items.map((it) => (
        <div
          key={it.key}
          role={it.error ? "alert" : "status"}
          className={`flex items-center gap-2.5 rounded-full border px-4 py-2 text-[13px] font-medium shadow-[var(--shadow)] ${
            it.error
              ? "border-[var(--danger)]/40 bg-[var(--paper)] text-[var(--danger)]"
              : "border-[var(--rule)] bg-[var(--paper)] text-[var(--ink-2)]"
          }`}
        >
          {!it.error && (
            <span
              aria-hidden="true"
              className="h-3 w-3 animate-spin rounded-full border-2 border-current border-t-transparent"
            />
          )}
          {it.text}
          {it.retry && (
            <button
              type="button"
              onClick={it.retry}
              className="inline-flex items-center gap-1 rounded-full bg-[var(--danger)] px-2.5 py-0.5 text-[12px] font-semibold text-white"
            >
              <ArrowClockwise size={12} weight="bold" aria-hidden="true" />
              Coba lagi
            </button>
          )}
        </div>
      ))}
    </div>
  );
}
