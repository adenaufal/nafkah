"use client";

import { PencilSimple } from "@phosphor-icons/react";
import { useApp } from "@/state/AppContext";
import { VALUE_RAMP } from "@/lib/calculations";
import type { ColorMode } from "@/lib/types";
import { householdNoun } from "../actions";
import {
  BAND_ORDER,
  bandTheme,
  pct,
  rpJt,
  useNationalStats,
} from "../useLabData";
import { DotStrip } from "./DotStrip";
import { Kicker, Seg, SectionTitle } from "./parts";

const MODES: { value: ColorMode; label: string; hint: string }[] = [
  { value: "coverage", label: "Cakupan", hint: "Upah ÷ estimasi biaya hidup" },
  { value: "cost", label: "Biaya hidup", hint: "Estimasi rupiah per bulan" },
  { value: "wage", label: "Upah", hint: "UMK/UMP per bulan" },
];

export function NationalStory({
  hoverCode,
  onHover,
  onEditProfile,
  onOpenMethod,
}: {
  hoverCode: string | null;
  onHover: (code: string | null) => void;
  onEditProfile: () => void;
  onOpenMethod: () => void;
}) {
  const {
    state,
    regionByCode,
    select,
    setLegendFilter,
    setColorMode,
    retryData,
  } = useApp();
  const stats = useNationalStats();
  const theme = bandTheme(state.darkMode);
  const a = state.assumptions;
  const origin = state.originCode
    ? regionByCode.get(state.originCode)
    : undefined;
  const custom = (a.customIncome ?? 0) > 0;
  const subject = custom
    ? `gajimu ${rpJt(a.customIncome ?? 0)}`
    : origin
      ? `UMK ${origin.name}`
      : "upah minimum";
  const noun = householdNoun(a);

  return (
    <div className="lab-rise space-y-9">
      <header>
        <Kicker>
          <span
            aria-hidden="true"
            className="h-2 w-2 rounded-[2px] bg-[var(--accent)]"
          />
          UMK 2026 × estimasi biaya hidup
        </Kicker>
        {stats.ready ? (
          <h1 className="f-display text-balance mt-4 text-[clamp(28px,2.6vw,36px)] font-[560] leading-[1.1] tracking-[-0.012em]">
            {stats.below === 0 ? (
              <>
                Dengan profil ini, {subject} menutup biaya hidup {noun} di{" "}
                <span className="text-[var(--accent)]">
                  seluruh {stats.total}
                </span>{" "}
                daerah.
              </>
            ) : (
              <>
                Di{" "}
                <span className="tnum text-[var(--accent)]">{stats.below}</span>{" "}
                dari <span className="tnum">{stats.total}</span> daerah,{" "}
                {subject} belum menutup biaya hidup {noun}.
              </>
            )}
          </h1>
        ) : state.dataStatus === "error" ? (
          <div role="alert" className="mt-4">
            <h1 className="f-display text-[30px] font-[560] leading-[1.12] tracking-[-0.012em]">
              Data upah &amp; biaya belum bisa dimuat.
            </h1>
            <p className="mt-3 text-[14.5px] leading-[1.6] text-[var(--ink-2)]">
              Batas wilayah tetap tampil berarsir. Periksa koneksi, lalu coba
              lagi — data tersimpan di browser setelah kunjungan pertama yang
              berhasil.
            </p>
            <button
              type="button"
              onClick={retryData}
              className="mt-4 h-10 rounded-[10px] bg-[var(--ink)] px-4 text-[13.5px] font-semibold text-[var(--paper)]"
            >
              Coba lagi
            </button>
          </div>
        ) : (
          <div
            className="mt-4 space-y-2.5"
            role="status"
            aria-label="Memuat ringkasan"
          >
            <div className="lab-skel h-8 w-[92%]" />
            <div className="lab-skel h-8 w-[80%]" />
            <div className="lab-skel h-8 w-[55%]" />
          </div>
        )}
        <p className="text-pretty mt-4 text-[15px] leading-[1.6] text-[var(--ink-2)]">
          Warna peta menunjukkan berapa persen biaya hidup bulanan yang tertutup
          upah. Pilih daerah mana pun untuk membaca rinciannya.
        </p>
        <div className="mt-5 flex items-start justify-between gap-3 rounded-[12px] border border-[var(--rule)] bg-[var(--paper-2)] px-4 py-3">
          <p className="min-w-0 text-[13px] leading-[1.5] text-[var(--ink-2)]">
            <span className="font-semibold text-[var(--ink)]">Profil:</span>{" "}
            {[
              noun,
              { budget: "hemat", moderate: "standar", comfortable: "nyaman" }[
                a.lifestyle
              ],
              {
                room: "rusun/kost",
                studio: "rumah KPR",
                oneBedroom: "apartemen",
              }[a.housing],
              {
                motorcycle: "motor",
                publicTransport: "kendaraan umum",
                rideHailing: "ojol",
              }[a.transport],
              a.includeSavings ? "+tabungan" : null,
              a.wageBasis === "takeHome" ? "take-home" : null,
            ]
              .filter(Boolean)
              .join(" · ")}
          </p>
          <button
            type="button"
            onClick={onEditProfile}
            className="inline-flex shrink-0 items-center gap-1.5 rounded-[8px] px-2 py-1 text-[13px] font-semibold text-[var(--accent-ink)] hover:bg-[var(--accent-soft)]"
          >
            <PencilSimple size={14} weight="bold" aria-hidden="true" />
            Ubah
          </button>
        </div>
      </header>

      <section aria-labelledby="atlas-dist">
        <SectionTitle
          aside={
            <span className="text-[12px] text-[var(--muted)]">
              klik kelompok untuk menyaring peta
            </span>
          }
        >
          <span id="atlas-dist">Sebaran {stats.total || 514} daerah</span>
        </SectionTitle>
        <div className="mb-4">
          <Seg
            label="Warnai peta menurut"
            value={state.colorMode}
            options={MODES}
            onChange={setColorMode}
            hideLabel
          />
        </div>

        {state.colorMode === "coverage" ? (
          <>
            <div
              className="flex h-3.5 gap-[2px] overflow-hidden rounded-[3px]"
              aria-hidden="true"
            >
              {BAND_ORDER.map((band) => (
                <span
                  key={band}
                  className="h-full transition-[flex-grow,opacity] duration-300"
                  style={{
                    flexGrow: stats.ready ? stats.counts[band] : 1,
                    background: stats.ready
                      ? theme[band].fill
                      : "var(--paper-3)",
                    opacity:
                      state.legendFilter && state.legendFilter !== band
                        ? 0.25
                        : 1,
                  }}
                />
              ))}
            </div>
            <ul
              className="mt-3 grid grid-cols-4 gap-1"
              role="group"
              aria-label="Saring peta menurut kelompok"
            >
              {BAND_ORDER.map((band) => {
                const on = state.legendFilter === band;
                const off = state.legendFilter && !on;
                return (
                  <li key={band}>
                    <button
                      type="button"
                      aria-pressed={on}
                      onClick={() => setLegendFilter(on ? null : band)}
                      className={`w-full rounded-[10px] px-2 py-2 text-left transition-[background,opacity] ${
                        on
                          ? "bg-[var(--paper-2)] ring-1 ring-[var(--rule-2)]"
                          : "hover:bg-[var(--paper-2)]"
                      } ${off ? "opacity-45" : ""}`}
                    >
                      <span className="flex items-center gap-1.5 text-[12px] font-semibold text-[var(--ink-2)]">
                        <span
                          aria-hidden="true"
                          className="h-2.5 w-2.5 rounded-full"
                          style={{ background: theme[band].fill }}
                        />
                        {theme[band].label}
                      </span>
                      <span className="f-display tnum mt-1 block text-[26px] font-[520] leading-none">
                        {stats.ready ? stats.counts[band] : "–"}
                      </span>
                      <span className="tnum mt-1 block text-[11.5px] text-[var(--muted)]">
                        {theme[band].range}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </>
        ) : (
          <div>
            <div
              aria-hidden="true"
              className="h-3.5 rounded-[3px]"
              style={{
                background: `linear-gradient(to right, ${(state.darkMode ? VALUE_RAMP.dark : VALUE_RAMP.light).join(", ")})`,
              }}
            />
            <div className="tnum mt-2 flex justify-between text-[12px] text-[var(--muted)]">
              {(state.colorMode === "cost"
                ? ["Rp3 jt", "Rp5,5 jt", "Rp8 jt"]
                : ["Rp2 jt", "Rp3,5 jt", "Rp5,5 jt"]
              ).map((s) => (
                <span key={s}>{s}</span>
              ))}
            </div>
            <p className="mt-2 text-[12.5px] text-[var(--muted)]">
              {state.colorMode === "cost"
                ? "Estimasi biaya hidup bulanan untuk profil aktif."
                : "UMK/UMP 2026 per bulan (resmi)."}
            </p>
          </div>
        )}
      </section>

      <section aria-labelledby="atlas-strip">
        <SectionTitle
          aside={
            stats.ready ? (
              <span className="tnum text-[12px] text-[var(--muted)]">
                ▼ median {pct(stats.median, 1)}
              </span>
            ) : null
          }
        >
          <span id="atlas-strip">Setiap titik satu daerah</span>
        </SectionTitle>
        {stats.ready ? (
          <DotStrip
            ranked={stats.ranked}
            dark={state.darkMode}
            median={stats.median}
            hoverCode={hoverCode}
            onHover={onHover}
            onSelect={select}
          />
        ) : (
          <div className="lab-skel h-24 w-full" aria-hidden="true" />
        )}
        <p className="mt-2 text-[12.5px] leading-[1.5] text-[var(--muted)]">
          Garis tegas = 100%, titik ketika upah pas menutup biaya hidup. Arahkan
          kursor untuk menemukan daerahnya di peta.
        </p>
      </section>

      <section
        aria-labelledby="atlas-rank"
        className="grid grid-cols-2 gap-x-6"
      >
        <h2 id="atlas-rank" className="sr-only">
          Daerah dengan cakupan tertinggi dan terendah
        </h2>
        {(["top", "bottom"] as const).map((side) => {
          const list =
            side === "top"
              ? stats.ranked.slice(0, 4)
              : stats.ranked.slice(-4).reverse();
          return (
            <div key={side}>
              <p className="mb-2 border-b border-[var(--rule)] pb-2 text-[13px] font-bold">
                {side === "top" ? "Paling lega" : "Paling berat"}
              </p>
              <ol className="space-y-0.5">
                {list.map((r) => (
                  <li key={r.code}>
                    <button
                      type="button"
                      onClick={() => select(r.code)}
                      onMouseEnter={() => onHover(r.code)}
                      onMouseLeave={() => onHover(null)}
                      onFocus={() => onHover(r.code)}
                      onBlur={() => onHover(null)}
                      className="flex w-full items-baseline gap-2 rounded-[6px] py-1.5 text-left hover:bg-[var(--paper-2)]"
                    >
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[13.5px] font-medium">
                          {r.shortName}
                        </span>
                        <span className="block truncate text-[11.5px] text-[var(--muted)]">
                          {r.province}
                        </span>
                      </span>
                      <span
                        className="tnum text-[13.5px] font-semibold"
                        style={{ color: theme[r.metric.band].ink }}
                      >
                        {pct(r.metric.coveragePercent)}
                      </span>
                    </button>
                  </li>
                ))}
                {!stats.ready &&
                  [0, 1, 2, 3].map((i) => (
                    <li
                      key={i}
                      className="lab-skel my-2 h-7"
                      aria-hidden="true"
                    />
                  ))}
              </ol>
            </div>
          );
        })}
      </section>

      <footer className="border-t border-[var(--rule)] pt-4 text-[12.5px] leading-[1.6] text-[var(--muted)]">
        Biaya hidup adalah{" "}
        <b className="font-semibold text-[var(--ink-2)]">estimasi model</b> dari
        Susenas, IHK BPS, dan harga lokal — bukan survei per kabupaten. UMK
        adalah lantai upah resmi, bukan gaji rata-rata. Bukan nasihat keuangan.{" "}
        <button
          type="button"
          onClick={onOpenMethod}
          className="font-semibold text-[var(--accent-ink)] underline decoration-[var(--rule-2)] underline-offset-2 hover:decoration-[var(--accent)]"
        >
          Baca metode
        </button>
      </footer>
    </div>
  );
}
