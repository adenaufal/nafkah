/**
 * `?simulate=` switch for prototype stress tests. Patches fetch before the
 * AppProvider starts loading so loading/error states can be rendered on
 * demand. Lab-only: production never imports this module.
 *
 *   loading       geometry + data never resolve
 *   data-loading  geometry loads, data never resolves
 *   data-error    data files answer 503
 *   geo-error     boundary file answers 503
 */
export function applySimulation(mode: string | null): void {
  if (!mode || typeof window === "undefined") return;
  // SAFETY: private flag on window so React StrictMode double-init patches once.
  const w = window as unknown as { __labFetch?: boolean };
  if (w.__labFetch) return;
  w.__labFetch = true;
  const real = window.fetch.bind(window);
  window.fetch = (input: RequestInfo | URL, init?: RequestInit) => {
    const url =
      typeof input === "string"
        ? input
        : input instanceof URL
          ? input.href
          : input.url;
    const isData = url.includes("/data/v2026.1/");
    const isGeo = url.includes("regions.topojson");
    const hang = () => new Promise<Response>(() => {});
    const fail = () => Promise.resolve(new Response("", { status: 503 }));
    if (mode === "loading" && (isData || isGeo)) return hang();
    if (mode === "data-loading" && isData) return hang();
    if (mode === "data-error" && isData) return fail();
    if (mode === "geo-error" && isGeo) return fail();
    return real(input, init);
  };
}
