"use client";

import { useEffect, useRef, useState } from "react";
import { useApp } from "@/state/AppContext";
import { buildShareUrl } from "@/state/share";
import { recordUsage } from "@/lib/usage";
import { assumptionSummary } from "@/lib/profile";
import type { Assumptions, HouseholdType } from "@/lib/types";

/** Assumption setters shared by every variant's own controls. */
export function useAssumptionActions() {
  const { state, setAssumptions, resetAssumptions } = useApp();
  const a = state.assumptions;
  const set = <K extends keyof Assumptions>(k: K, v: Assumptions[K]) =>
    setAssumptions({ ...a, [k]: v });
  // Same preset as production: picking "Keluarga" fills 2 children if unset.
  const setHousehold = (v: HouseholdType) =>
    v === "family" && a.children === 0
      ? setAssumptions({ ...a, householdType: "family", children: 2 })
      : set("householdType", v);
  return {
    a,
    set,
    setHousehold,
    reset: resetAssumptions,
    summary: assumptionSummary(a),
  };
}

/** "lajang" / "pasangan" / "keluarga dengan 2 anak" for headline sentences. */
export function householdNoun(a: Assumptions): string {
  if (a.householdType === "single")
    return a.children > 0 ? `lajang dengan ${a.children} anak` : "lajang";
  if (a.householdType === "couple" && a.children === 0) return "pasangan";
  return a.children > 0 ? `keluarga dengan ${a.children} anak` : "keluarga";
}

export function parseRupiah(input: string): number | null {
  const digits = input.replace(/\D/g, "").slice(0, 12);
  const n = Number(digits);
  return digits && n > 0 ? n : null;
}

export function rupiahInput(n: number | null | undefined): string {
  return n ? n.toLocaleString("id-ID") : "";
}

type ShareStatus = "idle" | "copied" | "shared" | "error";

/** Copy/share the versioned state link (same encoder as production). */
export function useShareLink() {
  const { state } = useApp();
  const [status, setStatus] = useState<ShareStatus>("idle");
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );
  const flash = (s: ShareStatus) => {
    setStatus(s);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setStatus("idle"), 2600);
  };
  const share = async () => {
    recordUsage("share_requested");
    const url = buildShareUrl(window.location.href, {
      assumptions: state.assumptions,
      pinned: state.pinned,
      selectedCode: state.selectedCode,
      originCode: state.originCode,
      colorMode: state.colorMode,
      legendFilter: state.legendFilter,
    });
    try {
      if (navigator.share && window.matchMedia("(pointer: coarse)").matches) {
        await navigator.share({ title: "Nafkah", url });
        flash("shared");
        return;
      }
      await navigator.clipboard.writeText(url);
      flash("copied");
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      flash("error");
    }
  };
  const includesMoney =
    (state.assumptions.customIncome ?? 0) > 0 ||
    (state.assumptions.installmentMonthly ?? 0) > 0;
  const label =
    status === "copied"
      ? "Tautan disalin"
      : status === "shared"
        ? "Dibagikan"
        : status === "error"
          ? "Gagal menyalin"
          : "Bagikan";
  return { status, share, label, includesMoney };
}

/** Escape closes, "/" or Ctrl/⌘+K focuses search — shared shortcuts. */
export function useGlobalKeys(handlers: {
  onSearch?: () => void;
  onEscape?: () => void;
}) {
  const ref = useRef(handlers);
  ref.current = handlers;
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      const typing =
        t &&
        (t.tagName === "INPUT" ||
          t.tagName === "TEXTAREA" ||
          t.isContentEditable);
      if (
        (e.key === "k" && (e.metaKey || e.ctrlKey)) ||
        (e.key === "/" && !typing)
      ) {
        e.preventDefault();
        ref.current.onSearch?.();
      } else if (e.key === "Escape") {
        ref.current.onEscape?.();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
}
