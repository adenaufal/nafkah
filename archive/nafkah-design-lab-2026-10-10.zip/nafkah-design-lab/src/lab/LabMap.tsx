"use client";

import { useEffect, useRef, useState } from "react";
import maplibregl, {
  type ExpressionSpecification,
  type Map as MLMap,
  type MapMouseEvent,
  type StyleSpecification,
} from "maplibre-gl";
import { useApp } from "@/state/AppContext";
import { NO_DATA_PATTERN, VALUE_RAMP, bandColors } from "@/lib/calculations";
import type { Region, RegionFeatureProps, RegionMetrics } from "@/lib/types";
import { REGION_LAYER_ANCHOR, flatStyle, resolvePaperStyle } from "./basemap";

/**
 * Peta untuk prototipe desain. Fork dari MapCanvas produksi dengan empat
 * perbedaan:
 *  - basemap "kertas" hangat (lihat basemap.ts),
 *  - metrik dikirim lewat feature-state, jadi mewarnai ulang 514 wilayah
 *    tidak perlu setData (cukup cepat untuk slider gaji yang digeser),
 *  - hover/klik diangkat ke shell untuk tooltip & linked highlighting,
 *  - kamera menghormati padding rail supaya wilayah terpilih tidak tertutup.
 */

export interface LabMapApi {
  zoomIn: () => void;
  zoomOut: () => void;
  fitIndonesia: () => void;
}

export interface LabMapMarker {
  code: string;
  label: string;
}

interface Padding {
  top: number;
  right: number;
  bottom: number;
  left: number;
}

interface LabMapProps {
  padding?: Partial<Padding>;
  /** Region highlighted from outside the map (list row, dot, table row). */
  hoverCode?: string | null;
  onHover?: (hover: { code: string; x: number; y: number } | null) => void;
  /** Dim every other region while one is selected (focus + context). */
  dimUnselected?: boolean;
  /** Regions pushed to the background (e.g. filtered out of a table). */
  dimCodes?: ReadonlySet<string> | null;
  /** Region labels: names from zoom ~5.6, selected/hovered always. */
  labels?: boolean;
  fillOpacity?: number;
  markers?: LabMapMarker[];
  markerClassName?: string;
  onReady?: (api: LabMapApi) => void;
}

const SOURCE_ID = "regions";
const INDONESIA: [[number, number], [number, number]] = [
  [94.8, -11.2],
  [141.2, 6.2],
];
const INK_LIGHT = "#1e1b18";
const INK_DARK = "#f0ece7";

type AppState = ReturnType<typeof useApp>["state"];
type RegionGeometry = GeoJSON.FeatureCollection<
  GeoJSON.Geometry,
  RegionFeatureProps
>;

interface Live {
  state: AppState;
  metrics: Map<string, RegionMetrics>;
  metricsReady: boolean;
  regionByCode: Map<string, Region>;
  hoverCode: string | null;
  dimUnselected: boolean;
  dimCodes: ReadonlySet<string> | null;
  fillOpacity: number;
  labels: boolean;
  onHover?: LabMapProps["onHover"];
  select: (code: string | null) => void;
}

export default function LabMap({
  padding,
  hoverCode = null,
  onHover,
  dimUnselected = false,
  dimCodes = null,
  labels = true,
  fillOpacity = 0.9,
  markers = [],
  markerClassName = "",
  onReady,
}: LabMapProps) {
  const { state, metrics, metricsReady, regionByCode, select } = useApp();
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<MLMap | null>(null);
  const readyRef = useRef(false);
  const [loaded, setLoaded] = useState(false);

  const live = useRef<Live>(null as unknown as Live);
  live.current = {
    state,
    metrics,
    metricsReady,
    regionByCode,
    hoverCode,
    dimUnselected,
    dimCodes,
    fillOpacity,
    labels,
    onHover,
    select,
  };

  const pad: Padding = {
    top: padding?.top ?? 0,
    right: padding?.right ?? 0,
    bottom: padding?.bottom ?? 0,
    left: padding?.left ?? 0,
  };
  const padRef = useRef(pad);
  padRef.current = pad;

  /* ---------- init ---------- */
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    let disposed = false;
    const container = containerRef.current;
    const initial = live.current.state;

    const create = (style: StyleSpecification) => {
      if (disposed) return;
      const map = new maplibregl.Map({
        container,
        style,
        bounds: INDONESIA,
        fitBoundsOptions: { padding: edge(padRef.current, 20) },
        attributionControl: { compact: true },
        maxZoom: 12,
        minZoom: 2.5,
        dragRotate: false,
        pitchWithRotate: false,
        touchPitch: false,
      });
      map.touchZoomRotate.disableRotation();
      mapRef.current = map;
      // SAFETY: lab-only debug handle for screenshot/QA scripts.
      (window as unknown as { __labMap?: MLMap }).__labMap = map;

      // Paint the (local) choropleth as soon as the style is parsed; the
      // basemap tiles can keep streaming in underneath.
      const start = () => {
        if (readyRef.current || disposed) return;
        provision(map, live.current);
        readyRef.current = true;
        setLoaded(true);
        registerInteractions(map, live);
        onReady?.({
          zoomIn: () => map.zoomIn({ duration: 250 }),
          zoomOut: () => map.zoomOut({ duration: 250 }),
          fitIndonesia: () =>
            map.fitBounds(INDONESIA, {
              padding: edge(padRef.current, 20),
              duration: 700,
            }),
        });
      };
      map.once("style.load", start);
      map.once("load", () => {
        start();
        // Compact attribution starts collapsed: an (i) button, not a banner.
        container
          .querySelector(".maplibregl-ctrl-attrib")
          ?.classList.remove("maplibregl-compact-show");
      });
    };

    // Wait briefly for the warm style; never block the map on the network.
    const timeout = new Promise<StyleSpecification>((resolve) =>
      setTimeout(() => resolve(flatStyle(initial.darkMode)), 2500),
    );
    void Promise.race([
      resolvePaperStyle(
        navigator.onLine ? initial.basemap : "offline",
        initial.darkMode,
      ),
      timeout,
    ]).then(create);

    const ro = new ResizeObserver(() => mapRef.current?.resize());
    ro.observe(container);

    return () => {
      disposed = true;
      ro.disconnect();
      readyRef.current = false;
      mapRef.current?.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------- basemap / theme ---------- */
  const firstStyle = useRef(true);
  useEffect(() => {
    if (firstStyle.current) {
      firstStyle.current = false;
      return;
    }
    let cancelled = false;
    let frame = 0;
    void resolvePaperStyle(state.basemap, state.darkMode).then((style) => {
      const map = mapRef.current;
      if (cancelled || !map) return;
      readyRef.current = false;
      map.setStyle(style, { diff: false });
      const restore = () => {
        if (cancelled || mapRef.current !== map) return;
        if (!map.isStyleLoaded()) {
          frame = requestAnimationFrame(restore);
          return;
        }
        provision(map, live.current);
        readyRef.current = true;
      };
      frame = requestAnimationFrame(restore);
    });
    return () => {
      cancelled = true;
      cancelAnimationFrame(frame);
    };
  }, [state.basemap, state.darkMode]);

  /* ---------- geometry / which regions have data ---------- */
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !readyRef.current) return;
    provision(map, live.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.geometry, metricsReady, loaded]);

  /* ---------- metrics → feature-state (cheap, every assumption change) ---------- */
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !readyRef.current) return;
    pushStates(map, live.current);
  }, [metrics, dimCodes, loaded]);

  /* ---------- paint ---------- */
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !readyRef.current) return;
    syncPaint(map, live.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    state.colorMode,
    state.legendFilter,
    state.selectedCode,
    hoverCode,
    dimUnselected,
    fillOpacity,
    labels,
    loaded,
  ]);

  /* ---------- camera padding (rails, sheets) ---------- */
  useEffect(() => {
    mapRef.current?.easeTo({ padding: pad, duration: 300 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pad.top, pad.right, pad.bottom, pad.left]);

  /* ---------- fly to selection ---------- */
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !state.selectedCode || !state.geometry) return;
    const feature = state.geometry.features.find(
      (f) => f.properties.kode === state.selectedCode,
    );
    const box = feature ? bbox(feature.geometry) : null;
    if (!box) return;
    map.fitBounds(box, {
      padding: edge(padRef.current, 56),
      maxZoom: 8.4,
      duration: 900,
    });
  }, [state.selectedCode, state.geometry, loaded]);

  /* ---------- reset view ---------- */
  useEffect(() => {
    if (state.resetViewToken === 0) return;
    mapRef.current?.fitBounds(INDONESIA, {
      padding: edge(padRef.current, 20),
      duration: 700,
    });
  }, [state.resetViewToken]);

  /* ---------- markers (pins) ---------- */
  const markerKey = markers.map((m) => `${m.code}:${m.label}`).join("|");
  useEffect(() => {
    const map = mapRef.current;
    if (!map || markers.length === 0) return;
    const made = markers.flatMap((m) => {
      const region = regionByCode.get(m.code);
      if (!region) return [];
      const el = document.createElement("div");
      el.className = markerClassName;
      el.textContent = m.label;
      el.setAttribute("aria-hidden", "true");
      return [
        new maplibregl.Marker({ element: el })
          .setLngLat(region.centroid)
          .addTo(map),
      ];
    });
    return () => made.forEach((mk) => mk.remove());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [markerKey, regionByCode, markerClassName, loaded]);

  return (
    <div
      className="absolute inset-0"
      role="region"
      aria-label="Peta keterjangkauan 514 kabupaten/kota (choropleth)"
    >
      <div ref={containerRef} className="h-full w-full" />
    </div>
  );
}

/* ================= helpers ================= */

function edge(p: Padding, extra: number) {
  return {
    top: p.top + extra,
    right: p.right + extra,
    bottom: p.bottom + extra,
    left: p.left + extra,
  };
}

function bbox(
  geom: GeoJSON.Geometry,
): [[number, number], [number, number]] | null {
  let minX = Infinity,
    minY = Infinity,
    maxX = -Infinity,
    maxY = -Infinity;
  const walk = (c: unknown): void => {
    if (!Array.isArray(c)) return;
    if (typeof c[0] === "number") {
      const [x, y] = c as [number, number];
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
      return;
    }
    c.forEach(walk);
  };
  if (geom.type === "Polygon" || geom.type === "MultiPolygon")
    walk(geom.coordinates);
  return minX === Infinity
    ? null
    : [
        [minX, minY],
        [maxX, maxY],
      ];
}

/** Static per-feature properties; live numbers travel as feature-state. */
function staticGeometry(live: Live): RegionGeometry | null {
  const geo = live.state.geometry;
  if (!geo) return null;
  return {
    type: "FeatureCollection",
    features: geo.features.map((f) => {
      const tier =
        live.regionByCode.get(f.properties.kode)?.tier ?? "kabupaten";
      return {
        ...f,
        properties: {
          ...f.properties,
          hasData: live.metricsReady && live.state.costs.has(f.properties.kode),
          tier,
          rank: tier === "kota" ? 0 : 1,
        },
      };
    }),
  };
}

function pushStates(map: MLMap, live: Live) {
  if (!map.getSource(SOURCE_ID) || !live.state.geometry) return;
  for (const f of live.state.geometry.features) {
    const code = f.properties.kode;
    const m = live.metricsReady ? live.metrics.get(code) : undefined;
    map.setFeatureState(
      { source: SOURCE_ID, id: code },
      {
        band: m?.band ?? "none",
        cost: m?.totalMonthlyCost ?? 0,
        wage: m?.regionalWageAmount ?? 0,
        dim: live.dimCodes ? live.dimCodes.has(code) : false,
      },
    );
  }
}

function hatch(): Uint8Array {
  const s = 8;
  const data = new Uint8Array(s * s * 4);
  for (let y = 0; y < s; y++) {
    for (let x = 0; x < s; x++) {
      const i = (y * s + x) * 4;
      const on = (x + y) % s < 2;
      data[i] = data[i + 1] = data[i + 2] = 120;
      data[i + 3] = on ? 90 : 26;
    }
  }
  return data;
}

function provision(map: MLMap, live: Live) {
  const geo = staticGeometry(live);
  if (!geo) return;
  if (!map.hasImage(NO_DATA_PATTERN)) {
    map.addImage(
      NO_DATA_PATTERN,
      { width: 8, height: 8, data: hatch() },
      { pixelRatio: 2 },
    );
  }
  const existing = map.getSource(SOURCE_ID) as
    maplibregl.GeoJSONSource | undefined;
  if (existing) {
    // SAFETY: RegionFeatureProps is a superset of what MapLibre stores per feature.
    existing.setData(geo as unknown as GeoJSON.GeoJSON);
    pushStates(map, live);
    syncPaint(map, live);
    return;
  }
  map.addSource(SOURCE_ID, {
    type: "geojson",
    // SAFETY: same normalisation guarantee as setData above.
    data: geo as unknown as GeoJSON.GeoJSON,
    promoteId: "kode",
  });
  const before = map.getLayer(REGION_LAYER_ANCHOR)
    ? REGION_LAYER_ANCHOR
    : undefined;
  const dark = live.state.darkMode;
  const hasData: ExpressionSpecification = [
    "to-boolean",
    ["coalesce", ["get", "hasData"], false],
  ];
  const none: ExpressionSpecification = ["==", ["get", "kode"], ""];

  map.addLayer(
    {
      id: "lab-nodata",
      type: "fill",
      source: SOURCE_ID,
      filter: ["!", hasData],
      paint: { "fill-pattern": NO_DATA_PATTERN, "fill-opacity": 0.7 },
    },
    before,
  );
  map.addLayer(
    {
      id: "lab-fill",
      type: "fill",
      source: SOURCE_ID,
      filter: hasData,
      paint: { "fill-color": "#ccc", "fill-opacity": live.fillOpacity },
    },
    before,
  );
  map.addLayer(
    {
      id: "lab-outline",
      type: "line",
      source: SOURCE_ID,
      paint: {
        "line-color": dark ? "rgba(22,19,16,0.75)" : "rgba(255,255,255,0.8)",
        "line-width": [
          "interpolate",
          ["linear"],
          ["zoom"],
          4,
          0.3,
          7,
          0.9,
          10,
          1.4,
        ],
      },
    },
    before,
  );
  map.addLayer(
    {
      id: "lab-hover",
      type: "line",
      source: SOURCE_ID,
      filter: none,
      paint: { "line-color": dark ? INK_DARK : INK_LIGHT, "line-width": 1.5 },
    },
    before,
  );
  map.addLayer(
    {
      id: "lab-selected-halo",
      type: "line",
      source: SOURCE_ID,
      filter: none,
      paint: {
        "line-color": dark ? "#161310" : "#ffffff",
        "line-width": 6,
        "line-opacity": 0.95,
      },
    },
    before,
  );
  map.addLayer(
    {
      id: "lab-selected",
      type: "line",
      source: SOURCE_ID,
      filter: none,
      paint: { "line-color": dark ? INK_DARK : INK_LIGHT, "line-width": 2.2 },
    },
    before,
  );

  const glyphs = map.getStyle().glyphs ?? "";
  if (glyphs) {
    const carto = glyphs.includes("cartocdn");
    const regular = carto
      ? ["Montserrat Regular", "Open Sans Regular"]
      : ["Noto Sans Regular"];
    const medium = carto
      ? ["Montserrat Medium", "Open Sans Bold"]
      : ["Noto Sans Regular"];
    map.addLayer({
      id: "lab-labels",
      type: "symbol",
      source: SOURCE_ID,
      minzoom: 5.6,
      filter: hasData,
      layout: {
        "text-field": ["get", "name"],
        "text-font": regular,
        "text-size": ["interpolate", ["linear"], ["zoom"], 5.6, 10, 9, 13],
        "text-max-width": 7,
        "symbol-sort-key": ["get", "rank"],
        "text-padding": 4,
      },
      paint: labelPaint(dark, false),
    });
    map.addLayer({
      id: "lab-label-focus",
      type: "symbol",
      source: SOURCE_ID,
      filter: none,
      layout: {
        "text-field": ["get", "name"],
        "text-font": medium,
        "text-size": 13,
        "text-allow-overlap": true,
        "text-ignore-placement": true,
        "text-max-width": 8,
      },
      paint: labelPaint(dark, true),
    });
  }
  pushStates(map, live);
  syncPaint(map, live);
}

function labelPaint(dark: boolean, strong: boolean) {
  return dark
    ? {
        "text-color": strong ? "#fbf7f2" : "rgba(240,236,231,0.86)",
        "text-halo-color": "rgba(22,19,16,0.92)",
        "text-halo-width": strong ? 1.8 : 1.3,
      }
    : {
        "text-color": strong ? "#16130f" : "#2b2622",
        "text-halo-color": "rgba(255,255,255,0.92)",
        "text-halo-width": strong ? 1.8 : 1.3,
      };
}

function syncPaint(map: MLMap, live: Live) {
  if (!map.getLayer("lab-fill")) return;
  const { state } = live;
  const dark = state.darkMode;

  let fillColor: unknown;
  if (state.colorMode === "coverage") {
    const c = bandColors(dark);
    fillColor = [
      "match",
      ["feature-state", "band"],
      "comfortable",
      c.comfortable,
      "manageable",
      c.manageable,
      "tight",
      c.tight,
      "insufficient",
      c.insufficient,
      dark ? "#3a332c" : "#d8d1c6",
    ];
  } else {
    const prop = state.colorMode === "cost" ? "cost" : "wage";
    const ramp = dark ? VALUE_RAMP.dark : VALUE_RAMP.light;
    const [a, b, d] =
      state.colorMode === "cost" ? [3e6, 5.5e6, 8e6] : [2e6, 3.5e6, 5.5e6];
    fillColor = [
      "interpolate",
      ["linear"],
      ["number", ["feature-state", prop], 0],
      a,
      ramp[0],
      b,
      ramp[1],
      d,
      ramp[2],
    ];
  }
  map.setPaintProperty(
    "lab-fill",
    "fill-color",
    fillColor as ExpressionSpecification,
  );

  const sel = state.selectedCode;
  const filter = state.legendFilter;
  const base = live.fillOpacity;
  const isSel: ExpressionSpecification = ["==", ["get", "kode"], sel ?? ""];
  const dimmed: ExpressionSpecification = [
    "boolean",
    ["feature-state", "dim"],
    false,
  ];
  const inBand: ExpressionSpecification = [
    "==",
    ["feature-state", "band"],
    filter ?? "",
  ];
  const rest = sel && live.dimUnselected ? base * (dark ? 0.32 : 0.45) : base;
  const opacity: ExpressionSpecification = [
    "case",
    isSel,
    base,
    dimmed,
    0.1,
    ...(filter ? ([["!", inBand], 0.1] as const) : []),
    rest,
  ] as unknown as ExpressionSpecification;
  map.setPaintProperty("lab-fill", "fill-opacity", opacity);

  const pick = (code: string | null): ExpressionSpecification => [
    "==",
    ["get", "kode"],
    code ?? "",
  ];
  map.setFilter("lab-hover", pick(live.hoverCode));
  map.setFilter("lab-selected", pick(sel));
  map.setFilter("lab-selected-halo", pick(sel));
  if (map.getLayer("lab-label-focus"))
    map.setFilter("lab-label-focus", pick(sel ?? live.hoverCode));
  if (map.getLayer("lab-labels")) {
    map.setLayoutProperty(
      "lab-labels",
      "visibility",
      live.labels ? "visible" : "none",
    );
  }
}

function registerInteractions(map: MLMap, liveRef: { current: Live }) {
  // SAFETY: private registration flag on the Map instance, set once at init.
  const flagged = map as unknown as { __labInteractions?: boolean };
  if (flagged.__labInteractions) return;
  flagged.__labInteractions = true;

  let last: string | null = null;
  const onMove = (e: MapMouseEvent) => {
    if (!map.getLayer("lab-fill")) return;
    const f = map.queryRenderedFeatures(e.point, {
      layers: ["lab-fill", "lab-nodata"],
    })[0];
    const code = (f?.properties?.kode as string | undefined) ?? null;
    if (code !== last) {
      last = code;
      map.getCanvas().style.cursor = code ? "pointer" : "";
    }
    liveRef.current.onHover?.(
      code ? { code, x: e.point.x, y: e.point.y } : null,
    );
  };
  map.on("mousemove", onMove);
  map.on("mouseout", () => {
    last = null;
    liveRef.current.onHover?.(null);
  });
  map.on("click", (e: MapMouseEvent) => {
    if (!map.getLayer("lab-fill")) return;
    const f = map.queryRenderedFeatures(e.point, {
      layers: ["lab-fill", "lab-nodata"],
    })[0];
    liveRef.current.select((f?.properties?.kode as string | undefined) ?? null);
  });
}
