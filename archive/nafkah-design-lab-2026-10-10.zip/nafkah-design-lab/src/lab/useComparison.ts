"use client";

import { useState } from "react";
import { useApp } from "@/state/AppContext";
import {
  buildComparisonCsv,
  downloadCsv,
  type ComparisonExportRow,
} from "@/lib/export";
import { recordUsage } from "@/lib/usage";
import type { RegionMetrics } from "@/lib/types";
import manifest from "../../public/data/v2026.1/manifest.json";

/** Pinned regions with metrics + the production CSV export, for every variant. */
export function useComparison() {
  const { state, metrics, regionByCode } = useApp();
  const [exportStatus, setExportStatus] = useState<"idle" | "done" | "error">(
    "idle",
  );
  const items = state.pinned
    .map((code) => {
      const metric = metrics.get(code);
      const region = regionByCode.get(code);
      return metric && region ? { code, metric, region } : null;
    })
    .filter(
      (
        x,
      ): x is {
        code: string;
        metric: RegionMetrics;
        region: NonNullable<ReturnType<typeof regionByCode.get>>;
      } => x !== null,
    );

  const exportCsv = () => {
    const origin = state.originCode
      ? regionByCode.get(state.originCode)
      : undefined;
    const rows: ComparisonExportRow[] = items.flatMap(
      ({ code, metric, region }) => {
        const wage = state.wages.get(code);
        const costs = state.costs.get(code);
        if (!wage || !costs) return [];
        return [
          {
            region,
            metrics: metric,
            wage,
            costs,
            originWage: state.originCode
              ? state.wages.get(state.originCode)
              : undefined,
          },
        ];
      },
    );
    if (!rows.length) return;
    try {
      const csv = buildComparisonCsv({
        rows,
        assumptions: state.assumptions,
        datasetVersion: manifest.datasetVersion,
        origin,
      });
      downloadCsv(
        csv,
        `nafkah-perbandingan-${new Date().toISOString().slice(0, 10)}.csv`,
      );
      recordUsage("csv_exported");
      setExportStatus("done");
      window.setTimeout(() => setExportStatus("idle"), 2400);
    } catch {
      setExportStatus("error");
    }
  };

  return { items, exportCsv, exportStatus };
}
