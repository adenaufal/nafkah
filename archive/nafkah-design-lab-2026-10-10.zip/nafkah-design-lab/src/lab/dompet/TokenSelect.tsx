"use client";

import { useEffect, useId, useRef, useState } from "react";
import { CaretDown, Check } from "@phosphor-icons/react";

/**
 * A word in the profile sentence that opens a small option list. Reads as
 * prose ("Aku lajang, hidup standar…") but is a real listbox for keyboards
 * and screen readers.
 */
export function TokenSelect<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: { value: T; label: string; hint?: string }[];
  onChange: (v: T) => void;
}) {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  // Fixed position: the popover must escape the scrolling profile card.
  const [pos, setPos] = useState<{ left: number; top: number } | null>(null);
  const wrap = useRef<HTMLSpanElement>(null);
  const btn = useRef<HTMLButtonElement>(null);
  const list = useRef<HTMLSpanElement>(null);
  const id = useId();
  const current = options.find((o) => o.value === value) ?? options[0];

  useEffect(() => {
    if (!open) return;
    const r = btn.current?.getBoundingClientRect();
    if (r)
      setPos({
        left: Math.min(r.left, window.innerWidth - 228),
        top: r.bottom + 6,
      });
    setActive(
      Math.max(
        0,
        options.findIndex((o) => o.value === value),
      ),
    );
    const onDoc = (e: MouseEvent) => {
      if (!wrap.current?.contains(e.target as Node)) setOpen(false);
    };
    const onScroll = (e: Event) => {
      if (!list.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("scroll", onScroll, true);
    requestAnimationFrame(() => list.current?.focus());
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("scroll", onScroll, true);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const commit = (i: number) => {
    onChange(options[i].value);
    setOpen(false);
    btn.current?.focus();
  };

  return (
    <span ref={wrap} className="relative inline-block">
      <button
        ref={btn}
        type="button"
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={`${label}: ${current.label}`}
        onClick={() => setOpen((v) => !v)}
        className={`inline-flex items-center gap-1 rounded-[10px] px-2 py-0.5 font-bold text-[var(--accent-strong)] transition-colors ${
          open
            ? "bg-[var(--accent-soft)]"
            : "bg-[var(--accent-tint)] hover:bg-[var(--accent-soft)]"
        }`}
      >
        {current.label}
        <CaretDown
          size={13}
          weight="bold"
          aria-hidden="true"
          className={`transition-transform ${open ? "rotate-180" : ""}`}
        />
      </button>
      {open && pos && (
        <span
          ref={list}
          id={id}
          role="listbox"
          tabIndex={-1}
          aria-label={label}
          aria-activedescendant={`${id}-${active}`}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setActive((i) => Math.min(i + 1, options.length - 1));
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              setActive((i) => Math.max(i - 1, 0));
            } else if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              commit(active);
            } else if (e.key === "Escape" || e.key === "Tab") {
              e.stopPropagation();
              setOpen(false);
              btn.current?.focus();
            }
          }}
          style={{ left: pos.left, top: pos.top, outline: "none" }}
          className="lab-fade fixed z-[60] block w-[220px] rounded-[14px] border border-[var(--line)] bg-[var(--card)] p-1.5 text-[14px] font-normal leading-normal shadow-[var(--shadow-2)]"
        >
          {options.map((o, i) => {
            const on = o.value === value;
            return (
              <span
                key={o.value}
                id={`${id}-${i}`}
                role="option"
                aria-selected={on}
                onMouseEnter={() => setActive(i)}
                onMouseDown={(e) => {
                  e.preventDefault();
                  commit(i);
                }}
                className={`flex cursor-pointer items-center gap-3 rounded-[10px] px-3 py-2 ${i === active ? "bg-[var(--card-2)]" : ""}`}
              >
                <span className="min-w-0 flex-1">
                  <span className={`block ${on ? "font-bold" : "font-medium"}`}>
                    {o.label}
                  </span>
                  {o.hint && (
                    <span className="block text-[12px] text-[var(--muted)]">
                      {o.hint}
                    </span>
                  )}
                </span>
                {on && (
                  <Check
                    size={15}
                    weight="bold"
                    className="text-[var(--accent)]"
                    aria-hidden="true"
                  />
                )}
              </span>
            );
          })}
        </span>
      )}
    </span>
  );
}
