"use client";

import { DownloadSimple, X } from "@phosphor-icons/react";
import { useApp } from "@/state/AppContext";
import { EXPENSE_CATEGORIES } from "@/data/costs";
import { useDialogFocus } from "@/lib/useDialogFocus";
import { useAssumptionActions } from "../actions";
import { useComparison } from "../useComparison";
import { bandTheme, pct, wageLabel } from "../useLabData";

const num = (v: number) =>
  (Math.round(Math.abs(v) / 1000) * 1000).toLocaleString("id-ID");

/** Saved receipts side by side — same lines, same order, easy to scan across. */
export function ReceiptCompare({ onClose }: { onClose: () => void }) {
  const { state, unpin, select } = useApp();
  const { summary } = useAssumptionActions();
  const { items, exportCsv, exportStatus } = useComparison();
  const ref = useDialogFocus<HTMLDivElement>(true, onClose);
  const theme = bandTheme(state.darkMode);
  const best = items.reduce<string | null>(
    (acc, it) =>
      !acc ||
      it.metric.surplusOrDeficit >
        (items.find((x) => x.code === acc)?.metric.surplusOrDeficit ??
          -Infinity)
        ? it.code
        : acc,
    null,
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-0 sm:items-center sm:p-6"
      onClick={onClose}
      role="presentation"
    >
      <div
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-labelledby="cmp-title"
        onClick={(e) => e.stopPropagation()}
        className="lab-rise flex max-h-[92dvh] w-full max-w-[1180px] flex-col overflow-hidden rounded-t-[24px] bg-[var(--bg)] shadow-[var(--shadow-2)] sm:rounded-[24px]"
      >
        <header className="flex items-center gap-3 px-6 py-4">
          <div className="min-w-0">
            <h2
              id="cmp-title"
              className="text-[20px] font-extrabold tracking-[-0.02em]"
            >
              Bandingkan {items.length} struk
            </h2>
            <p className="truncate text-[12.5px] text-[var(--muted)]">
              Profil: {summary}
            </p>
          </div>
          <button
            type="button"
            onClick={exportCsv}
            className="ml-auto inline-flex h-10 items-center gap-1.5 rounded-[12px] border border-[var(--line-2)] bg-[var(--card)] px-3.5 text-[13px] font-bold hover:border-[var(--ink-2)]"
          >
            <DownloadSimple size={15} aria-hidden="true" />
            {exportStatus === "done" ? "CSV diunduh" : "Ekspor CSV"}
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup perbandingan"
            className="grid h-10 w-10 place-items-center rounded-full hover:bg-[var(--card)]"
          >
            <X size={17} weight="bold" aria-hidden="true" />
          </button>
        </header>
        <div className="lab-scroll flex min-h-0 gap-4 overflow-x-auto overflow-y-auto px-6 pb-7">
          {items.map(({ code, region, metric }) => {
            const surplus = metric.surplusOrDeficit >= 0;
            return (
              <article key={code} className="w-[264px] shrink-0">
                <div className="rounded-t-[16px] bg-[var(--paper-receipt)] px-5 pb-4 pt-4 shadow-[var(--shadow-1)]">
                  <div className="flex items-start gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        select(code);
                        onClose();
                      }}
                      className="min-w-0 flex-1 text-left"
                    >
                      <h3 className="truncate text-[16px] font-extrabold tracking-[-0.01em] hover:text-[var(--accent-strong)]">
                        {region.name}
                      </h3>
                      <p className="truncate text-[12px] text-[var(--muted)]">
                        {region.province}
                      </p>
                    </button>
                    <button
                      type="button"
                      onClick={() => unpin(code)}
                      aria-label={`Hapus struk ${region.name}`}
                      className="grid h-7 w-7 place-items-center rounded-full text-[var(--muted)] hover:bg-[var(--card-2)]"
                    >
                      <X size={12} weight="bold" aria-hidden="true" />
                    </button>
                  </div>
                  {/* Badge row is reserved on every receipt so the lines stay aligned. */}
                  <p className="mt-2 h-5">
                    {best === code && items.length > 1 && (
                      <span className="inline-block rounded-full bg-[var(--ok-soft)] px-2 py-0.5 text-[11px] font-bold text-[var(--ok)]">
                        Sisa terbesar
                      </span>
                    )}
                  </p>
                  <div
                    className="my-3 border-t border-dashed border-[var(--line-2)]"
                    aria-hidden="true"
                  />
                  <Row
                    label={wageLabel(metric, state.assumptions)}
                    value={num(metric.wageAmount)}
                    strong
                  />
                  <div
                    className="my-2 border-t border-dashed border-[var(--line-2)]"
                    aria-hidden="true"
                  />
                  {EXPENSE_CATEGORIES.map((c) => (
                    <Row
                      key={c.key}
                      label={c.label.replace(" / pengasuhan anak", "")}
                      value={num(metric.breakdown[c.key])}
                    />
                  ))}
                  <div
                    className="my-2 border-t border-dashed border-[var(--line-2)]"
                    aria-hidden="true"
                  />
                  <Row
                    label="Total"
                    value={num(metric.totalMonthlyCost)}
                    strong
                  />
                  <div
                    className="my-2.5 h-[3px] border-y border-[var(--ink)]"
                    aria-hidden="true"
                  />
                  <p
                    className={`f-mono tnum text-right text-[24px] font-bold tracking-[-0.03em] ${surplus ? "text-[var(--ok)]" : "text-[var(--danger)]"}`}
                  >
                    {surplus ? "+" : "−"}
                    {num(metric.surplusOrDeficit)}
                  </p>
                  <p className="mt-1 flex items-center justify-end gap-1.5 text-[12px] text-[var(--ink-2)]">
                    <span
                      aria-hidden="true"
                      className="h-2 w-2 rounded-full"
                      style={{ background: theme[metric.band].fill }}
                    />
                    {theme[metric.band].label} · {pct(metric.coveragePercent)}
                  </p>
                </div>
                <div className="receipt-edge" aria-hidden="true" />
              </article>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function Row({
  label,
  value,
  strong = false,
}: {
  label: string;
  value: string;
  strong?: boolean;
}) {
  return (
    <div className="flex items-baseline gap-2 py-[2px]">
      <span
        className={`min-w-0 truncate text-[12.5px] ${strong ? "font-bold" : "text-[var(--ink-2)]"}`}
      >
        {label}
      </span>
      <span
        aria-hidden="true"
        className="mb-[3px] min-w-3 flex-1 border-b border-dotted border-[var(--line-2)]"
      />
      <span
        className={`f-mono tnum shrink-0 text-[12.5px] ${strong ? "font-bold" : ""}`}
      >
        {value}
      </span>
    </div>
  );
}
