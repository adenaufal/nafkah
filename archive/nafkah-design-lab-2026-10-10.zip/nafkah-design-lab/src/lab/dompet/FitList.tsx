"use client";

import { useMemo, useState } from "react";
import { useApp } from "@/state/AppContext";
import { bandTheme, rpJt, useNationalStats } from "../useLabData";

/** Ranked places for *this* profile, by what is left at the end of the month. */
export function FitList({
  onHover,
}: {
  onHover: (code: string | null) => void;
}) {
  const { state, select, retryData } = useApp();
  const stats = useNationalStats();
  const theme = bandTheme(state.darkMode);
  const [side, setSide] = useState<"lega" | "berat">("lega");
  const [limit, setLimit] = useState(12);
  const list = useMemo(() => {
    const sorted = [...stats.ranked].sort(
      (a, b) => b.metric.surplusOrDeficit - a.metric.surplusOrDeficit,
    );
    return side === "lega" ? sorted : sorted.reverse();
  }, [stats.ranked, side]);
  const maxAbs = Math.max(
    1,
    ...list.slice(0, limit).map((r) => Math.abs(r.metric.surplusOrDeficit)),
  );

  return (
    <section aria-labelledby="fit-title" className="flex min-h-0 flex-col">
      <div className="px-5 pt-5">
        <h2
          id="fit-title"
          className="text-[17px] font-extrabold tracking-[-0.015em]"
        >
          {side === "lega" ? "Paling lega untukmu" : "Paling berat untukmu"}
        </h2>
        <p className="mt-0.5 text-[12.5px] text-[var(--muted)]">
          Diurutkan menurut sisa uang di akhir bulan.
        </p>
        <div
          role="radiogroup"
          aria-label="Urutan daftar"
          className="mt-3 grid grid-cols-2 gap-1 rounded-[12px] bg-[var(--card-2)] p-1 ring-1 ring-[var(--line)]"
        >
          {(["lega", "berat"] as const).map((s) => (
            <button
              key={s}
              type="button"
              role="radio"
              aria-checked={side === s}
              onClick={() => {
                setSide(s);
                setLimit(12);
              }}
              className={`h-8 rounded-[9px] text-[12.5px] font-semibold ${side === s ? "bg-[var(--card)] text-[var(--ink)] shadow-[var(--shadow-1)]" : "text-[var(--muted)]"}`}
            >
              {s === "lega" ? "Sisa terbesar" : "Kurang terbesar"}
            </button>
          ))}
        </div>
      </div>
      <ol
        className="lab-scroll mt-2 min-h-0 flex-1 overflow-y-auto px-2 pb-2"
        onMouseLeave={() => onHover(null)}
      >
        {state.dataStatus === "error" && (
          <li
            role="alert"
            className="mx-3 my-4 rounded-[14px] bg-[var(--danger-soft)] p-4 text-[13px] leading-[1.55]"
          >
            <b>Daftar belum bisa dihitung.</b> Data upah &amp; biaya gagal
            dimuat.
            <button
              type="button"
              onClick={retryData}
              className="mt-3 block h-9 rounded-[10px] bg-[var(--accent)] px-4 text-[13px] font-bold text-white dark:text-[#211a14]"
            >
              Coba lagi
            </button>
          </li>
        )}
        {!stats.ready &&
          state.dataStatus !== "error" &&
          Array.from({ length: 8 }, (_, i) => (
            <li
              key={i}
              className="mx-3 my-3 flex items-center gap-3"
              aria-hidden="true"
            >
              <div className="lab-skel h-9 flex-1" />
            </li>
          ))}
        {list.slice(0, limit).map((r, i) => {
          const s = r.metric.surplusOrDeficit;
          return (
            <li key={r.code}>
              <button
                type="button"
                onClick={() => select(r.code)}
                onMouseEnter={() => onHover(r.code)}
                onFocus={() => onHover(r.code)}
                className="grid w-full grid-cols-[22px_minmax(0,1fr)_auto] items-center gap-x-3 rounded-[12px] px-3 py-2 text-left hover:bg-[var(--card-2)]"
              >
                <span className="tnum text-right text-[12px] font-bold text-[var(--muted)]">
                  {i + 1}
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-[14px] font-semibold">
                    {r.name}
                  </span>
                  <span className="block truncate text-[11.5px] text-[var(--muted)]">
                    {r.province}
                  </span>
                  <span className="mt-1.5 block h-1 overflow-hidden rounded-full bg-[var(--line)]">
                    <span
                      className="block h-full rounded-full"
                      style={{
                        width: `${(Math.abs(s) / maxAbs) * 100}%`,
                        background: theme[r.metric.band].fill,
                      }}
                    />
                  </span>
                </span>
                <span
                  className={`tnum text-right text-[14px] font-bold ${s >= 0 ? "text-[var(--ok)]" : "text-[var(--danger)]"}`}
                >
                  {s >= 0 ? "+" : "−"}
                  {rpJt(s)}
                </span>
              </button>
            </li>
          );
        })}
        {stats.ready && limit < list.length && (
          <li className="px-3 pt-1">
            <button
              type="button"
              onClick={() => setLimit((l) => l + 24)}
              className="h-9 w-full rounded-[10px] text-[13px] font-semibold text-[var(--accent-strong)] hover:bg-[var(--accent-tint)]"
            >
              Tampilkan lebih banyak ({list.length - limit} lagi)
            </button>
          </li>
        )}
      </ol>
    </section>
  );
}
