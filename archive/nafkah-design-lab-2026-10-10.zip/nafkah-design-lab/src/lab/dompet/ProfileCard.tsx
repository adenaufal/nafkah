"use client";

import { useEffect, useMemo, useState } from "react";
import { Check, MagnifyingGlass, X } from "@phosphor-icons/react";
import { useApp } from "@/state/AppContext";
import { MAX_CHILDREN } from "@/state/persist";
import type { HousingType, LifestyleLevel, TransportMode } from "@/lib/types";
import { parseRupiah, rupiahInput, useAssumptionActions } from "../actions";
import { useRegionSearch } from "../useRegionSearch";
import { BAND_ORDER, bandTheme, rpJt, useNationalStats } from "../useLabData";
import { TokenSelect } from "./TokenSelect";

type IncomeMode = "umk" | "gaji" | "asal";

/* 1–10 jt in 100 rb steps, then 10,5–25 jt in 500 rb steps. */
const STEPS = [
  ...Array.from({ length: 91 }, (_, i) => 1_000_000 + i * 100_000),
  ...Array.from({ length: 30 }, (_, i) => 10_500_000 + i * 500_000),
];
const posOf = (v: number) => {
  let best = 0;
  for (let i = 0; i < STEPS.length; i++)
    if (Math.abs(STEPS[i] - v) < Math.abs(STEPS[best] - v)) best = i;
  return best;
};

export function ProfileCard({ compact = false }: { compact?: boolean }) {
  const { state, setOrigin, regionByCode } = useApp();
  const { a, set, setHousehold, reset } = useAssumptionActions();
  const stats = useNationalStats();
  const theme = bandTheme(state.darkMode);

  const derived: IncomeMode =
    (a.customIncome ?? 0) > 0 ? "gaji" : state.originCode ? "asal" : "umk";
  const [mode, setMode] = useState<IncomeMode>(derived);
  useEffect(() => {
    if (derived !== "umk") setMode(derived);
  }, [derived]);
  const [installmentOpen, setInstallmentOpen] = useState(
    (a.installmentMonthly ?? 0) > 0,
  );

  const chooseMode = (m: IncomeMode) => {
    setMode(m);
    if (m === "umk") {
      if (a.customIncome) set("customIncome", null);
      if (state.originCode) setOrigin(null);
    } else if (m === "gaji") {
      if (state.originCode) setOrigin(null);
      if (!a.customIncome) set("customIncome", 6_000_000);
    } else if (a.customIncome) {
      set("customIncome", null);
    }
  };

  const fits = stats.counts.comfortable + stats.counts.manageable;
  const best = useMemo(
    () =>
      [...stats.ranked].sort(
        (x, y) => y.metric.surplusOrDeficit - x.metric.surplusOrDeficit,
      )[0],
    [stats.ranked],
  );
  const origin = state.originCode
    ? regionByCode.get(state.originCode)
    : undefined;
  const who =
    mode === "gaji" && a.customIncome
      ? `gaji ${rpJt(a.customIncome)}`
      : mode === "asal" && origin
        ? `UMK ${origin.name}`
        : "UMK tiap daerah";

  return (
    <div className="flex flex-col">
      <div className={compact ? "px-5 pt-5" : "px-6 pt-6"}>
        <p className="text-[12px] font-bold uppercase tracking-[0.12em] text-[var(--muted)]">
          Profil kamu
        </p>
        <p className="mt-3 text-[19px] font-medium leading-[1.9] tracking-[-0.01em] text-[var(--ink)]">
          Aku{" "}
          <TokenSelect
            label="Rumah tangga"
            value={a.householdType}
            onChange={setHousehold}
            options={[
              { value: "single", label: "lajang" },
              { value: "couple", label: "berpasangan" },
              { value: "family", label: "berkeluarga" },
            ]}
          />
          ,{" "}
          <TokenSelect
            label="Jumlah anak"
            value={String(a.children)}
            onChange={(v) => set("children", Number(v))}
            options={Array.from({ length: MAX_CHILDREN + 1 }, (_, i) => ({
              value: String(i),
              label: i === 0 ? "tanpa anak" : `${i} anak`,
            }))}
          />
          , hidup{" "}
          <TokenSelect<LifestyleLevel>
            label="Gaya hidup"
            value={a.lifestyle}
            onChange={(v) => set("lifestyle", v)}
            options={[
              {
                value: "budget",
                label: "hemat",
                hint: "Makan rumahan, jarang jajan",
              },
              {
                value: "moderate",
                label: "standar",
                hint: "Sesekali makan di luar & hiburan",
              },
              {
                value: "comfortable",
                label: "nyaman",
                hint: "Lebih leluasa untuk rekreasi",
              },
            ]}
          />
          , tinggal di{" "}
          <TokenSelect<HousingType>
            label="Hunian"
            value={a.housing}
            onChange={(v) => set("housing", v)}
            options={[
              {
                value: "room",
                label: "kost",
                hint: "Rusun/kost — menengah ke bawah",
              },
              { value: "studio", label: "rumah KPR", hint: "Menengah" },
              {
                value: "oneBedroom",
                label: "apartemen",
                hint: "Menengah ke atas",
              },
            ]}
          />
          , dan naik{" "}
          <TokenSelect<TransportMode>
            label="Transportasi"
            value={a.transport}
            onChange={(v) => set("transport", v)}
            options={[
              { value: "motorcycle", label: "motor" },
              { value: "publicTransport", label: "kendaraan umum" },
              { value: "rideHailing", label: "ojol" },
            ]}
          />
          .
        </p>
      </div>

      <div
        className={`mt-5 border-t border-[var(--line)] ${compact ? "px-5 pt-4" : "px-6 pt-5"}`}
      >
        <p id="dompet-income" className="text-[14px] font-bold">
          Penghasilanku
        </p>
        <div
          role="radiogroup"
          aria-labelledby="dompet-income"
          className="mt-2.5 grid grid-cols-3 gap-1 rounded-[14px] bg-[var(--card-2)] p-1 ring-1 ring-[var(--line)]"
        >
          {(
            [
              { id: "umk", label: "UMK daerah" },
              { id: "gaji", label: "Gaji sendiri" },
              { id: "asal", label: "UMK kotaku" },
            ] as const
          ).map((o) => (
            <button
              key={o.id}
              type="button"
              role="radio"
              aria-checked={mode === o.id}
              onClick={() => chooseMode(o.id)}
              className={`h-9 rounded-[10px] text-[13px] font-semibold transition-colors ${
                mode === o.id
                  ? "bg-[var(--accent)] text-white shadow-[var(--shadow-1)] dark:text-[#211a14]"
                  : "text-[var(--ink-2)] hover:text-[var(--ink)]"
              }`}
            >
              {o.label}
            </button>
          ))}
        </div>

        {mode === "umk" && (
          <p className="mt-3 text-[13px] leading-[1.55] text-[var(--muted)]">
            Tiap daerah dihitung dengan UMK/UMP-nya sendiri — lantai upah resmi,
            bukan gaji rata-rata.
          </p>
        )}
        {mode === "gaji" && (
          <SalaryField
            value={a.customIncome ?? 6_000_000}
            onChange={(v) => set("customIncome", v)}
          />
        )}
        {mode === "asal" && <OriginPicker />}

        <div className="mt-4 flex flex-wrap gap-1.5">
          {a.householdType !== "single" && (
            <Chip
              on={a.dualIncome}
              onClick={() => set("dualIncome", !a.dualIncome)}
            >
              Pasangan ikut kerja
            </Chip>
          )}
          <Chip
            on={a.includeSavings}
            onClick={() => set("includeSavings", !a.includeSavings)}
          >
            Sisihkan tabungan 10%
          </Chip>
          {mode !== "gaji" && (
            <Chip
              on={a.wageBasis === "takeHome"}
              onClick={() =>
                set(
                  "wageBasis",
                  a.wageBasis === "takeHome" ? "gross" : "takeHome",
                )
              }
            >
              Setelah potongan
            </Chip>
          )}
          <Chip
            on={installmentOpen}
            onClick={() => {
              if (installmentOpen) set("installmentMonthly", null);
              setInstallmentOpen((v) => !v);
            }}
          >
            Ada cicilan rumah
          </Chip>
        </div>
        {installmentOpen && (
          <label className="mt-3 flex h-11 items-center gap-2 rounded-[12px] border border-[var(--line-2)] bg-[var(--card)] px-3 focus-within:border-[var(--accent)]">
            <span className="text-[13px] font-semibold text-[var(--muted)]">
              Cicilan/bln Rp
            </span>
            <input
              inputMode="numeric"
              autoComplete="off"
              aria-label="Cicilan rumah per bulan"
              placeholder="2.500.000"
              value={rupiahInput(a.installmentMonthly)}
              onChange={(e) =>
                set("installmentMonthly", parseRupiah(e.target.value))
              }
              className="tnum min-w-0 flex-1 bg-transparent text-[15px] font-semibold outline-none"
            />
          </label>
        )}
      </div>

      <div
        className={`mt-5 border-t border-[var(--line)] bg-[var(--card-2)] ${compact ? "px-5 py-4" : "rounded-b-[22px] px-6 py-5"}`}
        aria-live="polite"
      >
        {stats.ready ? (
          <>
            <p className="text-[15px] leading-[1.5] text-[var(--ink-2)]">
              Dengan {who}, hidupmu tertutup di{" "}
              <b className="tnum text-[22px] font-extrabold tracking-[-0.02em] text-[var(--ink)]">
                {fits}
              </b>{" "}
              <span className="text-[var(--muted)]">
                dari {stats.total} daerah.
              </span>
            </p>
            <div
              className="mt-3 flex h-2.5 gap-[3px] overflow-hidden rounded-full"
              aria-hidden="true"
            >
              {BAND_ORDER.map((b) => (
                <span
                  key={b}
                  className="h-full transition-[flex-grow] duration-300"
                  style={{
                    flexGrow: stats.counts[b] || 0.001,
                    background: theme[b].fill,
                  }}
                />
              ))}
            </div>
            <div className="tnum mt-2 flex justify-between text-[11.5px] text-[var(--muted)]">
              {BAND_ORDER.map((b) => (
                <span key={b}>
                  {theme[b].label} {stats.counts[b]}
                </span>
              ))}
            </div>
            {best && (
              <p className="mt-3 text-[12.5px] text-[var(--muted)]">
                Sisa terbesar:{" "}
                <b className="text-[var(--ink)]">{best.shortName}</b>{" "}
                <span className="tnum font-semibold text-[var(--ok)]">
                  +{rpJt(best.metric.surplusOrDeficit)}
                </span>
              </p>
            )}
          </>
        ) : state.dataStatus === "error" ? (
          <p
            role="alert"
            className="text-[13.5px] leading-[1.55] text-[var(--danger)]"
          >
            Hasil belum bisa dihitung karena data gagal dimuat.
          </p>
        ) : (
          <div
            className="space-y-2"
            role="status"
            aria-label="Menghitung hasil"
          >
            <div className="lab-skel h-5 w-4/5" />
            <div className="lab-skel h-2.5 w-full" />
          </div>
        )}
        <button
          type="button"
          onClick={() => {
            reset();
            chooseMode("umk");
            setInstallmentOpen(false);
          }}
          className="mt-3 text-[12.5px] font-semibold text-[var(--muted)] underline decoration-[var(--line-2)] underline-offset-2 hover:text-[var(--ink)]"
        >
          Atur ulang profil
        </button>
      </div>
    </div>
  );
}

function Chip({
  on,
  onClick,
  children,
}: {
  on: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={onClick}
      className={`inline-flex h-8 items-center gap-1.5 rounded-full border px-3 text-[12.5px] font-semibold transition-colors ${
        on
          ? "border-[var(--accent)] bg-[var(--accent-tint)] text-[var(--accent-strong)]"
          : "border-[var(--line-2)] text-[var(--ink-2)] hover:border-[var(--ink-2)]"
      }`}
    >
      {on && <Check size={12} weight="bold" aria-hidden="true" />}
      {children}
    </button>
  );
}

function SalaryField({
  value,
  onChange,
}: {
  value: number;
  onChange: (v: number | null) => void;
}) {
  const pos = posOf(value);
  const fill = (pos / (STEPS.length - 1)) * 100;
  return (
    <div className="mt-3">
      <label className="flex items-baseline gap-2 rounded-[14px] border border-[var(--line-2)] bg-[var(--card)] px-4 py-2.5 focus-within:border-[var(--accent)]">
        <span className="text-[15px] font-bold text-[var(--muted)]">Rp</span>
        <input
          inputMode="numeric"
          autoComplete="off"
          aria-label="Gaji bersih per bulan"
          value={rupiahInput(value)}
          onChange={(e) => onChange(parseRupiah(e.target.value))}
          className="tnum min-w-0 flex-1 bg-transparent text-[26px] font-extrabold tracking-[-0.02em] text-[var(--ink)] outline-none"
        />
        <span className="text-[13px] text-[var(--muted)]">/bulan</span>
      </label>
      <input
        type="range"
        min={0}
        max={STEPS.length - 1}
        value={pos}
        aria-label="Geser gaji"
        aria-valuetext={rpJt(value)}
        onChange={(e) => onChange(STEPS[Number(e.target.value)])}
        className="lab-range mt-2"
        style={{ "--fill": `${fill}%` } as React.CSSProperties}
      />
      <div className="tnum flex justify-between text-[11.5px] text-[var(--muted)]">
        <span>Rp1 jt</span>
        <span>Rp10 jt</span>
        <span>Rp25 jt</span>
      </div>
      <p className="mt-1 text-[12.5px] text-[var(--muted)]">
        Geser — peta langsung menghitung ulang semua daerah.
      </p>
    </div>
  );
}

function OriginPicker() {
  const { state, setOrigin, regionByCode } = useApp();
  const [q, setQ] = useState("");
  const hits = useRegionSearch(q, 5);
  const origin = state.originCode
    ? regionByCode.get(state.originCode)
    : undefined;
  if (origin) {
    return (
      <div className="mt-3 flex items-center gap-3 rounded-[14px] border border-[var(--accent)] bg-[var(--accent-tint)] px-4 py-2.5">
        <div className="min-w-0 flex-1">
          <p className="text-[12px] font-semibold text-[var(--accent-strong)]">
            Aku dari
          </p>
          <p className="truncate text-[16px] font-bold">{origin.name}</p>
          <p className="text-[12.5px] text-[var(--muted)]">
            Gaji = UMK kota ini; biaya = daerah tujuan.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setOrigin(null)}
          aria-label="Hapus kota asal"
          className="grid h-8 w-8 place-items-center rounded-full hover:bg-[var(--accent-soft)]"
        >
          <X size={14} weight="bold" aria-hidden="true" />
        </button>
      </div>
    );
  }
  return (
    <div className="relative mt-3">
      <label className="flex h-11 items-center gap-2 rounded-[12px] border border-[var(--line-2)] bg-[var(--card)] px-3 focus-within:border-[var(--accent)]">
        <MagnifyingGlass
          size={16}
          className="text-[var(--muted)]"
          aria-hidden="true"
        />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Aku sekarang tinggal di…"
          aria-label="Cari kota asal"
          className="min-w-0 flex-1 bg-transparent text-[14px] outline-none placeholder:text-[var(--muted)]"
        />
      </label>
      {hits.length > 0 && (
        <ul className="lab-fade absolute left-0 right-0 top-[calc(100%+6px)] z-50 rounded-[14px] border border-[var(--line)] bg-[var(--card)] p-1.5 shadow-[var(--shadow-2)]">
          {hits.map((h) => (
            <li key={h.code}>
              <button
                type="button"
                onClick={() => {
                  setOrigin(h.code);
                  setQ("");
                }}
                className="flex w-full flex-col rounded-[10px] px-3 py-2 text-left hover:bg-[var(--card-2)]"
              >
                <span className="text-[14px] font-semibold">{h.name}</span>
                <span className="text-[12px] text-[var(--muted)]">
                  {h.province}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
      <p className="mt-2 text-[12.5px] text-[var(--muted)]">
        Mau pindah? Pilih kotamu sekarang — peta menghitung UMK kotamu terhadap
        biaya di tiap daerah tujuan.
      </p>
    </div>
  );
}
