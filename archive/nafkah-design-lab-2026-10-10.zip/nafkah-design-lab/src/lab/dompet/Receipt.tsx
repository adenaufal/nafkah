"use client";

import { useState } from "react";
import {
  ArrowUpRight,
  Check,
  MapPinLine,
  Plus,
  X,
} from "@phosphor-icons/react";
import { useApp } from "@/state/AppContext";
import { formatDate } from "@/lib/format";
import { CORRECTION_FORM_URL } from "@/lib/links";
import { recordUsage } from "@/lib/usage";
import { householdNoun, useAssumptionActions } from "../actions";
import {
  bandTheme,
  breakdownRows,
  pct,
  rpJt,
  useRegionDetail,
  wageLabel,
} from "../useLabData";

const num = (v: number) =>
  (Math.round(Math.abs(v) / 1000) * 1000).toLocaleString("id-ID");

/**
 * Region detail as a monthly receipt: income on top, every cost line below,
 * and what is left (or missing) at the bottom — the format people already
 * use to judge a month.
 */
export function Receipt({
  code,
  onClose,
}: {
  code: string;
  onClose: () => void;
}) {
  const { state, pin, unpin, setOrigin } = useApp();
  const { a } = useAssumptionActions();
  const summary = [
    householdNoun(a),
    { budget: "hemat", moderate: "standar", comfortable: "nyaman" }[
      a.lifestyle
    ],
    { room: "kost", studio: "rumah KPR", oneBedroom: "apartemen" }[a.housing],
    {
      motorcycle: "motor",
      publicTransport: "kendaraan umum",
      rideHailing: "ojol",
    }[a.transport],
  ].join(" · ");
  const d = useRegionDetail(code);
  const [why, setWhy] = useState(false);
  if (!d) return null;
  const m = d.metric;
  const theme = bandTheme(state.darkMode);
  const rows = breakdownRows(d);
  const prov = rows[0]?.provenance;

  return (
    <article aria-labelledby="receipt-title" className="lab-rise relative">
      <div className="rounded-t-[18px] bg-[var(--paper-receipt)] px-6 pb-5 pt-5 shadow-[var(--shadow-2)]">
        <div className="flex items-start justify-between gap-3">
          <p className="f-mono text-[11px] uppercase tracking-[0.18em] text-[var(--muted)]">
            Struk bulanan · Nafkah
          </p>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup struk"
            className="-mr-2 -mt-1 grid h-8 w-8 place-items-center rounded-full text-[var(--muted)] hover:bg-[var(--card-2)] hover:text-[var(--ink)]"
          >
            <X size={15} weight="bold" aria-hidden="true" />
          </button>
        </div>
        <h2
          id="receipt-title"
          className="text-balance mt-2 text-[24px] font-extrabold leading-[1.15] tracking-[-0.02em]"
        >
          {d.name}
        </h2>
        <p className="mt-1 text-[12.5px] text-[var(--muted)]">
          {d.province} · {summary}
        </p>

        {state.dataStatus !== "ready" ? (
          <div
            className="mt-5 space-y-2.5"
            role="status"
            aria-label="Memuat struk"
          >
            {[0, 1, 2, 3, 4].map((i) => (
              <div key={i} className="lab-skel h-4" />
            ))}
          </div>
        ) : !m || !d.hasData ? (
          <p
            role="status"
            className="mt-5 rounded-[12px] border border-dashed border-[var(--line-2)] p-4 text-[13.5px] leading-[1.55]"
          >
            Belum ada data upah atau biaya untuk {d.name}. Daerah ini tampil
            berarsir di peta.
          </p>
        ) : (
          <>
            <Rule />
            <p className="text-[11.5px] font-bold uppercase tracking-[0.1em] text-[var(--muted)]">
              Pemasukan
            </p>
            <Line
              label={
                m.wageSource === "region"
                  ? `${wageLabel(m, state.assumptions)} ${d.wage?.year ?? ""}`
                  : wageLabel(m, state.assumptions)
              }
              value={num(m.wageAmount)}
              strong
            />
            {m.wageSource !== "region" && (
              <p className="f-mono -mt-0.5 text-[11px] text-[var(--muted)]">
                UMK daerah ini: {num(m.regionalWageAmount)}
              </p>
            )}
            <Rule />
            <p className="text-[11.5px] font-bold uppercase tracking-[0.1em] text-[var(--muted)]">
              Pengeluaran · estimasi
            </p>
            <ul className="mt-1">
              {rows.map((r) => (
                <li key={r.key}>
                  <Line label={r.label} value={num(r.value)} />
                </li>
              ))}
            </ul>
            <Rule />
            <Line
              label="Total pengeluaran"
              value={num(m.totalMonthlyCost)}
              strong
            />
            <div
              className="my-3 h-[3px] border-y border-[var(--ink)]"
              aria-hidden="true"
            />
            <div className="flex items-end justify-between gap-3">
              <div>
                <p className="text-[12px] font-bold uppercase tracking-[0.1em] text-[var(--muted)]">
                  {m.surplusOrDeficit >= 0 ? "Sisa" : "Kurang"}
                </p>
                <p className="mt-1 flex items-center gap-1.5 text-[12.5px] font-semibold text-[var(--ink-2)]">
                  <span
                    aria-hidden="true"
                    className="h-2.5 w-2.5 rounded-full"
                    style={{ background: theme[m.band].fill }}
                  />
                  {theme[m.band].label} · tertutup {pct(m.coveragePercent)}
                </p>
              </div>
              <p
                className={`f-mono tnum text-[30px] font-bold leading-none tracking-[-0.03em] ${m.surplusOrDeficit >= 0 ? "text-[var(--ok)]" : "text-[var(--danger)]"}`}
              >
                {m.surplusOrDeficit >= 0 ? "+" : "−"}
                {num(m.surplusOrDeficit)}
              </p>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => (d.isPinned ? unpin(code) : pin(code))}
                aria-pressed={d.isPinned}
                className={`inline-flex h-10 items-center justify-center gap-1.5 rounded-[12px] text-[13px] font-bold transition-colors ${
                  d.isPinned
                    ? "bg-[var(--ink)] text-[var(--card)]"
                    : "bg-[var(--accent)] text-white hover:bg-[var(--accent-strong)] dark:text-[#211a14]"
                }`}
              >
                {d.isPinned ? (
                  <Check size={15} weight="bold" aria-hidden="true" />
                ) : (
                  <Plus size={15} weight="bold" aria-hidden="true" />
                )}
                {d.isPinned ? "Tersimpan" : "Simpan struk"}
              </button>
              <button
                type="button"
                onClick={() => setOrigin(d.isOrigin ? null : code)}
                aria-pressed={d.isOrigin}
                className="inline-flex h-10 items-center justify-center gap-1.5 rounded-[12px] border border-[var(--line-2)] text-[13px] font-bold text-[var(--ink)] hover:border-[var(--ink-2)]"
              >
                <MapPinLine size={15} weight="bold" aria-hidden="true" />
                {d.isOrigin ? "Ini kotaku ✓" : "Ini kotaku"}
              </button>
            </div>

            <button
              type="button"
              aria-expanded={why}
              onClick={() => setWhy((v) => !v)}
              className="mt-4 text-[13px] font-semibold text-[var(--accent-strong)] underline decoration-[var(--line-2)] underline-offset-2"
            >
              {why ? "Sembunyikan catatan" : "Kenapa segini?"}
            </button>
            {why && d.narrative && (
              <div className="lab-fade mt-2 space-y-2 text-[13px] leading-[1.6] text-[var(--ink-2)]">
                <p>{d.narrative.interpretation}</p>
                <p>
                  <b className="text-[var(--ink)]">Sewa tipikal:</b>{" "}
                  {rpJt(d.narrative.rentRange.min)}–
                  {rpJt(d.narrative.rentRange.max)}.{" "}
                  {d.narrative.rentRange.note}
                </p>
              </div>
            )}
            <p className="f-mono mt-4 text-[10.5px] leading-[1.6] text-[var(--muted)]">
              Upah: {d.wageProvenance?.source ?? "—"} (
              {d.wageProvenance?.confidence === "official"
                ? "resmi"
                : "estimasi"}
              ).
              {prov
                ? ` Biaya: estimasi model per ${formatDate(prov.asOf)}.`
                : ""}{" "}
              Bukan nasihat keuangan.{" "}
              <a
                href={CORRECTION_FORM_URL}
                target="_blank"
                rel="noreferrer"
                onClick={() => recordUsage("correction_report_opened")}
                className="inline-flex items-center gap-0.5 font-semibold text-[var(--accent-strong)] underline underline-offset-2"
              >
                Laporkan angka
                <ArrowUpRight size={10} weight="bold" aria-hidden="true" />
              </a>
            </p>
          </>
        )}
      </div>
      <div className="receipt-edge" aria-hidden="true" />
    </article>
  );
}

function Rule() {
  return (
    <div
      className="my-3 border-t border-dashed border-[var(--line-2)]"
      aria-hidden="true"
    />
  );
}

function Line({
  label,
  value,
  strong = false,
}: {
  label: string;
  value: string;
  strong?: boolean;
}) {
  return (
    <div className="flex items-baseline gap-2 py-[3px]">
      <span
        className={`min-w-0 truncate text-[13.5px] ${strong ? "font-bold text-[var(--ink)]" : "text-[var(--ink-2)]"}`}
      >
        {label}
      </span>
      <span
        aria-hidden="true"
        className="mb-[3px] min-w-4 flex-1 border-b border-dotted border-[var(--line-2)]"
      />
      <span
        className={`f-mono tnum shrink-0 text-[13.5px] ${strong ? "font-bold" : ""}`}
      >
        {value}
      </span>
    </div>
  );
}
