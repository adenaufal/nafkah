"use client";

import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import {
  ArrowClockwise,
  ArrowsIn,
  Check,
  MagnifyingGlass,
  Minus,
  Moon,
  PencilSimple,
  Plus,
  Receipt as ReceiptIcon,
  ShareNetwork,
  Sun,
} from "@phosphor-icons/react";
import { useApp } from "@/state/AppContext";
import LabMap, { type LabMapApi } from "../LabMap";
import { useAssumptionActions, useGlobalKeys, useShareLink } from "../actions";
import { useComparison } from "../useComparison";
import { useRegionSearch } from "../useRegionSearch";
import { bandTheme, pct, rpJt } from "../useLabData";
import { FitList } from "./FitList";
import { ProfileCard } from "./ProfileCard";
import { Receipt } from "./Receipt";
import { ReceiptCompare } from "./ReceiptCompare";

/**
 * B · Dompet — personal-first. Start from your own life (a sentence you can
 * edit, a salary you can drag) and let the full-bleed map answer "where does
 * this life fit?". Region detail is a monthly receipt.
 */
export default function DompetShell() {
  const { state, select, setDarkMode } = useApp();
  const [hover, setHover] = useState<{
    code: string;
    x: number;
    y: number;
  } | null>(null);
  const [listHover, setListHover] = useState<string | null>(null);
  const [api, setApi] = useState<LabMapApi | null>(null);
  const [compareOpen, setCompareOpen] = useState(false);
  const [profileSheet, setProfileSheet] = useState(false);
  const wide = useWide();
  const search = useRef<{ focus: () => void }>(null);
  const comparison = useComparison();

  useGlobalKeys({
    onSearch: () => search.current?.focus(),
    onEscape: () => {
      if (compareOpen) return;
      if (profileSheet) setProfileSheet(false);
      else if (state.selectedCode) select(null);
    },
  });

  const padding = wide
    ? { top: 76, left: 400, right: 392, bottom: 16 }
    : {
        top: 108,
        left: 0,
        right: 0,
        bottom: state.selectedCode
          ? Math.round(
              (typeof window === "undefined" ? 800 : window.innerHeight) * 0.6,
            )
          : 260,
      };

  return (
    <div className="dompet relative h-dvh overflow-hidden">
      <div className="absolute inset-0">
        <LabMap
          padding={padding}
          hoverCode={listHover ?? hover?.code ?? null}
          onHover={setHover}
          onReady={setApi}
          markers={state.pinned.map((code, i) => ({
            code,
            label: String(i + 1),
          }))}
          markerClassName="lab-marker-receipt"
        />
      </div>
      {hover && <Tip hover={hover} />}

      {/* Top bar floats over the map */}
      <header className="pointer-events-none absolute inset-x-3 top-3 z-30 flex items-start gap-3">
        <div className="pointer-events-auto flex h-12 items-center gap-2.5 rounded-[16px] bg-[var(--card)] pl-2 pr-4 shadow-[var(--shadow-1)] ring-1 ring-[var(--line)]">
          <span
            aria-hidden="true"
            className="grid h-8 w-8 place-items-center rounded-[10px] bg-[var(--accent)] text-[15px] font-extrabold text-white dark:text-[#211a14]"
          >
            N
          </span>
          <span className="text-[17px] font-extrabold tracking-[-0.02em]">
            Nafkah
          </span>
          <span className="hidden text-[13px] text-[var(--muted)] xl:inline">
            · mulai dari gajimu
          </span>
        </div>
        <div className="pointer-events-auto mx-auto max-lg:hidden">
          <DompetSearch ref={search} />
        </div>
        <div className="pointer-events-auto ml-auto flex h-12 items-center gap-1 rounded-[16px] bg-[var(--card)] px-1.5 shadow-[var(--shadow-1)] ring-1 ring-[var(--line)]">
          {state.pinned.length > 0 && (
            <button
              type="button"
              onClick={() => setCompareOpen(true)}
              disabled={comparison.items.length < 2}
              title={
                comparison.items.length < 2
                  ? "Simpan satu struk lagi untuk membandingkan"
                  : undefined
              }
              className="inline-flex h-9 items-center gap-1.5 rounded-[11px] bg-[var(--accent-tint)] px-3 text-[13px] font-bold text-[var(--accent-strong)] disabled:opacity-60"
            >
              <ReceiptIcon size={16} weight="bold" aria-hidden="true" />
              <span className="max-sm:hidden">
                {comparison.items.length < 2 ? "Struk" : "Bandingkan"}
              </span>
              <span className="tnum grid h-5 min-w-5 place-items-center rounded-full bg-[var(--accent)] px-1 text-[11px] text-white dark:text-[#211a14]">
                {state.pinned.length}
              </span>
            </button>
          )}
          <ShareBtn />
          <button
            type="button"
            onClick={() => setDarkMode(!state.darkMode)}
            aria-label={
              state.darkMode ? "Pakai tema terang" : "Pakai tema gelap"
            }
            className="grid h-9 w-9 place-items-center rounded-[11px] text-[var(--ink-2)] hover:bg-[var(--card-2)]"
          >
            {state.darkMode ? (
              <Sun size={17} aria-hidden="true" />
            ) : (
              <Moon size={17} aria-hidden="true" />
            )}
          </button>
        </div>
      </header>

      {wide ? (
        <>
          <aside
            aria-label="Profil kamu"
            className="lab-scroll absolute left-3 top-[72px] z-20 max-h-[calc(100%-84px)] w-[376px] overflow-y-auto rounded-[22px] bg-[var(--card)] shadow-[var(--shadow-2)] ring-1 ring-[var(--line)]"
          >
            <ProfileCard />
          </aside>
          <aside
            aria-label={
              state.selectedCode ? "Struk daerah" : "Daerah yang cocok"
            }
            className={`absolute right-3 top-[72px] z-20 flex w-[368px] flex-col ${
              state.selectedCode
                ? "lab-scroll max-h-[calc(100%-84px)] overflow-y-auto rounded-[18px] pb-1"
                : "max-h-[min(640px,calc(100%-84px))] overflow-hidden rounded-[22px] bg-[var(--card)] shadow-[var(--shadow-2)] ring-1 ring-[var(--line)]"
            }`}
          >
            {state.selectedCode ? (
              <Receipt
                key={state.selectedCode}
                code={state.selectedCode}
                onClose={() => select(null)}
              />
            ) : (
              <FitList onHover={setListHover} />
            )}
          </aside>
          <MapButtons api={api} className="bottom-4 right-[392px]" />
        </>
      ) : (
        <>
          <button
            type="button"
            onClick={() => setProfileSheet(true)}
            className="absolute inset-x-3 top-[68px] z-20 flex h-11 items-center gap-2 rounded-[14px] bg-[var(--card)] px-3 text-left shadow-[var(--shadow-1)] ring-1 ring-[var(--line)]"
          >
            <ProfileSummary />
            <PencilSimple
              size={15}
              weight="bold"
              className="ml-auto shrink-0 text-[var(--accent)]"
              aria-hidden="true"
            />
            <span className="sr-only">Ubah profil</span>
          </button>
          <section
            aria-label={
              state.selectedCode ? "Struk daerah" : "Daerah yang cocok"
            }
            className={`lab-scroll absolute inset-x-0 bottom-0 z-20 overflow-y-auto rounded-t-[24px] ${
              state.selectedCode
                ? "max-h-[78%] bg-transparent"
                : "h-[260px] bg-[var(--card)] shadow-[0_-8px_30px_rgb(0_0_0/0.12)]"
            }`}
          >
            {state.selectedCode ? (
              <div className="px-2">
                <Receipt
                  key={state.selectedCode}
                  code={state.selectedCode}
                  onClose={() => select(null)}
                />
              </div>
            ) : (
              <FitList onHover={setListHover} />
            )}
          </section>
          {profileSheet && (
            <div
              role="dialog"
              aria-modal="true"
              aria-label="Profil kamu"
              className="lab-rise fixed inset-0 z-50 flex flex-col bg-[var(--card)]"
            >
              <div className="flex items-center justify-between border-b border-[var(--line)] px-4 py-3">
                <p className="text-[16px] font-extrabold">Profil kamu</p>
                <button
                  type="button"
                  onClick={() => setProfileSheet(false)}
                  className="h-9 rounded-[11px] bg-[var(--accent)] px-4 text-[13px] font-bold text-white dark:text-[#211a14]"
                >
                  Lihat peta
                </button>
              </div>
              <div className="lab-scroll min-h-0 flex-1 overflow-y-auto">
                <ProfileCard compact />
              </div>
            </div>
          )}
        </>
      )}

      <Status />
      {state.pinMessage && (
        <p
          role="alert"
          className="lab-fade absolute bottom-24 left-1/2 z-40 -translate-x-1/2 rounded-full bg-[var(--ink)] px-4 py-2 text-[13px] font-semibold text-[var(--card)] shadow-[var(--shadow-2)]"
        >
          {state.pinMessage}
        </p>
      )}
      {compareOpen && comparison.items.length >= 2 && (
        <ReceiptCompare onClose={() => setCompareOpen(false)} />
      )}
    </div>
  );
}

function useWide() {
  const [wide, setWide] = useState(
    () => typeof window !== "undefined" && window.innerWidth >= 1024,
  );
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px)");
    const sync = () => setWide(mq.matches);
    sync();
    mq.addEventListener("change", sync);
    return () => mq.removeEventListener("change", sync);
  }, []);
  return wide;
}

function ProfileSummary() {
  const { a } = useAssumptionActions();
  const { state, regionByCode } = useApp();
  const income =
    (a.customIncome ?? 0) > 0
      ? `Gaji ${rpJt(a.customIncome ?? 0)}`
      : state.originCode
        ? `UMK ${(regionByCode.get(state.originCode)?.name ?? "").replace(/^Kota /, "")}`
        : "UMK daerah";
  const parts = [
    { single: "Lajang", couple: "Pasangan", family: "Keluarga" }[
      a.householdType
    ],
    { budget: "Hemat", moderate: "Standar", comfortable: "Nyaman" }[
      a.lifestyle
    ],
    { room: "Kost", studio: "KPR", oneBedroom: "Apartemen" }[a.housing],
    { motorcycle: "Motor", publicTransport: "Umum", rideHailing: "Ojol" }[
      a.transport
    ],
  ];
  return (
    <span className="flex min-w-0 items-center gap-1.5 overflow-hidden text-[13px]">
      <span className="shrink-0 rounded-full bg-[var(--accent)] px-2 py-0.5 text-[12px] font-bold text-white dark:text-[#211a14]">
        {income}
      </span>
      <span className="truncate font-semibold text-[var(--ink-2)]">
        {parts.join(" · ")}
      </span>
    </span>
  );
}

function ShareBtn() {
  const share = useShareLink();
  return (
    <button
      type="button"
      onClick={() => void share.share()}
      aria-label={share.label}
      title={
        share.includesMoney
          ? "Tautan ikut membawa angka gaji/cicilan yang kamu isi."
          : "Salin tautan"
      }
      className="grid h-9 w-9 place-items-center rounded-[11px] text-[var(--ink-2)] hover:bg-[var(--card-2)]"
    >
      {share.status === "copied" ? (
        <Check size={17} weight="bold" aria-hidden="true" />
      ) : (
        <ShareNetwork size={17} aria-hidden="true" />
      )}
    </button>
  );
}

const DompetSearch = forwardRef<{ focus: () => void }>(
  function DompetSearch(_, ref) {
    const { state, metrics, metricsReady, select } = useApp();
    const [q, setQ] = useState("");
    const [active, setActive] = useState(0);
    const [open, setOpen] = useState(false);
    const input = useRef<HTMLInputElement>(null);
    useImperativeHandle(
      ref,
      () => ({ focus: () => input.current?.focus() }),
      [],
    );
    const hits = useRegionSearch(q, 6);
    const theme = bandTheme(state.darkMode);
    const choose = (code: string) => {
      select(code);
      setQ("");
      setOpen(false);
    };
    const show = open && q.trim() !== "";
    return (
      <div className="relative w-[340px]">
        <MagnifyingGlass
          size={17}
          className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[var(--muted)]"
          aria-hidden="true"
        />
        <input
          ref={input}
          role="combobox"
          aria-label="Cari kabupaten/kota"
          aria-expanded={show}
          aria-controls="dompet-hits"
          aria-activedescendant={
            show && hits[active] ? `dompet-hit-${hits[active].code}` : undefined
          }
          value={q}
          placeholder="Cari kota tujuanmu…"
          onChange={(e) => {
            setQ(e.target.value);
            setActive(0);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 120)}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setActive((i) => Math.min(i + 1, hits.length - 1));
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              setActive((i) => Math.max(i - 1, 0));
            } else if (e.key === "Enter" && hits[active]) {
              choose(hits[active].code);
            } else if (e.key === "Escape") {
              e.stopPropagation();
              setQ("");
              input.current?.blur();
            }
          }}
          className="h-12 w-full rounded-[16px] bg-[var(--card)] pl-11 pr-4 text-[14.5px] shadow-[var(--shadow-1)] outline-none ring-1 ring-[var(--line)] placeholder:text-[var(--muted)] focus:ring-2 focus:ring-[var(--accent)]"
        />
        {show && (
          <ul
            id="dompet-hits"
            role="listbox"
            className="lab-fade absolute inset-x-0 top-[calc(100%+6px)] z-50 rounded-[16px] bg-[var(--card)] p-1.5 shadow-[var(--shadow-2)] ring-1 ring-[var(--line)]"
          >
            {hits.length === 0 && (
              <li className="px-3 py-2.5 text-[13.5px] text-[var(--muted)]">
                Tidak ada daerah “{q.trim()}”.
              </li>
            )}
            {hits.map((h, i) => {
              const m = metricsReady ? metrics.get(h.code) : undefined;
              return (
                <li
                  key={h.code}
                  id={`dompet-hit-${h.code}`}
                  role="option"
                  aria-selected={i === active}
                  onMouseEnter={() => setActive(i)}
                  onMouseDown={(e) => {
                    e.preventDefault();
                    choose(h.code);
                  }}
                  className={`flex cursor-pointer items-center gap-3 rounded-[11px] px-3 py-2 ${i === active ? "bg-[var(--card-2)]" : ""}`}
                >
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[14px] font-semibold">
                      {h.name}
                    </span>
                    <span className="block truncate text-[12px] text-[var(--muted)]">
                      {h.province}
                    </span>
                  </span>
                  {m && (
                    <span
                      className={`tnum text-[13px] font-bold ${m.surplusOrDeficit >= 0 ? "text-[var(--ok)]" : "text-[var(--danger)]"}`}
                    >
                      <span
                        aria-hidden="true"
                        className="mr-1.5 inline-block h-2 w-2 rounded-full align-middle"
                        style={{ background: theme[m.band].fill }}
                      />
                      {m.surplusOrDeficit >= 0 ? "+" : "−"}
                      {rpJt(m.surplusOrDeficit)}
                    </span>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </div>
    );
  },
);

function Tip({ hover }: { hover: { code: string; x: number; y: number } }) {
  const { state, metrics, metricsReady, regionByCode } = useApp();
  const m = metricsReady ? metrics.get(hover.code) : undefined;
  const name = regionByCode.get(hover.code)?.name ?? hover.code;
  const theme = bandTheme(state.darkMode);
  return (
    <div
      role="status"
      className="pointer-events-none absolute z-20 flex items-center gap-2.5 whitespace-nowrap rounded-full bg-[var(--ink)] py-1.5 pl-2.5 pr-3.5 text-[13px] text-[var(--card)] shadow-[var(--shadow-2)]"
      style={{ left: hover.x + 14, top: hover.y - 18 }}
    >
      {m && (
        <span
          aria-hidden="true"
          className="h-2.5 w-2.5 rounded-full ring-2 ring-[var(--card)]/30"
          style={{ background: theme[m.band].fill }}
        />
      )}
      <b className="font-bold">{name}</b>
      {m ? (
        <span className="tnum opacity-80">
          {m.surplusOrDeficit >= 0 ? "sisa +" : "kurang −"}
          {rpJt(m.surplusOrDeficit)} · {pct(m.coveragePercent)}
        </span>
      ) : (
        <span className="opacity-70">
          {metricsReady ? "belum ada data" : "memuat…"}
        </span>
      )}
    </div>
  );
}

function MapButtons({
  api,
  className = "",
}: {
  api: LabMapApi | null;
  className?: string;
}) {
  const btn =
    "grid h-10 w-10 place-items-center rounded-[12px] text-[var(--ink-2)] hover:bg-[var(--card-2)] disabled:opacity-40";
  return (
    <div
      className={`absolute z-10 flex gap-1 rounded-[16px] bg-[var(--card)] p-1 shadow-[var(--shadow-1)] ring-1 ring-[var(--line)] ${className}`}
    >
      <button
        type="button"
        className={btn}
        aria-label="Perbesar"
        onClick={() => api?.zoomIn()}
        disabled={!api}
      >
        <Plus size={16} weight="bold" aria-hidden="true" />
      </button>
      <button
        type="button"
        className={btn}
        aria-label="Perkecil"
        onClick={() => api?.zoomOut()}
        disabled={!api}
      >
        <Minus size={16} weight="bold" aria-hidden="true" />
      </button>
      <button
        type="button"
        className={btn}
        aria-label="Tampilkan seluruh Indonesia"
        onClick={() => api?.fitIndonesia()}
        disabled={!api}
      >
        <ArrowsIn size={16} weight="bold" aria-hidden="true" />
      </button>
    </div>
  );
}

function Status() {
  const { state, retryData, retryGeometry } = useApp();
  const error =
    state.dataStatus === "error" || state.geometryStatus === "error";
  const loading =
    state.dataStatus === "loading" || state.geometryStatus === "loading";
  if (!error && !loading) return null;
  return (
    <div
      role={error ? "alert" : "status"}
      className="absolute bottom-[284px] left-1/2 z-30 flex -translate-x-1/2 items-center gap-3 rounded-full bg-[var(--card)] px-4 py-2 text-[13px] font-semibold shadow-[var(--shadow-2)] ring-1 ring-[var(--line)] lg:bottom-6"
    >
      {error ? (
        <>
          <span className="text-[var(--danger)]">
            {state.geometryStatus === "error"
              ? "Batas wilayah gagal dimuat."
              : "Data upah & biaya gagal dimuat."}
          </span>
          <button
            type="button"
            onClick={
              state.geometryStatus === "error" ? retryGeometry : retryData
            }
            className="inline-flex items-center gap-1 rounded-full bg-[var(--accent)] px-3 py-1 text-[12.5px] font-bold text-white dark:text-[#211a14]"
          >
            <ArrowClockwise size={13} weight="bold" aria-hidden="true" />
            Coba lagi
          </button>
        </>
      ) : (
        <>
          <span
            aria-hidden="true"
            className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-[var(--accent)] border-t-transparent"
          />
          Menghitung 514 daerah…
        </>
      )}
    </div>
  );
}
