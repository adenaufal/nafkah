"use client";

import dynamic from "next/dynamic";
import { useState } from "react";
import { AppProvider } from "@/state/AppContext";
import { applySimulation } from "@/lab/simulate";

/**
 * Client entry for the three design prototypes. Each shell mounts the real
 * AppProvider (same dataset, calculations, persistence and share links as
 * production) and only swaps the chrome around it.
 */

function Booting() {
  return (
    <div className="flex h-dvh items-center justify-center bg-surface text-sm text-muted">
      Memuat prototipe…
    </div>
  );
}

const SHELLS = {
  atlas: dynamic(() => import("@/lab/atlas/AtlasShell"), {
    ssr: false,
    loading: Booting,
  }),
  dompet: dynamic(() => import("@/lab/dompet/DompetShell"), {
    ssr: false,
    loading: Booting,
  }),
  meja: dynamic(() => import("@/lab/meja/MejaShell"), {
    ssr: false,
    loading: Booting,
  }),
};

export type LabVariant = keyof typeof SHELLS;

export default function LabClient({ variant }: { variant: LabVariant }) {
  // Patch fetch before AppProvider's mount effect starts loading.
  useState(() =>
    applySimulation(
      typeof window === "undefined"
        ? null
        : new URLSearchParams(window.location.search).get("simulate"),
    ),
  );
  const Shell = SHELLS[variant];
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  );
}
