import Link from "next/link";

const VARIANTS = [
  {
    href: "/lab/atlas",
    tag: "A",
    name: "Atlas",
    axis: "Hierarki & ekspresi",
    pitch: "Cerita dulu, peta jadi buktinya.",
    body: "Rail editorial menjawab pertanyaan nasional dalam satu kalimat, lalu berganti menjadi cerita daerah dan editor profil — peta tidak pernah tertutup scrim.",
    best: "Publik umum, jurnalis, tautan yang dibagikan",
  },
  {
    href: "/lab/dompet",
    tag: "B",
    name: "Dompet",
    axis: "Interaksi",
    pitch: "Mulai dari gajimu.",
    body: "Profil berupa kalimat yang bisa diubah, slider gaji yang mewarnai ulang 514 daerah secara langsung, dan detail daerah sebagai struk bulanan.",
    best: "Pencari kerja, perantau, perencanaan pindah kota",
  },
  {
    href: "/lab/meja",
    tag: "C",
    name: "Meja Data",
    axis: "Kepadatan & tata letak",
    pitch: "Semua angka sekaligus.",
    body: "Saringan, peta, tabel 514 daerah, dan inspektor tampil bersamaan dan saling terhubung. ⌘K, panah, dan matriks selisih untuk perbandingan.",
    best: "Peneliti, HR, analis kebijakan",
  },
];

export default function LabIndex() {
  return (
    <div className="atlas h-dvh overflow-y-auto">
      <main className="mx-auto max-w-5xl px-6 py-14">
        <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[var(--muted)]">
          Nafkah · lab desain
        </p>
        <h1 className="f-display mt-3 text-[40px] font-[580] leading-[1.08] tracking-[-0.015em]">
          Tiga arah untuk peta yang sama.
        </h1>
        <p className="mt-4 max-w-2xl text-[15.5px] leading-[1.6] text-[var(--ink-2)]">
          Data, rumus, palet band, dan tautan berbagi sama persis dengan
          produksi. Yang berbeda hanya cara menyajikannya. Tiap prototipe bisa
          dicoba penuh: klik daerah, ubah profil, sematkan, dan bandingkan.
        </p>
        <ul className="mt-10 grid gap-4 md:grid-cols-3">
          {VARIANTS.map((v) => (
            <li key={v.href}>
              <Link
                href={v.href}
                className="group flex h-full flex-col rounded-[16px] border border-[var(--rule)] bg-[var(--paper)] p-5 transition-colors hover:border-[var(--ink)]"
              >
                <span className="flex items-center gap-2 text-[12px] font-semibold text-[var(--muted)]">
                  <span className="grid h-6 w-6 place-items-center rounded-[7px] bg-[var(--ink)] text-[12px] font-bold text-[var(--paper)]">
                    {v.tag}
                  </span>
                  {v.axis}
                </span>
                <span className="f-display mt-4 text-[26px] font-[580] leading-tight">
                  {v.name}
                </span>
                <span className="mt-1 text-[15px] font-semibold text-[var(--accent-ink)]">
                  {v.pitch}
                </span>
                <span className="mt-3 flex-1 text-[14px] leading-[1.6] text-[var(--ink-2)]">
                  {v.body}
                </span>
                <span className="mt-4 border-t border-[var(--rule)] pt-3 text-[12.5px] text-[var(--muted)]">
                  Paling cocok: {v.best}
                </span>
              </Link>
            </li>
          ))}
        </ul>
        <p className="mt-8 text-[12.5px] leading-[1.6] text-[var(--muted)]">
          Uji keadaan: tambahkan{" "}
          <code className="rounded bg-[var(--paper-2)] px-1">
            ?simulate=loading
          </code>
          ,{" "}
          <code className="rounded bg-[var(--paper-2)] px-1">data-loading</code>
          , <code className="rounded bg-[var(--paper-2)] px-1">data-error</code>
          , atau{" "}
          <code className="rounded bg-[var(--paper-2)] px-1">geo-error</code> ke
          URL prototipe mana pun.
        </p>
      </main>
    </div>
  );
}
