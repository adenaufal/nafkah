import type { Metadata } from "next";
import { Fraunces, JetBrains_Mono, Plus_Jakarta_Sans } from "next/font/google";
import "@/lab/lab.css";

/*
 * Design lab: three prototype directions for the Nafkah shell. Not linked
 * from the product and excluded from indexing; delete this route (and
 * src/lab) once a direction is chosen.
 */

// Plus Jakarta Sans — Tokotype's typeface for Jakarta's city identity.
const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-jakarta",
  display: "swap",
});

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  display: "swap",
  axes: ["opsz", "SOFT"],
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Lab desain",
  robots: { index: false, follow: false },
};

export default function LabLayout({ children }: { children: React.ReactNode }) {
  return (
    <div
      className={`${jakarta.variable} ${fraunces.variable} ${mono.variable} lab-root`}
    >
      {children}
    </div>
  );
}
