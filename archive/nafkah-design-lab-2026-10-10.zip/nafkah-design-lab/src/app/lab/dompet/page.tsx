import type { Metadata } from "next";
import LabClient from "../LabClient";

export const metadata: Metadata = { title: "B · Dompet — Lab desain" };

export default function Page() {
  return <LabClient variant="dompet" />;
}
