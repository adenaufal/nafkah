import type { Metadata } from "next";
import LabClient from "../LabClient";

export const metadata: Metadata = { title: "C · Meja Data — Lab desain" };

export default function Page() {
  return <LabClient variant="meja" />;
}
