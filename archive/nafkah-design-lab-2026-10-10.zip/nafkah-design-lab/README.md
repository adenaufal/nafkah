# Arsip lab desain Nafkah — 10 Oktober 2026

Tiga prototipe arah desain yang dibuat sebelum desain **A · Atlas** diterapkan
ke produksi. Arah A dipilih dan versi produksinya kini ada di `src/components/`.
**B · Dompet** dan **C · Meja Data** disimpan di arsip ini supaya bisa dipakai
lagi nanti — misalnya C sebagai dasar tampilan multi-GIS untuk analis.

Semua prototipe memakai dataset, rumus, palet band, penyimpanan lokal, dan
tautan berbagi yang sama dengan produksi. Yang berbeda hanya cara penyajiannya.

## Isi

| Folder | Isi |
| --- | --- |
| `src/lab/atlas/` | A · Atlas (hierarki & ekspresi): rail editorial — judul nasional, cerita daerah, editor profil, dot plot 514 daerah. Versi prototipe; versi produksinya sudah berkembang. |
| `src/lab/dompet/` | B · Dompet (interaksi): profil berbentuk kalimat, slider gaji yang mewarnai ulang peta secara langsung, detail daerah sebagai struk bulanan, perbandingan struk berdampingan. |
| `src/lab/meja/` | C · Meja Data (kepadatan & tata letak): saringan band/tier/provinsi, peta + tabel 514 daerah yang saling terhubung, inspektor dengan selisih terhadap median nasional, palet perintah Ctrl/⌘K, matriks selisih terhadap daerah acuan, layout yang bisa diubah ukurannya. |
| `src/lab/*.ts(x)` | Modul bersama: `LabMap.tsx` (MapLibre + feature-state untuk pewarnaan ulang instan), `basemap.ts` (peta dasar "kertas" hangat dari CARTO), `useLabData.ts`, `actions.ts`, `useRegionSearch.ts`, `useComparison.ts`, `simulate.ts`, `lab.css` (token tiap varian). |
| `src/app/lab/` | Rute `/lab` (indeks), `/lab/atlas`, `/lab/dompet`, `/lab/meja`, plus layout yang memuat font (Plus Jakarta Sans, Fraunces, JetBrains Mono). |
| `screenshots/` | Tangkapan layar desktop, mobile, mode gelap, dan perbandingan. `0-current.jpg` adalah UI produksi sebelum redesain. |

## Memulihkan persis seperti saat diarsipkan

Prototipe dibuat di atas commit `fb33615` (`chore(release): v0.3.0`) dan dijamin
bisa di-build di sana.

```bash
git switch -c lab-restore fb33615
unzip nafkah-design-lab-2026-10-10.zip
cp -r nafkah-design-lab/src/. src/
npm install
npm run dev   # buka http://localhost:3000/lab
```

Uji keadaan dengan menambahkan `?simulate=loading`, `data-loading`,
`data-error`, atau `geo-error` ke URL prototipe mana pun.

## Memakai B atau C di kode yang lebih baru

B dan C hanya bergantung pada API produksi yang tetap ada setelah Atlas
diterapkan: `@/state/AppContext` (`AppProvider`, `useApp`, `MAX_PINS`),
`@/lib/*`, `@/data/costs`, `@/state/persist` (`MAX_CHILDREN`), `@/state/share`
(`buildShareUrl`), dan `@/lib/useDialogFocus`.

Satu import perlu disesuaikan: `src/lab/basemap.ts` mengambil `BASEMAPS` dari
`@/components/map/MapCanvas`, yang di produksi baru pindah ke
`@/components/map/basemap`. Prototipe A (`src/lab/atlas/`) juga memakai
`setAboutOpen` dan `AboutDrawer`, yang diganti halaman `/metode` dan
`/tentang`; abaikan folder itu bila hanya B atau C yang dibutuhkan.

Font memakai `next/font/google`, jadi `npm run build` butuh koneksi internet.
